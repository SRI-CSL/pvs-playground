//Code generated using pvs2ir
#ifndef _strassen_h 
#define _strassen_h

#include <stdio.h>

#include <stdlib.h>

#include <inttypes.h>

#include <stdbool.h>

#include <stdarg.h>

#include <string.h>

#include <fcntl.h>

#include <math.h>

#include <sys/mman.h>

#include <sys/stat.h>

#include <sys/types.h>

#include <gmp.h>

#include "pvslib.h"

#include "matrix_c.h"


#include "sigma_c.h"


#include "integertypes_c.h"


#include "exp2_c.h"


//cc -O3 -Wall -o strassen -L /Users/shankar/pvs8/PVS/lib/pvs2c/lib -I /Users/shankar/pvs8/PVS/lib/pvs2c/include matrix_c.c sigma_c.c strassen_c.c <your main>.c  -lgmp -lpvs-prelude 
//msub

struct strassen_array_0_s { uint32_t count;
        uint32_t size;
         uint32_t max;
         mpq_ptr_t elems[]; };
typedef struct strassen_array_0_s * strassen_array_0_t;

extern strassen_array_0_t new_strassen_array_0(uint32_t size);

extern void release_strassen_array_0(strassen_array_0_t x);

extern strassen_array_0_t copy_strassen_array_0(strassen_array_0_t x);

extern bool_t equal_strassen_array_0(strassen_array_0_t x, strassen_array_0_t y);
extern char * json_strassen_array_0(strassen_array_0_t x);

typedef struct actual_strassen_array_0_s {equal_ptr_t equal_ptr; release_ptr_t release_ptr; json_ptr_t json_ptr;} * actual_strassen_array_0_t;
extern void release_strassen_array_0_ptr(pointer_t x, type_actual_t strassen_array_0);

extern bool_t equal_strassen_array_0_ptr(pointer_t x, pointer_t y, type_actual_t T);

extern char * json_strassen_array_0_ptr(pointer_t x, type_actual_t T);

actual_strassen_array_0_t actual_strassen_array_0(void);

 

extern strassen_array_0_t update_strassen_array_0(strassen_array_0_t x, uint32_t i, mpq_t v);

extern strassen_array_0_t upgrade_strassen_array_0(strassen_array_0_t x, uint32_t i, mpq_t v);


//msub

struct strassen_array_1_s { uint32_t count;
        uint32_t size;
         uint32_t max;
         strassen_array_0_t elems[]; };
typedef struct strassen_array_1_s * strassen_array_1_t;

extern strassen_array_1_t new_strassen_array_1(uint32_t size);

extern void release_strassen_array_1(strassen_array_1_t x);

extern strassen_array_1_t copy_strassen_array_1(strassen_array_1_t x);

extern bool_t equal_strassen_array_1(strassen_array_1_t x, strassen_array_1_t y);
extern char * json_strassen_array_1(strassen_array_1_t x);

typedef struct actual_strassen_array_1_s {equal_ptr_t equal_ptr; release_ptr_t release_ptr; json_ptr_t json_ptr;} * actual_strassen_array_1_t;
extern void release_strassen_array_1_ptr(pointer_t x, type_actual_t strassen_array_1);

extern bool_t equal_strassen_array_1_ptr(pointer_t x, pointer_t y, type_actual_t T);

extern char * json_strassen_array_1_ptr(pointer_t x, type_actual_t T);

actual_strassen_array_1_t actual_strassen_array_1(void);

 

extern strassen_array_1_t update_strassen_array_1(strassen_array_1_t x, uint32_t i, strassen_array_0_t v);

extern strassen_array_1_t upgrade_strassen_array_1(strassen_array_1_t x, uint32_t i, strassen_array_0_t v);


//msub

struct strassen_record_2_s {
        uint32_t count; 
        strassen_array_1_t project_1;
        strassen_array_1_t project_2;};
typedef struct strassen_record_2_s * strassen_record_2_t;

extern strassen_record_2_t new_strassen_record_2(void);

extern void release_strassen_record_2(strassen_record_2_t x);

extern strassen_record_2_t copy_strassen_record_2(strassen_record_2_t x);

extern bool_t equal_strassen_record_2(strassen_record_2_t x, strassen_record_2_t y);
extern char * json_strassen_record_2(strassen_record_2_t x);

typedef struct actual_strassen_record_2_s {equal_ptr_t equal_ptr; release_ptr_t release_ptr; json_ptr_t json_ptr;} * actual_strassen_record_2_t;
extern void release_strassen_record_2_ptr(pointer_t x, type_actual_t strassen_record_2);

extern bool_t equal_strassen_record_2_ptr(pointer_t x, pointer_t y, actual_strassen_record_2_t T);

extern char * json_strassen_record_2_ptr(pointer_t x,  actual_strassen_record_2_t T);

actual_strassen_record_2_t actual_strassen_record_2(void);

 

extern strassen_record_2_t update_strassen_record_2_project_1(strassen_record_2_t x, strassen_array_1_t v);

extern strassen_record_2_t update_strassen_record_2_project_2(strassen_record_2_t x, strassen_array_1_t v);


//msub

struct strassen_funtype_3_s;
        typedef struct strassen_funtype_3_s * strassen_funtype_3_t;

struct strassen_funtype_3_ftbl_s {strassen_array_1_t (* fptr)(struct strassen_funtype_3_s *, strassen_record_2_t);
        strassen_array_1_t (* mptr)(struct strassen_funtype_3_s *, strassen_array_1_t, strassen_array_1_t);
        void (* rptr)(struct strassen_funtype_3_s *);
        struct strassen_funtype_3_s * (* cptr)(struct strassen_funtype_3_s *);};
typedef struct strassen_funtype_3_ftbl_s * strassen_funtype_3_ftbl_t;

struct strassen_funtype_3_hashentry_s {uint32_t keyhash; strassen_record_2_t key; strassen_array_1_t value;}; 
typedef struct strassen_funtype_3_hashentry_s strassen_funtype_3_hashentry_t;

struct strassen_funtype_3_htbl_s {uint32_t size; uint32_t num_entries; strassen_funtype_3_hashentry_t * data;}; 
typedef struct strassen_funtype_3_htbl_s * strassen_funtype_3_htbl_t;

struct strassen_funtype_3_s {uint32_t count;
        strassen_funtype_3_ftbl_t ftbl;
        strassen_funtype_3_htbl_t htbl;};

extern void release_strassen_funtype_3(strassen_funtype_3_t x);

extern strassen_funtype_3_t copy_strassen_funtype_3(strassen_funtype_3_t x);

extern bool_t equal_strassen_funtype_3(strassen_funtype_3_t x, strassen_funtype_3_t y);

extern char* json_strassen_funtype_3(strassen_funtype_3_t x);




struct strassen_closure_4_s;
        typedef struct strassen_closure_4_s * strassen_closure_4_t;

struct strassen_closure_4_s {uint32_t count;
         strassen_funtype_3_ftbl_t ftbl;
         strassen_funtype_3_htbl_t htbl;};

strassen_array_1_t f_strassen_closure_4(struct strassen_closure_4_s * closure, strassen_record_2_t bvar);

strassen_array_1_t m_strassen_closure_4(struct strassen_closure_4_s * closure, strassen_array_1_t bvar_1, strassen_array_1_t bvar_2);

extern strassen_array_1_t h_strassen_closure_4(strassen_array_1_t ivar_5, strassen_array_1_t ivar_6);

strassen_closure_4_t new_strassen_closure_4(void);

void release_strassen_closure_4(strassen_funtype_3_t closure);

strassen_closure_4_t copy_strassen_closure_4(strassen_closure_4_t x);


//tl

struct strassen_funtype_5_s;
        typedef struct strassen_funtype_5_s * strassen_funtype_5_t;

struct strassen_funtype_5_ftbl_s {strassen_array_1_t (* fptr)(struct strassen_funtype_5_s *, strassen_array_1_t);
        strassen_array_1_t (* mptr)(struct strassen_funtype_5_s *, strassen_array_1_t);
        void (* rptr)(struct strassen_funtype_5_s *);
        struct strassen_funtype_5_s * (* cptr)(struct strassen_funtype_5_s *);};
typedef struct strassen_funtype_5_ftbl_s * strassen_funtype_5_ftbl_t;

struct strassen_funtype_5_hashentry_s {uint32_t keyhash; strassen_array_1_t key; strassen_array_1_t value;}; 
typedef struct strassen_funtype_5_hashentry_s strassen_funtype_5_hashentry_t;

struct strassen_funtype_5_htbl_s {uint32_t size; uint32_t num_entries; strassen_funtype_5_hashentry_t * data;}; 
typedef struct strassen_funtype_5_htbl_s * strassen_funtype_5_htbl_t;

struct strassen_funtype_5_s {uint32_t count;
        strassen_funtype_5_ftbl_t ftbl;
        strassen_funtype_5_htbl_t htbl;};

extern void release_strassen_funtype_5(strassen_funtype_5_t x);

extern strassen_funtype_5_t copy_strassen_funtype_5(strassen_funtype_5_t x);

extern bool_t equal_strassen_funtype_5(strassen_funtype_5_t x, strassen_funtype_5_t y);

extern char* json_strassen_funtype_5(strassen_funtype_5_t x);


//tl

struct strassen_record_6_s {
        uint32_t count; 
        mpz_t project_1;
        mpz_t project_2;};
typedef struct strassen_record_6_s * strassen_record_6_t;

extern strassen_record_6_t new_strassen_record_6(void);

extern void release_strassen_record_6(strassen_record_6_t x);

extern strassen_record_6_t copy_strassen_record_6(strassen_record_6_t x);

extern bool_t equal_strassen_record_6(strassen_record_6_t x, strassen_record_6_t y);
extern char * json_strassen_record_6(strassen_record_6_t x);

typedef struct actual_strassen_record_6_s {equal_ptr_t equal_ptr; release_ptr_t release_ptr; json_ptr_t json_ptr;} * actual_strassen_record_6_t;
extern void release_strassen_record_6_ptr(pointer_t x, type_actual_t strassen_record_6);

extern bool_t equal_strassen_record_6_ptr(pointer_t x, pointer_t y, actual_strassen_record_6_t T);

extern char * json_strassen_record_6_ptr(pointer_t x,  actual_strassen_record_6_t T);

actual_strassen_record_6_t actual_strassen_record_6(void);

 

extern strassen_record_6_t update_strassen_record_6_project_1(strassen_record_6_t x, mpz_ptr_t v);

extern strassen_record_6_t update_strassen_record_6_project_2(strassen_record_6_t x, mpz_ptr_t v);


//tl

struct strassen_funtype_7_s;
        typedef struct strassen_funtype_7_s * strassen_funtype_7_t;

struct strassen_funtype_7_ftbl_s {strassen_funtype_5_t (* fptr)(struct strassen_funtype_7_s *, strassen_record_6_t);
        strassen_funtype_5_t (* mptr)(struct strassen_funtype_7_s *, mpz_ptr_t, mpz_ptr_t);
        void (* rptr)(struct strassen_funtype_7_s *);
        struct strassen_funtype_7_s * (* cptr)(struct strassen_funtype_7_s *);};
typedef struct strassen_funtype_7_ftbl_s * strassen_funtype_7_ftbl_t;

struct strassen_funtype_7_hashentry_s {uint32_t keyhash; strassen_record_6_t key; strassen_funtype_5_t value;}; 
typedef struct strassen_funtype_7_hashentry_s strassen_funtype_7_hashentry_t;

struct strassen_funtype_7_htbl_s {uint32_t size; uint32_t num_entries; strassen_funtype_7_hashentry_t * data;}; 
typedef struct strassen_funtype_7_htbl_s * strassen_funtype_7_htbl_t;

struct strassen_funtype_7_s {uint32_t count;
        strassen_funtype_7_ftbl_t ftbl;
        strassen_funtype_7_htbl_t htbl;};

extern void release_strassen_funtype_7(strassen_funtype_7_t x);

extern strassen_funtype_7_t copy_strassen_funtype_7(strassen_funtype_7_t x);

extern bool_t equal_strassen_funtype_7(strassen_funtype_7_t x, strassen_funtype_7_t y);

extern char* json_strassen_funtype_7(strassen_funtype_7_t x);


//join4

struct strassen_record_8_s {
        uint32_t count; 
        strassen_array_1_t project_1;
        strassen_array_1_t project_2;
        strassen_array_1_t project_3;
        strassen_array_1_t project_4;};
typedef struct strassen_record_8_s * strassen_record_8_t;

extern strassen_record_8_t new_strassen_record_8(void);

extern void release_strassen_record_8(strassen_record_8_t x);

extern strassen_record_8_t copy_strassen_record_8(strassen_record_8_t x);

extern bool_t equal_strassen_record_8(strassen_record_8_t x, strassen_record_8_t y);
extern char * json_strassen_record_8(strassen_record_8_t x);

typedef struct actual_strassen_record_8_s {equal_ptr_t equal_ptr; release_ptr_t release_ptr; json_ptr_t json_ptr;} * actual_strassen_record_8_t;
extern void release_strassen_record_8_ptr(pointer_t x, type_actual_t strassen_record_8);

extern bool_t equal_strassen_record_8_ptr(pointer_t x, pointer_t y, actual_strassen_record_8_t T);

extern char * json_strassen_record_8_ptr(pointer_t x,  actual_strassen_record_8_t T);

actual_strassen_record_8_t actual_strassen_record_8(void);

 

extern strassen_record_8_t update_strassen_record_8_project_1(strassen_record_8_t x, strassen_array_1_t v);

extern strassen_record_8_t update_strassen_record_8_project_2(strassen_record_8_t x, strassen_array_1_t v);

extern strassen_record_8_t update_strassen_record_8_project_3(strassen_record_8_t x, strassen_array_1_t v);

extern strassen_record_8_t update_strassen_record_8_project_4(strassen_record_8_t x, strassen_array_1_t v);


//join4

struct strassen_funtype_9_s;
        typedef struct strassen_funtype_9_s * strassen_funtype_9_t;

struct strassen_funtype_9_ftbl_s {strassen_array_1_t (* fptr)(struct strassen_funtype_9_s *, strassen_record_8_t);
        strassen_array_1_t (* mptr)(struct strassen_funtype_9_s *, strassen_array_1_t, strassen_array_1_t, strassen_array_1_t, strassen_array_1_t);
        void (* rptr)(struct strassen_funtype_9_s *);
        struct strassen_funtype_9_s * (* cptr)(struct strassen_funtype_9_s *);};
typedef struct strassen_funtype_9_ftbl_s * strassen_funtype_9_ftbl_t;

struct strassen_funtype_9_hashentry_s {uint32_t keyhash; strassen_record_8_t key; strassen_array_1_t value;}; 
typedef struct strassen_funtype_9_hashentry_s strassen_funtype_9_hashentry_t;

struct strassen_funtype_9_htbl_s {uint32_t size; uint32_t num_entries; strassen_funtype_9_hashentry_t * data;}; 
typedef struct strassen_funtype_9_htbl_s * strassen_funtype_9_htbl_t;

struct strassen_funtype_9_s {uint32_t count;
        strassen_funtype_9_ftbl_t ftbl;
        strassen_funtype_9_htbl_t htbl;};

extern void release_strassen_funtype_9(strassen_funtype_9_t x);

extern strassen_funtype_9_t copy_strassen_funtype_9(strassen_funtype_9_t x);

extern bool_t equal_strassen_funtype_9(strassen_funtype_9_t x, strassen_funtype_9_t y);

extern char* json_strassen_funtype_9(strassen_funtype_9_t x);




struct strassen_closure_10_s;
        typedef struct strassen_closure_10_s * strassen_closure_10_t;

struct strassen_closure_10_s {uint32_t count;
         strassen_funtype_9_ftbl_t ftbl;
         strassen_funtype_9_htbl_t htbl;
        uint32_t fvar_1;};

strassen_array_1_t f_strassen_closure_10(struct strassen_closure_10_s * closure, strassen_record_8_t bvar);

strassen_array_1_t m_strassen_closure_10(struct strassen_closure_10_s * closure, strassen_array_1_t bvar_1, strassen_array_1_t bvar_2, strassen_array_1_t bvar_3, strassen_array_1_t bvar_4);

extern strassen_array_1_t h_strassen_closure_10(strassen_array_1_t ivar_19, strassen_array_1_t ivar_20, strassen_array_1_t ivar_21, strassen_array_1_t ivar_22, uint32_t ivar_1);

strassen_closure_10_t new_strassen_closure_10(void);

void release_strassen_closure_10(strassen_funtype_9_t closure);

strassen_closure_10_t copy_strassen_closure_10(strassen_closure_10_t x);




struct strassen_closure_11_s;
        typedef struct strassen_closure_11_s * strassen_closure_11_t;

struct strassen_closure_11_s {uint32_t count;
         strassen_funtype_3_ftbl_t ftbl;
         strassen_funtype_3_htbl_t htbl;
        uint32_t fvar_1;};

strassen_array_1_t f_strassen_closure_11(struct strassen_closure_11_s * closure, strassen_record_2_t bvar);

strassen_array_1_t m_strassen_closure_11(struct strassen_closure_11_s * closure, strassen_array_1_t bvar_1, strassen_array_1_t bvar_2);

extern strassen_array_1_t h_strassen_closure_11(strassen_array_1_t ivar_65, strassen_array_1_t ivar_78, uint32_t ivar_1);

strassen_closure_11_t new_strassen_closure_11(void);

void release_strassen_closure_11(strassen_funtype_3_t closure);

strassen_closure_11_t copy_strassen_closure_11(strassen_closure_11_t x);



extern uint32_t strassen__dim(uint32_t ivar_1);

extern strassen_funtype_3_t strassen__msub(uint32_t ivar_1);

extern strassen_funtype_5_t strassen__tl(uint32_t ivar_1);

extern strassen_funtype_5_t strassen__tr(uint32_t ivar_1);

extern strassen_funtype_5_t strassen__bl(uint32_t ivar_1);

extern strassen_funtype_5_t strassen__br(uint32_t ivar_1);

extern strassen_funtype_9_t strassen__join4(uint32_t ivar_1);

extern strassen_funtype_3_t strassen__strassen(uint32_t ivar_1);

extern bool_t strassen__strassen_id_2(void);

extern bool_t strassen__strassen_id_4(void);
#endif
