# Auto-generated fragment for matrix
OBJS_matrix := $(SRCDIR)/matrix.o $(SRCDIR)/matrix_c.o $(SRCDIR)/sigma_c.o  
pvs2c/bin/matrix: $(OBJS_matrix) | $(BINDIR)
	$(CC) $(CFLAGS) $(LDFLAGS) -o $@ $^ $(LDLIBS)

.PHONY: matrix
matrix: pvs2c/bin/matrix

.PHONY: run_matrix
run_matrix: matrix
	./pvs2c/bin/matrix
