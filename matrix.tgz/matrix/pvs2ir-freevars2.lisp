(defvar *array-expected* nil);;contains the high-expr when the expected type is an array

(defmacro wrap-pvs2ir-freevars (ir-expr array-expected)
  `(let ((*array-expected* ,array-expected))
     (pvs2ir-freevars ,ir-expr)))

(defmacro wrap-pvs2ir-freevars* (ir-expr array-expected)
  `(let ((*array-expected* ,array-expected))
     (pvs2ir-freevars* ,ir-expr)))

(defun pvs2ir-freevars (ir-expr)
  (call-next-method));;add a cache in the next version

(defmethod pvs2ir-freevars* :around ((ir-expr ir-expr))
  (with-slots (ir-freevars) ir-expr
    (if (eq ir-freevars 'unbound)    
	(let ((new-ir-freevars (call-next-method)))
	  (setf (ir-freevars ir-expr) new-ir-freevars)
	  new-ir-freevars)
	ir-freevars)))

    ;; (when (and (consp ir-freevars)
    ;; 	       (member '|ivar_1| ir-freevars :key #'ir-name))
    ;(break "ivar_1 found")
    ;; (format t "~%Going into ~a" (print-ir ir-expr))
    ;; (let ((fv (call-next-method)))
    ;;   (format t "~%~a has freevars: ~{ ~a,~^~}" (print-ir ir-expr) fv)
    ;;   fv)))



(defmethod pvs2ir-freevars* ((ir-expr ir-variable))
  (with-slots (ir-vtype) ir-expr  ;;NSH(4-6-24): don't need to collect freevars from types
    (if (and *array-expected* (ir-funtype? (ir-type-def ir-vtype)))
	(cons ir-expr (wrap-pvs2-ir-freevars* *array-expected* nil))
	(list ir-expr))));; freevars in bound occurrences matter since it could be used for bound computation. 

(defmethod pvs2ir-freevars* ((ir-expr ir-formal-typename))
  (let ((ir-const-formal (loop for entry in *ir-theory-tbindings*
			       when (eq (pvs2ir-unique-decl-id (car entry))
					(ir-type-id ir-expr))
			       return (cdr entry))))
    (if (null ir-const-formal) nil 
      (list ir-const-formal))))

(defmethod pvs2ir-freevars* ((ir-expr ir-last))
  (with-slots (ir-var) ir-expr
	      (pvs2ir-freevars* ir-var)))


	 

(defmethod pvs2ir-freevars* ((ir-expr ir-apply))
  (with-slots (ir-func ir-params ir-args ir-atype) ir-expr
	      (union (wrap-pvs2ir-freevars* ir-func nil)
		     (union (wrap-pvs2ir-freevars* ir-params nil);;don't need to worry about type-freevars
			    (wrap-pvs2ir-freevars* ir-args nil)  ;;since args are all variables of the domain type
			    ;(pvs2ir-freevars* (rename-type ir-atype nil))
			    :test #'eq)
		     :test #'eq)))


(defmethod pvs2ir-freevars* ((ir-expr ir-let))
  (with-slots (ir-vartype ir-bind-expr ir-body) ir-expr
    (let ((body-freevars (pvs2ir-freevars* ir-body)));;no change to *array-expected*
;      (format t "~%body-freevars: ~a" body-freevars)
      (if (memq ir-vartype body-freevars)
	  (let* ((bind-freevars (wrap-pvs2ir-freevars* ir-bind-expr (ir-array? (ir-vtype ir-vartype)))))
		 ;(when (ir-lambda? ir-bind-expr)(format t "~%bindvar-freevars: ~a" bindvar-freevars))
	    ;(format t "~%bind-freevars: ~a" bind-freevars)
	    (union bind-freevars
		   (remove (ir-name ir-vartype) body-freevars :key #'ir-name)
		   :test #'eq))
	  body-freevars))))

(defmethod pvs2ir-freevars* ((ir-expr ir-lett));;high freevars are collected when array<-function cast.
  (with-slots (ir-vartype ir-bind-type ir-bind-expr ir-body) ir-expr
    (let ((body-freevars (pvs2ir-freevars* ir-body)))
      (if (memq ir-vartype body-freevars)
	  (union (wrap-pvs2ir-freevars* ir-bind-expr (ir-array? (ir-vtype ir-vartype)))
		 (remove (ir-name ir-vartype) body-freevars :key #'ir-name)
		 :test #'eq)
	  body-freevars))))

(defmethod pvs2ir-freevars* ((ir-expr ir-record))
  (with-slots (ir-fields ir-recordtype) ir-expr
    (pvs2ir-freevars* ir-fields)))
    ;; (union (pvs2ir-freevars* ir-fields)
    ;; 	   (pvs2ir-freevars* ir-recordtype)
    ;; 	   :test #'eq)


(defmethod pvs2ir-freevars* ((ir-expr ir-field))
  (with-slots (ir-fieldname ir-value) ir-expr
	      (pvs2ir-freevars* ir-value)))

(defmethod pvs2ir-freevars* ((ir-expr ir-lambda))
  (with-slots (ir-vartypes ir-body ir-rangetype) ir-expr
;    (break "pvs2ir-freevars*(ir-lambda)")
      (union (when *array-expected*
	       (pvs2ir-freevars* *array-expected*))
	     (set-difference ;;(union (pvs2ir-freevars* ir-rangetype);;These freevars are not needed
              ;;(union (pvs2ir-freevars* ir-vartypes)))
					;     union nil (pvs2ir-freevars* (mapcar #'ir-vtype ir-vartypes)) ;;NSH(4-6-24)
	      (wrap-pvs2ir-freevars* ir-body (ir-array? ir-rangetype))
					;	    :test #'eq
	      ir-vartypes		;;remove the bound variables
	      :test #'eq)
	     :test #'eq)))

(defmethod pvs2ir-freevars* ((ir-expr ir-ift))
  (with-slots (ir-condition ir-then ir-else) ir-expr
	      (union (wrap-pvs2ir-freevars* ir-condition nil);;expected could be NIL
		     (union (pvs2ir-freevars* ir-then)
			    (pvs2ir-freevars* ir-else)
			    :test #'eq)
		     :test #'eq)))

(defmethod pvs2ir-freevars* ((ir-expr ir-nil))
  nil)

(defmethod pvs2ir-freevars* ((ir-expr ir-lookup))
  (with-slots (ir-array ir-index) ir-expr
	      (union (wrap-pvs2ir-freevars* ir-array nil);;don't need to worry about
		     (wrap-pvs2ir-freevars* ir-index nil);;expected since ir-array will be an array
		     :test #'eq)))

(defmethod pvs2ir-freevars* ((ir-expr ir-update))
  (with-slots (ir-target ir-lhs ir-rhs) ir-expr
	      (union (pvs2ir-freevars* ir-target)
		     (union (wrap-pvs2ir-freevars* ir-lhs nil)
			    (wrap-pvs2ir-freevars* ir-rhs nil)
			    :test #'eq)
		     :test #'eq)))

(defmethod pvs2ir-freevars* ((ir-expr ir-new))
  nil)

(defmethod pvs2ir-freevars* ((ir-expr ir-get))
  (with-slots (ir-record) ir-expr
    (wrap-pvs2ir-freevars* ir-record nil)))

(defmethod pvs2ir-freevars* ((ir-expr ir-array-literal))
  (with-slots (ir-array-literal-exprs) ir-expr
    (wrap-pvs2ir-freevars* ir-array-literal-exprs nil)))


;;collect free vars from low and high exprs for forall and exists exprs
(defmethod pvs2ir-freevars* ((ir-expr ir-forall))
  (with-slots (ir-vartype ir-body) ir-expr
    (let ((bind-low-freevars (pvs2ir-freevars* (ir-low-expr (ir-vtype ir-vartype))))
	  (bind-high-freevars (pvs2ir-freevars* (ir-high-expr (ir-vtype ir-vartype)))))
      (let ((bind-freevars (union bind-low-freevars bind-high-freevars :test #'eq))
	    (body-freevars (pvs2ir-freevars* ir-body)))
	(remove (ir-name ir-vartype) (union bind-freevars body-freevars :test #'eq) :key #'ir-name)))))

(defmethod pvs2ir-freevars* ((ir-expr ir-exists))
  (with-slots (ir-vartype ir-body) ir-expr
    (let ((bind-low-freevars (pvs2ir-freevars* (ir-low-expr (ir-vtype ir-vartype))))
	  (bind-high-freevars (pvs2ir-freevars* (ir-high-expr (ir-vtype ir-vartype)))))
      (let ((bind-freevars (union bind-low-freevars bind-high-freevars :test #'eq))
	    (body-freevars (pvs2ir-freevars* ir-body)))
	(remove (ir-name ir-vartype) (union bind-freevars body-freevars :test #'eq) :key #'ir-name)))))

(defmethod pvs2ir-freevars* ((ir-expr list))
  (cond ((consp ir-expr)
	 (let ((car-fvars (pvs2ir-freevars* (car ir-expr)))
	       (cdr-fvars (pvs2ir-freevars* (cdr ir-expr))))
	   (if (ir-fieldtype? (car ir-expr))
	       (union car-fvars (remove (ir-name (car ir-expr)) cdr-fvars :key #'ir-name)
		      :test #'eq)
	     (union car-fvars cdr-fvars :test #'eq))))
	(t nil)))

(defmethod pvs2ir-freevars* ((ir-expr ir-release))
  (with-slots (ir-body) ir-expr
    (pvs2ir-freevars* ir-body)))

(defmethod pvs2ir-freevars* ((ir-expr ir-typename))
  (declare (ignore ir-expr))
  nil)

(defmethod pvs2ir-freevars* ((ir-expr t))
  (declare (ignore ir-expr))
  nil)

;; (defun make-ir-let (vartype expr body)
;;   (with-slots (ir-name ir-vtype) vartype
;;      (let ((body-freevars (pvs2ir-freevars* body)))
;;        (if (memq vartype body-freevars);;(10-26-22)discard let-binding when vartype is not free in body
;; 	  (if (and (ir-function? expr)
;; 		   (ir-funtype? ir-vtype))
;; 	      (with-slots (ir-domain ir-range) ir-vtype
;; 		(let* ((expr-arg-vars (new-irvartypes (ir-tuple-args ir-domain)))
;; 		       (eta-expr (mk-ir-lambda expr-arg-vars ir-range
;; 					       (mk-ir-apply expr expr-arg-vars nil ir-range))))
;; 		  (mk-ir-let vartype eta-expr body)))
;; 	    (mk-ir-let vartype expr body))
;; 	body))))

;; (defmethod pvs2ir-type-freevars* ((ir-typ ir-arraytype))
;;     (with-slots (high) ir-typ
;;       (pvs2ir-freevars* high '|uint32|)))

;; (defmethod pvs2ir-type-freevars* ((ir-type ir-recordtype))
;;   (with-slots (ir-field-types) ir-type
;;     (pvs2ir-type-freevars* ir-field-types)))

;; (defmethod pvs2ir-type-freevars* :around ((ir-type ir-type))
;; 	   nil)

;; (defmethod preprocess-ir* ((ir-expr ir-apply) livevars bindings);;the ir-args are always distinct, but we are
;;   (with-slots (ir-func ir-params ir-args ir-atype) ir-expr               ;;not exploiting this here.
;;     ;;(when (ir-variable? ir-func) (break "preprocess-ir*(ir-apply): ~s" (print-ir ir-func)))
;; 	      (let* ((ir-params-with-bindings (apply-bindings bindings (pvs2ir-freevars* ir-params nil)))
;; 		     (ir-args-with-bindings (apply-bindings bindings (pvs2ir-freevars* ir-args nil)))
;; 		     (new-ir-atype (preprocess-in-type ir-atype livevars bindings))
;; 		     (new-ir-func
;; 		      (preprocess-ir* ir-func (union ir-params-with-bindings
;; 					       (union ir-args-with-bindings 
;; 						      livevars :test #'eq) :test #'eq)
;; 				      bindings))
;; 		     (new-ir-params (preprocess-ir* ir-params livevars bindings))
;; 		     (new-ir-args (preprocess-ir* ir-args (union ir-params-with-bindings
;; 								 livevars :test #'eq)
;; 						  bindings))
;; 		     ;; (new-ir-atype (ir-apply-arith-type new-ir-func new-ir-args ir-atype))
;; 		     );(when (ir-function? ir-func)(format t "pp-ir*(ir-apply): ~a" (ir-fname ir-func))(break "pp-ir*(ir-apply)"))
;; 		(mk-ir-apply new-ir-func new-ir-args new-ir-params new-ir-atype))))

;; (defmethod preprocess-type* ((ir-type list) livevars bindings)
;;   (cond ((consp ir-type)
;; 	 (cons (preprocess-type* (car ir-type) ;;no freevars in types (except when expecting an array)
;; 				 ;; (union (apply-bindings bindings
;; 				 ;; 			(pvs2ir-freevars* (cdr ir-type))
;; 				 livevars
;; 					;;:test #'eq)
;; 			    bindings)
;; 	       (preprocess-type* (cdr ir-type) livevars bindings)))
;; 	(t nil)))

(defmethod preprocess-ir* ((ir-expr ir-apply) livevars bindings);;the ir-args are always distinct, but we are
  (with-slots (ir-func ir-params ir-args ir-atype) ir-expr               ;;not exploiting this here.
    ;;(when (ir-variable? ir-func) (break "preprocess-ir*(ir-apply): ~s" (print-ir ir-func)))
	      (let* ((ir-params-with-bindings (apply-bindings bindings (pvs2ir-freevars ir-params)))
		     (ir-args-with-bindings (apply-bindings bindings (pvs2ir-freevars ir-args)))
		     (new-ir-atype (preprocess-in-type ir-atype livevars bindings))
		     (new-ir-func
		      (preprocess-ir* ir-func (union ir-params-with-bindings
					       (union ir-args-with-bindings 
						      livevars :test #'eq) :test #'eq)
				      bindings))
		     (new-ir-params (preprocess-ir* ir-params livevars bindings))
		     (new-ir-args (preprocess-ir* ir-args (union ir-params-with-bindings
								 livevars :test #'eq)
						  bindings))
		     ;; (new-ir-atype (ir-apply-arith-type new-ir-func new-ir-args ir-atype))
		     );(when (ir-function? ir-func)(format t "pp-ir*(ir-apply): ~a" (ir-fname ir-func))(break "pp-ir*(ir-apply)"))
		(mk-ir-apply new-ir-func new-ir-args new-ir-params new-ir-atype))))

(defmethod preprocess-ir* ((ir-expr ir-let) livevars bindings)
  (with-slots (ir-vartype ir-bind-expr ir-body) ir-expr
    (let ((body-freevars (pvs2ir-freevars ir-body)));;apply-bindings to get livevars as below
      ;;(format t "preprocess-ir* (irlet): expr = ~a)" (print-ir ir-expr))
					;(loop for iv in body-freevars do (format t "~% free: ~a" (ir-name iv)))
      (if (memq ir-vartype body-freevars) ;;note: without apply-bindings
	  (let* ((body-livevars (apply-bindings bindings body-freevars))
		 (livevars-with-body (union body-livevars livevars :test #'eq))
		 (new-ir-vartype (rename-variable ir-vartype livevars-with-body  bindings)) ;does an in-place substitution
		 (new-ir-bind-expr
		  (let ((*array-expected* (ir-array? (ir-vtype ir-vartype))))
		    (preprocess-ir* ir-bind-expr livevars-with-body
				    bindings))))
	    (if (and (eq ir-vartype ir-body)
		     (not (ir-arraytype? (ir-vtype ir-vartype))))
		new-ir-bind-expr;;for let x = a in b, if x ~ b, then simplify to a
	      (if (and (or (ir-last? new-ir-bind-expr)
			   (and (ir-variable? new-ir-bind-expr) ;;bind var to var
				(not ;(and (mpnumber-type? (ir-vtype new-ir-bind-expr)))
				 (ir-lett? ir-expr)))) ;;ir-lett casts/copies mp numbers for applications
		       (ir2c-tcompatible-but (ir-vtype ir-vartype)(ir-vtype (get-ir-last-var new-ir-bind-expr)))
		       )
					;binds var to var' with same type, then replace var with var'
		  (preprocess-ir* ir-body livevars
				  (acons ir-vartype ; should be eq to new-ir-vartype
					 (get-ir-last-var new-ir-bind-expr); (get-assoc (get-ir-last-var new-ir-bind-expr) bindings)
					 bindings))
		(let* ((new-ir-body (preprocess-ir* ir-body livevars bindings))) ;;might be situations where new-ir-bind-expr 
		                            ;;needs to be re-preprocessed.  
		  ;;(acons ir-vartype new-ir-vartype bindings)
		  ;;(format t "old-ir-body: ~a" (print-ir ir-body))
		  ;;(format t "preprocess-ir*: output = (let ~a ~a ~a)" (print-ir new-ir-vartype)(print-ir new-ir-bind-expr)(print-ir new-ir-body))
		  ;;		(format t "~%old-ir~%~s" (print-ir ir-expr))
		  (if (ir-lett? ir-expr)
		      (let ((new-ir-expr (make-ir-lett new-ir-vartype (preprocess-type (ir-bind-type ir-expr) livevars-with-body bindings)
						       new-ir-bind-expr
						       new-ir-body)))
			new-ir-expr)
		    (mk-ir-let  new-ir-vartype new-ir-bind-expr new-ir-body))))))
	(preprocess-ir* ir-body livevars bindings)))))

(defun make-ir-let (vartype expr body)
  (with-slots (ir-name ir-vtype) vartype
     (let ((body-freevars (pvs2ir-freevars body)))
       (if (memq vartype body-freevars);;(10-26-22)discard let-binding when vartype is not free in body
	  (if (and (ir-function? expr)
		   (ir-funtype? ir-vtype))
	      (with-slots (ir-domain ir-range) ir-vtype
		(let* ((expr-arg-vars (new-irvartypes (ir-tuple-args ir-domain)))
		       (eta-expr (mk-ir-lambda expr-arg-vars ir-range
					       (mk-ir-apply expr expr-arg-vars nil ir-range))))
		  (mk-ir-let vartype eta-expr body)))
	    (mk-ir-let vartype expr body))
	body))))

(defmethod preprocess-type* ((ir-type list) livevars bindings)
  (cond ((consp ir-type)
	 (cons (preprocess-type* (car ir-type)
				 (union (apply-bindings bindings
							(pvs2ir-freevars (cdr ir-type)))
					livevars
					:test #'eq)
			    bindings)
	       (preprocess-type* (cdr ir-type) livevars bindings)))
	(t nil)))

(defmethod preprocess-ir* ((ir-expr ir-forall) livevars bindings)
  (with-slots (ir-vartype ir-body) ir-expr
    (let (;(*new-offset-bindings* nil)
	  (new-ir-vartype (rename-variable ir-vartype livevars bindings))
	  (body-freevars (pvs2ir-freevars ir-body)))
      (if (memq ir-vartype body-freevars)
;;	  (mk-ir-let*-alist *new-offset-bindings*
	  (lcopy ir-expr 'ir-vartype new-ir-vartype
		 'ir-body (preprocess-ir* ir-body livevars bindings)
		 'ir-freevars 'unbound)
	(preprocess-ir* ir-body livevars bindings)))))

(defmethod preprocess-ir* ((ir-expr ir-lambda) livevars bindings)
  (with-slots (ir-vartypes ir-rangetype ir-body) ir-expr
    (let* (;(*new-offset-bindings* nil)
	   (new-ir-vartypes (loop for ir-var in ir-vartypes
				  collect (rename-variable ir-var livevars bindings)))
	   (new-ir-rangetype (preprocess-type ir-rangetype livevars bindings))
	   ;; (ir-mpq-vartypes (loop for ir-var in new-ir-vartypes
	   ;; 			  when (ir-mpq-type? (ir-vtype ir-var))
	   ;; 			  collect ir-var))
	   (expr-freevars (apply-bindings bindings (pvs2ir-freevars* ir-expr)));;no need to substitute into types of freevars-only names matter
	   (last-expr-freevars (set-difference expr-freevars livevars :test #'eq))
		       ;;last-expr-freevars preserve refcount when closure is created
		       ;;other expr-freevars have their refcounts incremented by one.
	   ;(other-livevars (append ir-mpq-vartypes )) ;(union last-expr-freevars livevars :test #'eq)
		       ;;(body-freevars (pvs2ir-freevars* ir-body))
					;(irrelevant-args (set-difference ir-vartypes body-freevars :test #'eq))
	   ;;body freevars are treated as live so that they remain unmarked after preprocessing
	   ;;ir2c*(ir-lambda) takes care of releasing freevars post-for-loop for arrays, and
	   ;;in assigning closure freevars for closures.  
	   (preprocessed-body (preprocess-ir* ir-body (append expr-freevars livevars) bindings))
		       ;; (preprocessed-wrapped-body
		       ;; 	(if irrelevant-args
		       ;; 	    (mk-ir-release (extract-reference-vars irrelevant-args)
		       ;; 			   nil
		       ;; 			   preprocessed-body)
		       ;; 	  preprocessed-body))
	   (preprocessed-ir
	    (mk-ir-lambda-with-lastvars
	     new-ir-vartypes
	     last-expr-freevars
	     new-ir-rangetype
	     preprocessed-body)))
		  ;; (format t "~%Preprocessing Lambda")
		  ;; (format t "~%Freevars = ~s" (print-ir expr-freevars))
		  ;; (format t "~%Irrelevant Args = ~s" (print-ir irrelevant-args))
		  ;; (format t "~%Non-live freevars = ~s" (print-ir last-expr-freevars))
      preprocessed-ir)))

(defmethod preprocess-ir* ((ir-expr ir-lambda) livevars bindings)
  (with-slots (ir-vartypes ir-rangetype ir-body) ir-expr
    (let* (;(*new-offset-bindings* nil)
	   (new-ir-vartypes (loop for ir-var in ir-vartypes
				  collect (rename-variable ir-var livevars bindings)))
	   (new-ir-rangetype (preprocess-type ir-rangetype livevars bindings))
	   ;; (ir-mpq-vartypes (loop for ir-var in new-ir-vartypes
	   ;; 			  when (ir-mpq-type? (ir-vtype ir-var))
	   ;; 			  collect ir-var))
	   (expr-freevars (apply-bindings bindings (pvs2ir-freevars* ir-expr)));;no need to substitute into types of freevars-only names matter
	   (last-expr-freevars (set-difference expr-freevars livevars :test #'eq))
		       ;;last-expr-freevars preserve refcount when closure is created
		       ;;other expr-freevars have their refcounts incremented by one.
	   ;(other-livevars (append ir-mpq-vartypes )) ;(union last-expr-freevars livevars :test #'eq)
		       ;;(body-freevars (pvs2ir-freevars* ir-body))
					;(irrelevant-args (set-difference ir-vartypes body-freevars :test #'eq))
	   ;;body freevars are treated as live so that they remain unmarked after preprocessing
	   ;;ir2c*(ir-lambda) takes care of releasing freevars post-for-loop for arrays, and
	   ;;in assigning closure freevars for closures.  
	   (preprocessed-body (preprocess-ir* ir-body (append expr-freevars livevars) bindings))
		       ;; (preprocessed-wrapped-body
		       ;; 	(if irrelevant-args
		       ;; 	    (mk-ir-release (extract-reference-vars irrelevant-args)
		       ;; 			   nil
		       ;; 			   preprocessed-body)
		       ;; 	  preprocessed-body))
	   (preprocessed-ir
	    (mk-ir-lambda-with-lastvars
	     new-ir-vartypes
	     last-expr-freevars
	     new-ir-rangetype
	     preprocessed-body)))
		  ;; (format t "~%Preprocessing Lambda")
		  ;; (format t "~%Freevars = ~s" (print-ir expr-freevars))
		  ;; (format t "~%Irrelevant Args = ~s" (print-ir irrelevant-args))
		  ;; (format t "~%Non-live freevars = ~s" (print-ir last-expr-freevars))
      preprocessed-ir)))

(defmethod preprocess-ir* ((ir-expr list) livevars bindings)
  (cond ((consp ir-expr)
	 (cons (preprocess-ir* (car ir-expr)
			       (union (apply-bindings bindings
						      (pvs2ir-freevars* (cdr ir-expr)))
				      livevars
				      :test #'eq)
			       bindings)
	       (preprocess-ir* (cdr ir-expr)
			       livevars bindings)))
	(t nil)))

(defmethod ir2c* ((ir-expr ir-lambda) return-var return-type)
  (with-slots (ir-vartypes ir-lastvars ir-rangetype ir-body) ir-expr
    (let* ((ir-arraytype  (get-arraytype return-type)) 
	   (array? (and (ir-arraytype? ir-arraytype)
			(array-size-expr ir-arraytype)))) ;(break "ir2c*(ir-lambda")
      ;; (and (eql (length ir-vartypes) 1)
      ;; 		       (ir-index? (ir-vtype (car ir-vartypes))))
      (if array?;ignore this and retain lambda exprs
	  (let* ((elemtype (with-slots (ir-range) ir-arraytype ir-range))
		 (ir2c-arraytype (ir2c-type ir-arraytype))
		 (c-arraytype (add-c-type-definition ir2c-arraytype))
		 (index (ir-name (car ir-vartypes)))
		 (index-c-type (add-c-type-definition (ir2c-type (ir-vtype (car ir-vartypes)))))
		 (for-index (gentemp "index"))
		 (return-location (format nil "~a->elems[~a]" return-var for-index)) ;(NSH:4/3/24):replaced for-index w/index
		 (return-location-type (ir2c-type elemtype))
		 (c-body (ir2c* ir-body return-location return-location-type))
		 (mp-prelude (when (mpnumber-type? index-c-type)
			       (list (format nil "mpz_t ~a" index)
				     (format nil "mpz_init(~a)" index))))
		 (c-body-with-index (append mp-prelude ;;index is initialized within the for loop
					    (cons (make-c-assignment index index-c-type for-index '|uint32|)
						  c-body)))
		 ;; (mp-final (when (mpnumber-type? index-c-type)
		 ;; 	     (list (format nil "mpz_clear(~a)" index))))
		 (release-instrs (release-instrs ir-lastvars)) ;;NSH(1/21/20)
		 (size (if (integerp array?) (1+ array?) (gentemp "size")))
		 (size-instrs (if (integerp array?) nil
				  (with-slots (expr offset) array?
				    (let* ((size-offset (1+ offset))
					   (offset-instr
					    (format nil "~a += ~a" size size-offset)))
				      (append (list (format nil "uint32_t ~a" size));;link to *max-PVS-array-size*
					      (ir2c* expr size '|uint32|)
					      (list offset-instr))))))
		 (for-instr (mk-for-instr (format nil "uint32_t ~a = 0; ~a < ~a; ~a++"
						for-index for-index size for-index)
					c-body-with-index)));(break "ir2c*(lambda)")
	    (append mp-prelude
		    size-instrs
		    (cons (format nil "~a = new_~a(~a)" return-var c-arraytype size)
					;(format nil "~a->count = 1");;this should be done within new.
			  (if mp-prelude
			      (list for-instr)
			    (list (format nil "~a_t ~a" index-c-type index)
				    for-instr)))
;		    mp-final
		    release-instrs))
	  (let* ((fvars (pvs2ir-freevars* ir-expr))
		 (fvars (loop for fv in fvars
			      when (not (ir-const-formal? fv))
			      collect fv))
		 ;;(lastvars (ir-lastvars ir-expr))
		 (c-return-type (add-c-type-definition return-type))
		 (closure-name (add-closure-definition ir-expr c-return-type))
		 (closure-var (gentemp "cl"))
		 (new-instrs (list (format nil "~a_t ~a" closure-name closure-var)
				   (format nil "~a = new_~a()" closure-var closure-name)))
		 (fvar-instrs (loop for fvar in fvars
				 as i from 1
				 nconc (let ((ir-fv-type (ir2c-type (freevar-type fvar))))
					 (make-c-assignment-with-count
					  (format nil "~a->fvar_~a"  closure-var i)
					  ir-fv-type
					  (freevar-name fvar)
					  (add-c-type-definition ir-fv-type)))))
		 (release-instrs (release-instrs ir-lastvars))
		 (return-instrs (list (format nil "~a = (~a_t)~a"
					return-var
					c-return-type closure-var)))
		 ;;refcount isn't needed
		 ;; (refcount-instrs (loop for fvar in fvars
		 ;; 			      when (and (ir-reference-type? (ir-vtype fvar))
		 ;; 					(not (memq fvar lastvars)))
		 ;; 			      collect (format nil "~a->count++" (ir-name fvar))))
		 )			
	    (nconc new-instrs (nconc fvar-instrs (nconc release-instrs return-instrs))))))))

(defun add-closure-definition (ir-lambda-expr &optional c-return-type)
  (let* ((closure-info (get-c-closure-info ir-lambda-expr))
	 (closure-fdefn (when closure-info (fdefn closure-info))))
    ;(break "add-c-defn")
    (or (and closure-fdefn (op-name closure-fdefn))
	(let* ((ir-freevars (wrap-pvs2ir-freevars ir-lambda-expr
						  (ir-array c-return-type)))
	       (ir-freevars (loop for fv in ir-freevars
				  when (not (ir-const-formal? fv))
				  collect fv))
	       (ir-fvar-types (loop for fvar in ir-freevars collect (freevar-type fvar)))
	       (ir-fvar-ctypes (loop for fvtype in ir-fvar-types collect
				     (add-c-type-definition (ir2c-type fvtype))))
	       (ir-boundvars (ir-vartypes ir-lambda-expr))
	       (ir-rangetype (ir-rangetype ir-lambda-expr))
	       (ir-domaintype (if (eql (length ir-boundvars) 1)
				   (ir-vtype (car ir-boundvars))
				 (let ((ir-field-type (mapcar #'ir-vtype ir-boundvars)))
				   (mk-ir-tupletype (loop for type in ir-field-type
							   as i from 1
							   collect (let ((projection-id (intern (format nil "project_~a" i))))
								     (mk-ir-fieldtype projection-id type projection-id)))))))
	       (ir2c-rangetype (ir2c-type ir-rangetype))
	       (c-rangetype (mppointer-type (add-c-type-definition ir2c-rangetype)))
	       (c-domaintype (add-c-type-definition (ir2c-type ir-domaintype)))
	       (ir-funtype (mk-ir-funtype ir-domaintype ir-rangetype))
	       (c-funtype (or c-return-type (add-c-type-definition (ir2c-type ir-funtype))))
	       ;(ir-body (ir-body ir-lambda-expr))
	       (closure-name-root (format nil "~a_closure_~a" *theory-id* (length *c-type-info-table*)))
	       (closure-type-name (format nil "~a_t" closure-name-root))
	       (closure-struct-name (format nil "~a_s" closure-name-root))
	       (bvar-ctypes
		(loop for bv in ir-boundvars collect (format nil "~a_t" (mppointer-type (add-c-type-definition (ir2c-type (ir-vtype bv)))))))
	       (bvar-cvars (if (eql (length ir-boundvars) 1) (list "bvar")
			     (loop for bv in ir-boundvars as i from 1 collect (format nil "bvar_~a" i))))
	       (bvar-cvar-decls (loop for bv-ctype in bvar-ctypes
				      as bv in bvar-cvars
				      collect (format nil "~a ~a" bv-ctype bv)))
	       (fvar-cvars (loop for fv in ir-fvar-ctypes as i from 1 collect (format nil "fvar_~a" i)))
	       (fvar-cvar-decls (loop for fv-ctype in ir-fvar-ctypes
				      as fv in fvar-cvars
				      collect (format nil "~a_t ~a" fv-ctype fv)))
	       (theory-params *ir-theory-formals*)
	       (theory-formals *theory-formals*)
	       (theory-c-params (ir2c-theory-formals theory-params theory-formals))
;;	       (theory-c-params-variadic (ir2c-theory-formals-variadic "closure" theory-params theory-formals))
	       (c-param-decl-string (format nil "~{, ~a~}" theory-c-params))
	       (c-param-arg-string (format nil "~{, ~a~}" (loop for ir-formal in
								theory-params
								collect (ir-name ir-formal))))
	       (c-param-cvars-string (substitute #\; #\, c-param-decl-string))
	       (ftbl-type-name (format nil "~a_ftbl" c-funtype))
	       (closure-type-decl (format nil "~%struct ~a;~%~8Ttypedef struct ~a * ~a;"
					  closure-struct-name closure-struct-name closure-type-name))
	       (closure-type-defn ;the fptr takes the closure itself and a pointer to the lambda-args
		(format nil "struct ~a {uint32_t count;~%~8T ~a_t ftbl;~%~8T ~a_htbl_t htbl~{;~%~8T~a~^~}~a;};"
			closure-struct-name 
			ftbl-type-name c-funtype
			fvar-cvar-decls
			c-param-cvars-string
			))
	       (closure-fptr-name (format nil "f_~a" closure-name-root))
	       (closure-mptr-name (format nil "m_~a" closure-name-root))
	       (closure-hptr-name (format nil "h_~a" closure-name-root))
	       ;;(closure-cptr-name (format nil "copy_~a" closure-name-root))
	       ;; (closure-cptr-header (format nil "struct ~a * ~a(struct ~a * closure)"
	       ;; 				    closure-struct-name closure-cptr-name closure-struct-name))
	       (closure-fptr-header
		(format nil "~a_t ~a(struct ~a * closure, ~a_t bvar~a);"
			c-rangetype
			closure-fptr-name closure-struct-name (mppointer-type c-domaintype)
			c-param-decl-string))
		;; (case c-rangetype
		;;   ((|mpq| |mpz|)
		;;    (format nil "void ~a(struct ~a * closure, ~a_t result, ~a_t bvar);"
		;; 	   closure-fptr-name closure-struct-name c-rangetype  c-domaintype))
		;;   (t (format nil "~a_t ~a(struct ~a * closure, ~a_t bvar);"
		;; 	     c-rangetype closure-fptr-name closure-struct-name c-domaintype)))
	       (closure-mptr-header
		(format nil "~a_t ~a(struct ~a * closure, ~{~a~^, ~}~a);"
			c-rangetype
			closure-mptr-name closure-struct-name
			bvar-cvar-decls
			c-param-decl-string))
		;; (case c-rangetype
		;; 		      ((|mpq| |mpz|)
		;; 		       (format nil "void ~a(struct ~a * closure, ~a_t result, ~{~a~^, ~});"
		;; 			       closure-mptr-name closure-struct-name c-rangetype
		;; 			       bvar-cvar-decls))
		;; 		      (t (format nil "~a_t ~a(struct ~a * closure, ~{~a~^, ~});"
		;; 				 c-rangetype closure-mptr-name closure-struct-name
		;; 				 bvar-cvar-decls)))
	       (bvar-release-instrs (when (> (length ir-boundvars) 1)
				      (list (make-release-call ir-domaintype c-domaintype "bvar" c-param-arg-string))))
					;(format nil "release_~a(bvar~a)" c-domaintype c-param-arg-string)
	       (bvar_projections
		(when (> (length ir-boundvars) 1)
		  (nconc (loop for ir-bvar in ir-boundvars
			       as i from 1
			       nconc (let* ((atype (add-c-type-definition (ir2c-type (ir-vtype ir-bvar))))
					    (lhs (format nil "bvar_~a" i))
					    (rhs (format nil "bvar->project_~a" i))
					    (init-instrs (cons (format nil "~a_t ~a"  atype lhs)
							       (ir2c-initialize lhs atype rhs atype)))
					    (count-instrs (when (ir-reference-type? (ir-vtype ir-bvar))
							    (list (format nil "~a->count++" rhs))))) ;; i
				       (nconc init-instrs count-instrs)))
			 bvar-release-instrs
			 )))
	       ;;(8/7/21) Might need all theory formals and not just the free ones. 
	       ;; (release-bvar-projections
	       ;; 	(when (> (length ir-boundvars) 1)
	       ;; 	  (loop for ir-bvar in ir-boundvars
	       ;; 		as i from 1
	       ;; 		when (or (ir-reference-type? (ir-vtype ir-bvar))
	       ;; 			 (gmp-type? (ir2c-type (ir-vtype ir-bvar))))
	       ;; 		collect (let ((atype (add-c-type-definition (ir2c-type (ir-vtype ir-bvar)))))
	       ;; 			  (format nil "release_~a(bvar_~a)" atype i)))))
	       (fvar-init-instrs (loop for i from 1 to (length ir-freevars)
				       as fv in ir-freevars
				       collect (format nil "~a_t fvar_~a = closure->fvar_~a"
						       (mppointer-type (add-c-type-definition (ir2c-type (ir-vtype fv))))
						       i i)))
	       (fvar-incref-instrs (loop for i from 1 to (length ir-freevars)
					 as fv in ir-freevars
					 when (ir-reference-type? (ir-vtype fv))
					 collect (format nil "fvar_~a->count++" i)))
	       (bvar-fvar-args (format nil "~{~a~^, ~}~{, ~a~}" ;~{, ~a~}
				       bvar-cvars
				       (loop for i from 1 to (length ir-freevars)
					     collect (format nil "fvar_~a" i))
				       ;;(loop for param in theory-params collect (format nil "closure->~a" (ir-formal-id param)))
				       ))
	       (hashable-domain (ir-hashable-index? (ir2c-type ir-domaintype)))
	       ;;(hashable-range (ir-hashable-index? (ir2c-type ir-rangetype)))
	       (closure-fptr-defn 
		(if hashable-domain  ;;was (and hashable-domain hashable-range)
		    (format nil "~a_t ~a(struct ~a * closure, ~a_t bvar~a){~
~%if (closure->htbl != NULL){~
~%~8T~a_htbl_t htbl = closure->htbl;~
~%~8Tuint32_t hash = ~a_hash(bvar);~
~%~8Tuint32_t hashindex = lookup_~a(htbl, bvar, hash);~
~a~
~%~8Tif (!keyzero || entry.keyhash != 0){~
~%~16T~a_t result;~
~{~%~16T~a;~}~
~%~16T~a;~
~{~%~16T~a;~}~
~%~16Treturn result;}~
~%~8Telse {~
~{~%~12T~a;~}~{~%~12T~a;~}~%~{~%~12T~a;~}~%~12T~a;~
~%~12T~a_t result;~%~12T~a;~%~12Treturn result;};~
~%~8T}
~%~6Telse {~
~{~%~8T~a;~}~{~%~8T~a;~}~{~%~8T~a;~}~%~8T~a;~
~%~8T~a_t result;~%~8T~a;~%~8Treturn result;}~%}"
			    c-rangetype closure-fptr-name ;return type, f_ function name
			    closure-struct-name (mppointer-type c-domaintype); closure and bvar args
			    c-param-decl-string
			    c-funtype;hashtable type prefix
			    hashable-domain;hash function type prefix
			    c-funtype;hash lookup suffix
			    (format nil "~%~8T~a_hashentry_t entry = htbl->data[hashindex];~%~8Tbool_t keyzero;~{~%~8T ~a;~}"
				    c-funtype;
				    (ir2c-arith-relations '== "keyzero"  (list "entry.key" 0)
							  (list c-domaintype '|uint8|)));keyzero = entry.key==0
			    c-rangetype;rangetype for result
			    bvar-release-instrs;release any boundvar(s) since they are not used in this branch
			    (make-release-call ir-funtype c-funtype "closure" c-param-arg-string);closure-name-root ;release closure, also nevery used in this branch
			    (mk-c-assignment-with-count "result" c-rangetype
			     				"entry.value" c-rangetype);assign entry.value to result (inc count)
			    bvar_projections;on the hash failure branch: assign projections of bvar to bvar-projection variables
			    fvar-init-instrs;initialize fvar freevars from closure
			    fvar-incref-instrs ;closure-name-root;increment refcount of fvars in closure and release the closure
			    (make-release-call ir-funtype c-funtype "closure" c-param-arg-string)
			    c-rangetype;declare result var
			    (mk-c-assignment "result" c-rangetype
							(format nil "~a(~a~a)" closure-hptr-name bvar-fvar-args c-param-arg-string)
							c-rangetype);assign result to hptr invocation
			    bvar_projections;if there's no hashtable, compute bvar projections
			    fvar-init-instrs;initialize fvars
			    fvar-incref-instrs;increment fvar refcounts
			    (make-release-call ir-funtype c-funtype "closure" c-param-arg-string);closure-name-root;release closure
			    c-rangetype;introduce result variable
			    (mk-c-assignment "result" c-rangetype
							(format nil "~a(~a~a)" closure-hptr-name bvar-fvar-args c-param-arg-string)
							c-rangetype));assign result
		(format nil "~a_t ~a(struct ~a * closure, ~a_t bvar~a){~{~%~8T~a;~}~{~%~8T~a;~}~{~%~8T~a;~}~%~8T~a;~%~8T~a_t result;~%~8T~a;~%~8Treturn result;~%}"
			c-rangetype;return type
			closure-fptr-name;fptr function name
			closure-struct-name;closure-name-root?
			(mppointer-type c-domaintype);bvar domain type
			c-param-decl-string
			bvar_projections;bvar projections
			fvar-init-instrs;initialize fvars
			fvar-incref-instrs;fvar refcount increments
			(make-release-call ir-funtype c-funtype "closure" c-param-arg-string);closure-name-root;release closure var
			c-rangetype;return type for result var
			(mk-c-assignment "result" c-rangetype
					 (format nil "~a(~a~a)" closure-hptr-name bvar-fvar-args c-param-arg-string)
					 c-rangetype);result assignment calling hptr
			;release-bvar-projections
			)
		;; (case c-rangetype
		;;   ((|mpq| |mpz|)
		;;    ;(format t "bvar-fvar-args: ~a" bvar-fvar-args)
		;;    (format nil "void ~a(struct ~a * closure, ~a_t result, ~a_t bvar){~{~%~8T~a;~}~%~8T~a(result, ~a);}"
		;; 	closure-fptr-name closure-struct-name c-rangetype c-domaintype
		;; 	bvar_projections
		;; 	closure-hptr-name
		;; 	bvar-fvar-args
		;; 	))
		;;    (t (format nil "~a_t ~a(struct ~a * closure, ~a_t bvar){~{~%~8T~a;~}~%~8Treturn ~a(~a);}"
		;; 	      c-rangetype closure-fptr-name closure-struct-name c-domaintype
		;; 	      bvar_projections
		;; 	      closure-hptr-name
		;; 	      bvar-fvar-args
		;; 	      )))
		))
	       (closure-fptr-definition (mk-c-noextern-defn-info closure-fptr-name closure-fptr-header
							closure-fptr-defn))
	       (closure-mptr-defn
		(format nil "~a_t ~a(struct ~a * closure, ~{~a~^, ~}~a){~{~%~8T~a;~}~{~%~8T~a;~}~%~8T~a;~%~8Treturn ~a(~a~a);}"
			c-rangetype
			closure-mptr-name
			closure-struct-name
			bvar-cvar-decls
			c-param-decl-string
			fvar-init-instrs
			fvar-incref-instrs;fvar refcount increments
			(make-release-call ir-funtype c-funtype "closure" c-param-arg-string); closure-name-root;release closure var
			closure-hptr-name
			bvar-fvar-args c-param-arg-string
			)
		;; (case c-rangetype
		;;   ((|mpq| |mpz|)
		;;    ;(format t "bvar-fvar-args: ~a" bvar-fvar-args)
		;;    (format nil "void ~a(struct ~a * closure, ~a_t result, ~{~a~^, ~}){~%~8T~a(result, ~a);}"
		;; 	   closure-mptr-name closure-struct-name c-rangetype
		;; 	   bvar-cvar-decls
		;; 	closure-hptr-name
		;; 	bvar-fvar-args
		;; 	))
		;;    (t (format nil "~a_t ~a(struct ~a * closure, ~{~a~^, ~}){~%~8Treturn ~a(~a);}"
		;; 	      c-rangetype closure-mptr-name closure-struct-name bvar-cvar-decls
		;; 	      closure-hptr-name
		;; 	      bvar-fvar-args
		;; 	      )))
		)
	       (closure-mptr-definition (mk-c-noextern-defn-info closure-mptr-name closure-mptr-header
							closure-mptr-defn))
	       (fptr-cast (format nil "~a_t (*)(~a_t, ~a_t)" c-rangetype
				  c-funtype (mppointer-type c-domaintype)))
	       ;; (case c-rangetype
	       ;; 			 ((|mpq| |mpz|)
	       ;; 			  (format nil "void (*)(~a_t, ~a_t, ~a_t)" c-funtype c-rangetype c-domaintype))
	       ;; 			 (t (format nil "~a_t (*)(~a_t, ~a_t)" c-rangetype c-funtype c-domaintype)))
	       (mptr-cast (format nil "~a_t (*)(~a_t, ~{~a~^, ~})" c-rangetype
				  c-funtype bvar-ctypes)
			  ;; (case c-rangetype
			    ;; ((|mpq| |mpz|)
			    ;;  (format nil "void (*)(~a_t, ~a_t, ~{~a~^, ~})" c-funtype c-rangetype bvar-ctypes))
			    ;; (t (format nil "~a_t (*)(~a_t, ~{~a~^, ~})" c-rangetype c-funtype bvar-ctypes)))
			  )
	       (rptr-cast (format nil "void (*)(~a_t)" c-funtype))
	       (cptr-cast (format nil "~a_t (*)(~a_t)" c-funtype c-funtype))
	       (copy-info (make-closure-copy-info closure-name-root c-funtype ir-domaintype c-domaintype
						  ir-rangetype c-rangetype ir-freevars))
	       (new-info (make-closure-new-info closure-name-root ftbl-type-name fptr-cast mptr-cast rptr-cast cptr-cast ir-freevars));can reuse record-new-info
	       (release-info (make-closure-release-info c-funtype closure-name-root
							ir-domaintype c-domaintype
							ir-rangetype c-rangetype
							ir-fvar-types ir-fvar-ctypes
							c-param-arg-string c-param-decl-string))
	       (closure-defn-info
		(mk-c-closure-info ir-lambda-expr closure-name-root closure-type-decl closure-type-defn closure-fptr-definition closure-mptr-definition nil new-info release-info copy-info)))
	  (push closure-defn-info
		*c-type-info-table*);(break "add-closure")
	  (let ((closure-function-definition
		 (make-c-closure-defn-info ir-lambda-expr closure-hptr-name c-param-decl-string))
		)
	    (setf (hdefn closure-defn-info) closure-function-definition)
	    closure-name-root)))))

(defmethod pvs2ir-decl* ((decl const-decl))
  (let* ((einfod (eval-info decl))
	 (einfo (or einfod (make-c-eval-info decl))))
    (let* ((ir-einfo (ir einfo))
	   (ir-function-name (when ir-einfo (ir-function-name ir-einfo))));(break "pvs2ir-decl*(const-decl)")
      (or ir-function-name
	  (let* ((defn (decl-defn decl)))
	    (unless ir-einfo ;first create eval-info then fill the function name
	      (setf (ir einfo)
		    (make-instance 'ir-defn)))
	    (setf (ir-function-name (ir einfo))
		  (mk-ir-function (pvs2ir-unique-decl-id decl)
				  decl))
	    ;;create the ir for the definition
	    ;;(newcounter *var-counter*)
	    (let* ((context (decl-context decl))
		   (type (find-supertype (type decl)))
		   
		   
		   (ir-defn (if defn
				(if (lambda-expr? defn)
				    (with-slots (bindings expression) defn
				      (let* ((ir-binds
					      (pvs2ir-lambda-bindings bindings *ir-theory-tbindings*))
					     (in-bindings (append (pairlis bindings ir-binds)
								  *ir-theory-tbindings*))
					     (expected-range (dependent-function-range type bindings))
					     (ir-rangetype (pvs2ir-type expected-range in-bindings))
					     (*array-expected* (ir-array? rangetype))
					     (ir-body (pvs2ir expression in-bindings context expected-range)))
					(mk-ir-lambda ir-binds ir-rangetype ir-body)))
				    (let ((*array-expected* (ir-array? (pvs2ir-type (type defn)))))
					   (pvs2ir defn *ir-theory-tbindings* context type)))
				(pvs2c-warn "Missing definition for ~a" (id decl))))
		   (ir-defn-with-tformals
		    (if *ir-theory-formals*
			(cond ((ir-lambda? ir-defn)
			       (setf (ir-vartypes ir-defn)
				     (append *ir-theory-formals* (ir-vartypes ir-defn)))
			       ir-defn)
			      (t (mk-ir-lambda *ir-theory-formals* (pvs2ir-type (type decl))
					       ir-defn)))
			ir-defn))
		   (args (when (ir-lambda? ir-defn-with-tformals)
			   (ir-vartypes ir-defn-with-tformals)))
		   (returntype (or (and (ir-lambda? ir-defn-with-tformals)
					(ir-rangetype ir-defn-with-tformals))
				   (pvs2ir-type (type decl))))
		   (body (if (ir-lambda? ir-defn-with-tformals)
			     (ir-body ir-defn-with-tformals)
			     ir-defn-with-tformals))
		   (lifted-actuals-body (pvs2ir-lifted-actuals body *pvs2c-defn-actuals*)));(break "pvs2ir-decl")
	      ;;(format t "~%ir-theory-formals = ~{~a, ~}" *ir-theory-formals*)
	      ;;(format t "~% pvs2ir-decl*, ir-defn = ~a" (print-ir ir-defn-with-tformals))
	      (setf (ir-args (ir einfo)) args
		    (ir-return-type (ir einfo)) returntype
		    (ir-defn (ir einfo)) lifted-actuals-body)
	      ;; (format t "~%pvs2ir-decl*(const-decl): ~a" (id decl))
	      ;; (when (eq (id decl) '|size|) (break "size"))
	      (ir-function-name (ir einfo))))))))
