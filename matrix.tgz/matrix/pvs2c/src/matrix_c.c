//Code generated using pvs2ir2c
#include "matrix_c.h"



matrix_array_0_t new_matrix_array_0(uint32_t size){
        matrix_array_0_t tmp = (matrix_array_0_t) safe_malloc(sizeof(struct matrix_array_0_s) + (size * sizeof(mpq_ptr_t)));
        tmp->count = 1;
        tmp->size = size;;
        tmp->max = size;
         return tmp;}

void release_matrix_array_0(matrix_array_0_t x){
        x->count--;
         if (x->count <= 0){safe_free(x);}
}

void release_matrix_array_0_ptr(pointer_t x, type_actual_t T){
        release_matrix_array_0((matrix_array_0_t)x);
}

matrix_array_0_t copy_matrix_array_0(matrix_array_0_t x){
        matrix_array_0_t tmp = new_matrix_array_0(x->max);
        tmp->count = 1;
        tmp->size = x->max;
        for (uint32_t i = 0; i < x->max; i++){ tmp->elems[i] = (mpq_ptr_t)safe_malloc(sizeof(mpq_t));
                mpq_init(tmp->elems[i]);
                if (i < x->size) mpq_set(tmp->elems[i], x->elems[i]);};
         return tmp;}

bool_t equal_matrix_array_0(matrix_array_0_t x, matrix_array_0_t y){
        bool_t tmp = true;
        uint32_t i = 0;
        while  (i < x->size && tmp){tmp = (mpq_cmp(x->elems[i], y->elems[i]) == 0); i++;};
        return tmp;}

char * json_matrix_array_0(matrix_array_0_t x){
        char ** tmp = (char **)safe_malloc(sizeof(void *) * x->size);
        for (uint32_t i = 0; i < x->size; i++){tmp[i] = json_mpq(x->elems[i]);};
        char * result = json_list_with_sep(tmp, x->size, '[', ',', ']');
        for (uint32_t i = 0; i < x->size; i++) free(tmp[i]);
        free(tmp);
        return result;}

bool_t equal_matrix_array_0_ptr(pointer_t x, pointer_t y, type_actual_t T){
        return equal_matrix_array_0((matrix_array_0_t)x, (matrix_array_0_t)y);
}

char * json_matrix_array_0_ptr(pointer_t x, type_actual_t T){
        return json_matrix_array_0((matrix_array_0_t)x);
}

actual_matrix_array_0_t actual_matrix_array_0(void){
        actual_matrix_array_0_t new = (actual_matrix_array_0_t)safe_malloc(sizeof(struct actual_matrix_array_0_s));
        new->equal_ptr = (equal_ptr_t)(*equal_matrix_array_0_ptr);
 
        new->release_ptr = (release_ptr_t)(*release_matrix_array_0_ptr);
 
        new->json_ptr = (json_ptr_t)(*json_matrix_array_0_ptr);
 

 
        return new;
 }

matrix_array_0_t update_matrix_array_0(matrix_array_0_t x, uint32_t i, mpq_t v){
        matrix_array_0_t y; 
         if (x->count == 1){y = x;}
           else {y = copy_matrix_array_0(x );
                x->count--;};
        mpq_set(y->elems[i], v);
        return y;}

matrix_array_0_t upgrade_matrix_array_0(matrix_array_0_t x, uint32_t i, mpq_t v){
        matrix_array_0_t y;
        uint32_t xmax = x->max;
         if (x->count == 1 && i < xmax){y = x;}
           else if (i >= xmax){uint32_t newmax = ((xmax < UINT32_MAX/2) ? ((i < 2 * (xmax + 1)) ? 2 * (xmax + 1) : i + 1) : UINT32_MAX);
                y = safe_realloc(x, sizeof(struct matrix_array_0_s) + (newmax * sizeof(mpq_t)));
                y->count = 1;
                y->size = i+1;
                y->max = newmax;}
           else {y = copy_matrix_array_0(x );
                x->count--;};
        mpq_set(y->elems[i], v);
        return y;}




matrix__matrix_t new_matrix__matrix(uint32_t size){
        matrix__matrix_t tmp = (matrix__matrix_t) safe_malloc(sizeof(struct matrix__matrix_s) + (size * sizeof(matrix_array_0_t)));
        tmp->count = 1;
        tmp->size = size;
        tmp->max = size;
        return tmp;}

void release_matrix__matrix(matrix__matrix_t x){
        x->count--;
        if (x->count <= 0){
                for (int i = 0; i < x->size; i++){release_matrix_array_0((matrix_array_0_t)x->elems[i]);};
        //printf("\nFreeing\n");
        safe_free(x);}
}

void release_matrix__matrix_ptr(pointer_t x, type_actual_t T){
        release_matrix__matrix((matrix__matrix_t)x);
}

matrix__matrix_t copy_matrix__matrix(matrix__matrix_t x){
        matrix__matrix_t tmp = new_matrix__matrix(x->max);
        tmp->count = 1;
        tmp->size = x->max;
        for (uint32_t i = 0; i < x->max; i++){tmp->elems[i] = x->elems[i];
                if (i < x->size) x->elems[i]->count++;};
         return tmp;}

bool_t equal_matrix__matrix(matrix__matrix_t x, matrix__matrix_t y){
        bool_t tmp = true;
        uint32_t i = 0;
        while (i < x->size && tmp){tmp = equal_matrix_array_0(x->elems[i], y->elems[i]); i++;};
        return tmp;}

char * json_matrix__matrix(matrix__matrix_t x){
        char ** tmp = (char **)safe_malloc(sizeof(void *) * x->size);
        for (uint32_t i = 0; i < x->size; i++){tmp[i] = json_matrix_array_0(x->elems[i]);};
        char * result = json_list_with_sep(tmp, x->size, '[', ',', ']');
        for (uint32_t i = 0; i < x->size; i++) free(tmp[i]);
        free(tmp);
        return result;}

bool_t equal_matrix__matrix_ptr(pointer_t x, pointer_t y, type_actual_t T){
        return equal_matrix__matrix((matrix__matrix_t)x, (matrix__matrix_t)y);
}

char * json_matrix__matrix_ptr(pointer_t x, type_actual_t T){
        return json_matrix__matrix((matrix__matrix_t)x);
}

actual_matrix__matrix_t actual_matrix__matrix(void){
        actual_matrix__matrix_t new = (actual_matrix__matrix_t)safe_malloc(sizeof(struct actual_matrix__matrix_s));
        new->equal_ptr = (equal_ptr_t)(*equal_matrix__matrix_ptr);
 
        new->release_ptr = (release_ptr_t)(*release_matrix__matrix_ptr);
 
        new->json_ptr = (json_ptr_t)(*json_matrix__matrix_ptr);
 

 
        return new;
 }

matrix__matrix_t update_matrix__matrix(matrix__matrix_t x, uint32_t i, matrix_array_0_t v){
         matrix__matrix_t y;
         if (x->count == 1){y = x;}
                 else {y = copy_matrix__matrix(x);
                      x->count--;};
        matrix_array_0_t * yelems = y->elems;
        if (v != NULL){v->count++;}
        if (yelems[i] != NULL){release_matrix_array_0((matrix_array_0_t)yelems[i]);};
         yelems[i] = v;
         return y;}

matrix__matrix_t upgrade_matrix__matrix(matrix__matrix_t x, uint32_t i, matrix_array_0_t v){
         matrix__matrix_t y;
        uint32_t xmax = x->max;
        uint32_t xsize = x->size;
         if (x->count == 1 && i < xmax){y = x;}
                 else if (i >= xmax){
                            uint32_t newmax = ((xmax < UINT32_MAX/2)  ? ((i < 2 * (xmax + 1))  ? 2 * (xmax + 1) : i + 1) : UINT32_MAX);
                            y = safe_realloc(x, sizeof(struct matrix__matrix_s) + (newmax * sizeof(matrix_array_0_t)));
                            y->count = 1;
                            y->max = newmax;
                            for (uint32_t j = xsize; j < newmax; j++){y->elems[j] = NULL;};}
                         else {y = copy_matrix__matrix(x);
                            x->count--;};
        matrix_array_0_t * yelems = y->elems;
        if (v != NULL){v->count++;};
        y->size = xsize > i ? xsize : i + 1;
        if (i < xmax && yelems[i] != NULL){release_matrix_array_0((matrix_array_0_t)yelems[i]);};
         yelems[i] = v;
         return y;}




matrix_record_2_t new_matrix_record_2(void){
        matrix_record_2_t tmp = (matrix_record_2_t) safe_malloc(sizeof(struct matrix_record_2_s));
        tmp->count = 1;
        return tmp;}

void release_matrix_record_2(matrix_record_2_t x){
        x->count--;
        if (x->count <= 0){
         release_matrix__matrix((matrix__matrix_t)x->project_1);
         release_matrix__matrix((matrix__matrix_t)x->project_2);
        //printf("\nFreeing\n");
        safe_free(x);}}

void release_matrix_record_2_ptr(pointer_t x, type_actual_t T){
        release_matrix_record_2((matrix_record_2_t)x);
}

matrix_record_2_t copy_matrix_record_2(matrix_record_2_t x){
        matrix_record_2_t y = new_matrix_record_2();
        y->project_1 = x->project_1;
        if (y->project_1 != NULL){y->project_1->count++;};
        y->project_2 = x->project_2;
        if (y->project_2 != NULL){y->project_2->count++;};
        y->count = 1;
        return y;}

bool_t equal_matrix_record_2(matrix_record_2_t x, matrix_record_2_t y){
        bool_t tmp = true; tmp = tmp && equal_matrix__matrix((matrix__matrix_t)x->project_1, (matrix__matrix_t)y->project_1); tmp = tmp && equal_matrix__matrix((matrix__matrix_t)x->project_2, (matrix__matrix_t)y->project_2);
        return tmp;}

char * json_matrix_record_2(matrix_record_2_t x){
        char * tmp[2]; 
        char * fld0 = safe_malloc(21);
         sprintf(fld0, "\"project_1\" : ");
        tmp[0] = safe_strcat(fld0, json_matrix__matrix((matrix__matrix_t)x->project_1));
        char * fld1 = safe_malloc(21);
         sprintf(fld1, "\"project_2\" : ");
        tmp[1] = safe_strcat(fld1, json_matrix__matrix((matrix__matrix_t)x->project_2));
         char * result = json_list_with_sep(tmp, 2,  '{', ',', '}');
         for (uint32_t i = 0; i < 2; i++) free(tmp[i]);
        return result;}

bool_t equal_matrix_record_2_ptr(pointer_t x, pointer_t y, actual_matrix_record_2_t T){
        return equal_matrix_record_2((matrix_record_2_t)x, (matrix_record_2_t)y);
}

char * json_matrix_record_2_ptr(pointer_t x, actual_matrix_record_2_t T){
        return json_matrix_record_2((matrix_record_2_t)x);
}

actual_matrix_record_2_t actual_matrix_record_2(void){
        actual_matrix_record_2_t new = (actual_matrix_record_2_t)safe_malloc(sizeof(struct actual_matrix_record_2_s));
        new->equal_ptr = (equal_ptr_t)(*equal_matrix_record_2_ptr);
 
        new->release_ptr = (release_ptr_t)(*release_matrix_record_2_ptr);
 
        new->json_ptr = (json_ptr_t)(*json_matrix_record_2_ptr);
 

 
        return new;
 }

matrix_record_2_t update_matrix_record_2_project_1(matrix_record_2_t x, matrix__matrix_t v){
        matrix_record_2_t y;
        if (v != NULL){v->count++;};
        if (x->count == 1){y = x; if (x->project_1 != NULL){release_matrix__matrix((matrix__matrix_t)x->project_1);};}
        else {y = copy_matrix_record_2(x); x->count--; y->project_1->count--;};
        y->project_1 = (matrix__matrix_t)v;
        return y;}

matrix_record_2_t update_matrix_record_2_project_2(matrix_record_2_t x, matrix__matrix_t v){
        matrix_record_2_t y;
        if (v != NULL){v->count++;};
        if (x->count == 1){y = x; if (x->project_2 != NULL){release_matrix__matrix((matrix__matrix_t)x->project_2);};}
        else {y = copy_matrix_record_2(x); x->count--; y->project_2->count--;};
        y->project_2 = (matrix__matrix_t)v;
        return y;}



void release_matrix_funtype_3(matrix_funtype_3_t x){
        x->count--;
            if (x->count <= 0)

                x->ftbl->rptr(x);}

matrix_funtype_3_t copy_matrix_funtype_3(matrix_funtype_3_t x){return x->ftbl->cptr(x);}

bool_t equal_matrix_funtype_3(matrix_funtype_3_t x, matrix_funtype_3_t y){
        return false;}

char* json_matrix_funtype_3(matrix_funtype_3_t x){char * result = safe_malloc(26); sprintf(result, "%s", "\"matrix_funtype_3\""); return result;}


matrix__matrix_t f_matrix_closure_4(struct matrix_closure_4_s * closure, matrix_record_2_t bvar){
        matrix__matrix_t bvar_1;
        bvar_1 = (matrix__matrix_t)bvar->project_1;
        bvar->project_1->count++;
        matrix__matrix_t bvar_2;
        bvar_2 = (matrix__matrix_t)bvar->project_2;
        bvar->project_2->count++;
        release_matrix_record_2((matrix_record_2_t)bvar);
        release_matrix_funtype_3((matrix_funtype_3_t)closure);
        matrix__matrix_t result;
        result = (matrix__matrix_t)h_matrix_closure_4(bvar_1, bvar_2);
        return result;
}

matrix__matrix_t m_matrix_closure_4(struct matrix_closure_4_s * closure, matrix__matrix_t bvar_1, matrix__matrix_t bvar_2){
        release_matrix_funtype_3((matrix_funtype_3_t)closure);
        return h_matrix_closure_4(bvar_1, bvar_2);}

matrix__matrix_t h_matrix_closure_4(matrix__matrix_t ivar_6, matrix__matrix_t ivar_7){
        matrix__matrix_t result;

        uint32_t size6461;
        //copying to uint32 from uint32;
        size6461 = (uint32_t)ivar_1;
        size6461 += 0;
        result = new_matrix__matrix(size6461);
        uint32_t ivar_9;
        for (uint32_t index6458 = 0; index6458 < size6461; index6458++){
             ivar_9 = (uint32_t)index6458;
             uint32_t size6460;
             //copying to uint32 from uint32;
             size6460 = (uint32_t)ivar_2;
             size6460 += 0;
             result->elems[index6458] = new_matrix_array_0(size6460);
             uint32_t ivar_11;
             for (uint32_t index6459 = 0; index6459 < size6460; index6459++){
           ivar_11 = (uint32_t)index6459;
           mpq_ptr_t ivar_12;
           matrix_array_0_t ivar_16;
           matrix_array_0_t ivar_18;
           ivar_18 = (matrix_array_0_t)ivar_6->elems[ivar_9];
           ivar_18->count++;
           //copying to matrix_array_0 from matrix_array_0;
           ivar_16 = (matrix_array_0_t)ivar_18;
           if (ivar_16 != NULL) ivar_16->count++;
           release_matrix_array_0((matrix_array_0_t)ivar_18);
           ivar_12 = safe_malloc(sizeof(mpq_t));
           mpq_init(ivar_12);
           mpq_set(ivar_12, ivar_16->elems[ivar_11]);
           release_matrix_array_0((matrix_array_0_t)ivar_16);
           mpq_ptr_t ivar_13;
           matrix_array_0_t ivar_24;
           matrix_array_0_t ivar_26;
           ivar_26 = (matrix_array_0_t)ivar_7->elems[ivar_9];
           ivar_26->count++;
           //copying to matrix_array_0 from matrix_array_0;
           ivar_24 = (matrix_array_0_t)ivar_26;
           if (ivar_24 != NULL) ivar_24->count++;
           release_matrix_array_0((matrix_array_0_t)ivar_26);
           ivar_13 = safe_malloc(sizeof(mpq_t));
           mpq_init(ivar_13);
           mpq_set(ivar_13, ivar_24->elems[ivar_11]);
           release_matrix_array_0((matrix_array_0_t)ivar_24);
           mpq_mk_set(result->elems[index6458]->elems[index6459], ivar_12);
           mpq_add(result->elems[index6458]->elems[index6459], result->elems[index6458]->elems[index6459], ivar_13);
           mpq_clear(ivar_12);
           mpq_clear(ivar_13);
             };
        };
        release_matrix__matrix((matrix__matrix_t)ivar_6);
        release_matrix__matrix((matrix__matrix_t)ivar_7);
        return result;
}

matrix_closure_4_t new_matrix_closure_4(void){
        static struct matrix_funtype_3_ftbl_s ftbl = {.fptr = (matrix__matrix_t (*)(matrix_funtype_3_t, matrix_record_2_t))&f_matrix_closure_4, .mptr = (matrix__matrix_t (*)(matrix_funtype_3_t, matrix__matrix_t, matrix__matrix_t))&m_matrix_closure_4, .rptr =  (void (*)(matrix_funtype_3_t))&release_matrix_closure_4, .cptr = (matrix_funtype_3_t (*)(matrix_funtype_3_t))&copy_matrix_closure_4};
        matrix_closure_4_t tmp = (matrix_closure_4_t) safe_malloc(sizeof(struct matrix_closure_4_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_4(matrix_funtype_3_t closure){
        matrix_closure_4_t x = (matrix_closure_4_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix_record_2((matrix_record_2_t)x->htbl->data[j].key); release_matrix__matrix((matrix__matrix_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_4_t copy_matrix_closure_4(matrix_closure_4_t x){
        matrix_closure_4_t y = new_matrix_closure_4();
        y->ftbl = x->ftbl;

        if (x->htbl != NULL){
            matrix_funtype_3_htbl_t new_htbl = (matrix_funtype_3_htbl_t) safe_malloc(sizeof(struct matrix_funtype_3_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_3_hashentry_t * new_data = (matrix_funtype_3_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_3_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix_record_2_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (matrix__matrix_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}

void release_matrix_funtype_5(matrix_funtype_5_t x){
        x->count--;
            if (x->count <= 0)

                x->ftbl->rptr(x);}

matrix_funtype_5_t copy_matrix_funtype_5(matrix_funtype_5_t x){return x->ftbl->cptr(x);}

uint32_t lookup_matrix_funtype_5(matrix_funtype_5_htbl_t htbl, mpz_ptr_t i, uint32_t ihash){
        uint32_t mask = htbl->size - 1;
        uint32_t hashindex = ihash & mask;
        matrix_funtype_5_hashentry_t data = htbl->data[hashindex];
        bool_t keyzero;


        int64_t tmp6465 = mpz_cmp_ui(data.key, 0);
        keyzero = (tmp6465 == 0);
        bool_t keymatch;

        int64_t tmp6466 = mpz_cmp(data.key, i);
        keymatch = (tmp6466 == 0);
        while ((!keyzero || data.keyhash != 0) &&
                 (data.keyhash != ihash || !keymatch)){
                hashindex++;
                hashindex = hashindex & mask;
                data = htbl->data[hashindex];


                int64_t tmp6465 = mpz_cmp_ui(data.key, 0);
                keyzero = (tmp6465 == 0);


                int64_t tmp6466 = mpz_cmp(data.key, i);
                keymatch = (tmp6466 == 0);
                }
        return hashindex;
        }

matrix_funtype_5_t dupdate_matrix_funtype_5(matrix_funtype_5_t a, mpz_ptr_t i, mpq_ptr_t v){
        matrix_funtype_5_htbl_t htbl = a->htbl;
        if (htbl == NULL){//construct new htbl
                htbl = (matrix_funtype_5_htbl_t)safe_malloc(sizeof(struct matrix_funtype_5_htbl_s));
                htbl->size = HTBL_DEFAULT_SIZE; htbl->num_entries = 0;
                htbl->data = (matrix_funtype_5_hashentry_t *)safe_malloc(HTBL_DEFAULT_SIZE * sizeof(struct matrix_funtype_5_hashentry_s));
                for (uint32_t j = 0; j < HTBL_DEFAULT_SIZE; j++){mpz_init(htbl->data[j].key);mpz_set_ui(htbl->data[j].key, 0); htbl->data[j].keyhash = 0;
                }
                a->htbl = htbl;
        }
        uint32_t size = htbl->size;
        uint32_t num_entries = htbl->num_entries;
        matrix_funtype_5_hashentry_t * data = htbl->data;
        if (num_entries/3 >  size/5){//resize data
                uint32_t new_size = 2*size; uint32_t new_mask = new_size - 1;
                if (size >= HTBL_MAX_SIZE) out_of_memory();
                matrix_funtype_5_hashentry_t * new_data = (matrix_funtype_5_hashentry_t *)safe_malloc(new_size * sizeof(struct matrix_funtype_5_hashentry_s));
                for (uint32_t j = 0; j < new_size; j++){
                        mpz_init(new_data[j].key); mpz_set_ui(new_data[j].key, 0); 
                        new_data[j].keyhash = 0;}
                for (uint32_t j = 0; j < size; j++){//transfer entries
                        uint32_t keyhash = data[j].keyhash;
                        bool_t keyzero;
                        int64_t tmp6467 = mpz_cmp_ui(data[j].key, 0);
                        keyzero = (tmp6467 == 0);

                        if (!keyzero || keyhash != 0){
                                uint32_t new_loc = keyhash ^ new_mask;
                                bool_t newkeyzero;
                                int64_t tmp6468 = mpz_cmp_ui(new_data[new_loc].key, 0);
                                newkeyzero = (tmp6468 == 0);

                                while (!newkeyzero || new_data[new_loc].keyhash != 0){
                                        new_loc++;
                                        new_loc = new_loc ^ new_mask;

                                        int64_t tmp6469 = mpz_cmp_ui(new_data[new_loc].key, 0);
                                        newkeyzero = (tmp6469 == 0);

                                }
                                mpz_set(new_data[new_loc].key, data[j].key);
                                new_data[new_loc].keyhash = keyhash;
                                mpq_set(new_data[new_loc].value, data[j].value);
                                }}
                htbl->size = new_size;
                htbl->num_entries = num_entries;
                htbl->data = new_data;
                for (uint32_t j=0; j < size; j++){mpz_clear(data[j].key); mpq_clear(data[j].value);};
                safe_free(data);}
        uint32_t ihash = mpz_hash(i);
        uint32_t hashindex = lookup_matrix_funtype_5(htbl, i, ihash);
        matrix_funtype_5_hashentry_t hentry = htbl->data[hashindex];
        uint32_t hkeyhash = hentry.keyhash;
        bool_t hentrykeyzero;
        int64_t tmp6470 = mpz_cmp_ui(hentry.key, 0);
        hentrykeyzero = (tmp6470 == 0);

        if (hentrykeyzero && (hkeyhash == 0))
                {mpz_set(htbl->data[hashindex].key, i); htbl->data[hashindex].keyhash = ihash; mpq_set(htbl->data[hashindex].value, v); htbl->num_entries++;}
            else {mpq_set(htbl->data[hashindex].value, v);};
        return a;

}

matrix_funtype_5_t update_matrix_funtype_5(matrix_funtype_5_t a, mpz_ptr_t i, mpq_ptr_t v){
        if (a->count == 1){
                return dupdate_matrix_funtype_5(a, i, v);
            } else {
                matrix_funtype_5_t x = copy_matrix_funtype_5(a);
                a->count--;
                return dupdate_matrix_funtype_5(x, i, v);
            }}

bool_t equal_matrix_funtype_5(matrix_funtype_5_t x, matrix_funtype_5_t y){
        return false;}

char* json_matrix_funtype_5(matrix_funtype_5_t x){char * result = safe_malloc(26); sprintf(result, "%s", "\"matrix_funtype_5\""); return result;}


mpq_ptr_t f_matrix_closure_6(struct matrix_closure_6_s * closure, mpz_ptr_t bvar){
if (closure->htbl != NULL){
        matrix_funtype_5_htbl_t htbl = closure->htbl;
        uint32_t hash = mpz_hash(bvar);
        uint32_t hashindex = lookup_matrix_funtype_5(htbl, bvar, hash);
        matrix_funtype_5_hashentry_t entry = htbl->data[hashindex];
        bool_t keyzero;
         int64_t tmp6471 = mpz_cmp_ui(entry.key, 0);
         keyzero = (tmp6471 == 0);
        if (!keyzero || entry.keyhash != 0){
                mpq_ptr_t result;
                release_matrix_funtype_5((matrix_funtype_5_t)closure);
                result = (mpq_ptr_t)entry.value;
                return result;}
        else {
            matrix__matrix_t fvar_1 = closure->fvar_1;
            mpz_ptr_t fvar_2 = closure->fvar_2;
            matrix__matrix_t fvar_3 = closure->fvar_3;
            mpz_ptr_t fvar_4 = closure->fvar_4;

            fvar_1->count++;
            fvar_3->count++;
            release_matrix_funtype_5((matrix_funtype_5_t)closure);
            mpq_ptr_t result;
            result = (mpq_ptr_t)h_matrix_closure_6(bvar, fvar_1, fvar_2, fvar_3, fvar_4);
            return result;};
        }

      else {
        matrix__matrix_t fvar_1 = closure->fvar_1;
        mpz_ptr_t fvar_2 = closure->fvar_2;
        matrix__matrix_t fvar_3 = closure->fvar_3;
        mpz_ptr_t fvar_4 = closure->fvar_4;
        fvar_1->count++;
        fvar_3->count++;
        release_matrix_funtype_5((matrix_funtype_5_t)closure);
        mpq_ptr_t result;
        result = (mpq_ptr_t)h_matrix_closure_6(bvar, fvar_1, fvar_2, fvar_3, fvar_4);
        return result;}
}

mpq_ptr_t m_matrix_closure_6(struct matrix_closure_6_s * closure, mpz_ptr_t bvar){
        matrix__matrix_t fvar_1 = closure->fvar_1;
        mpz_ptr_t fvar_2 = closure->fvar_2;
        matrix__matrix_t fvar_3 = closure->fvar_3;
        mpz_ptr_t fvar_4 = closure->fvar_4;
        fvar_1->count++;
        fvar_3->count++;
        release_matrix_funtype_5((matrix_funtype_5_t)closure);
        return h_matrix_closure_6(bvar, fvar_1, fvar_2, fvar_3, fvar_4);}

mpq_ptr_t h_matrix_closure_6(mpz_ptr_t ivar_12, matrix__matrix_t ivar_5, mpz_ptr_t ivar_9, matrix__matrix_t ivar_4, mpz_ptr_t ivar_7){
        mpq_ptr_t result;

        mpq_ptr_t ivar_13;
        matrix_array_0_t ivar_17;
        uint32_t ivar_21;
        //copying to uint32 from mpz;
        ivar_21 = (uint32_t)mpz_get_ui(ivar_7);
        matrix_array_0_t ivar_19;
        ivar_19 = (matrix_array_0_t)ivar_4->elems[ivar_21];
        ivar_19->count++;
        //copying to matrix_array_0 from matrix_array_0;
        ivar_17 = (matrix_array_0_t)ivar_19;
        if (ivar_17 != NULL) ivar_17->count++;
        release_matrix_array_0((matrix_array_0_t)ivar_19);
        uint32_t ivar_22;
        //copying to uint32 from mpz;
        ivar_22 = (uint32_t)mpz_get_ui(ivar_12);
        ivar_13 = safe_malloc(sizeof(mpq_t));
        mpq_init(ivar_13);
        mpq_set(ivar_13, ivar_17->elems[ivar_22]);
        release_matrix_array_0((matrix_array_0_t)ivar_17);
        mpq_ptr_t ivar_14;
        matrix_array_0_t ivar_25;
        uint32_t ivar_29;
        //copying to uint32 from mpz;
        ivar_29 = (uint32_t)mpz_get_ui(ivar_12);
        mpz_clear(ivar_12);
        matrix_array_0_t ivar_27;
        ivar_27 = (matrix_array_0_t)ivar_5->elems[ivar_29];
        ivar_27->count++;
        //copying to matrix_array_0 from matrix_array_0;
        ivar_25 = (matrix_array_0_t)ivar_27;
        if (ivar_25 != NULL) ivar_25->count++;
        release_matrix_array_0((matrix_array_0_t)ivar_27);
        uint32_t ivar_30;
        //copying to uint32 from mpz;
        ivar_30 = (uint32_t)mpz_get_ui(ivar_9);
        ivar_14 = safe_malloc(sizeof(mpq_t));
        mpq_init(ivar_14);
        mpq_set(ivar_14, ivar_25->elems[ivar_30]);
        release_matrix_array_0((matrix_array_0_t)ivar_25);
        mpq_mk_mul(result, ivar_13, ivar_14);
        mpq_clear(ivar_13);
        mpq_clear(ivar_14);
        return result;
}

matrix_closure_6_t new_matrix_closure_6(void){
        static struct matrix_funtype_5_ftbl_s ftbl = {.fptr = (mpq_ptr_t (*)(matrix_funtype_5_t, mpz_ptr_t))&f_matrix_closure_6, .mptr = (mpq_ptr_t (*)(matrix_funtype_5_t, mpz_ptr_t))&m_matrix_closure_6, .rptr =  (void (*)(matrix_funtype_5_t))&release_matrix_closure_6, .cptr = (matrix_funtype_5_t (*)(matrix_funtype_5_t))&copy_matrix_closure_6};
        matrix_closure_6_t tmp = (matrix_closure_6_t) safe_malloc(sizeof(struct matrix_closure_6_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        mpz_init(tmp->fvar_2);
        mpz_init(tmp->fvar_4);
        return tmp;}

void release_matrix_closure_6(matrix_funtype_5_t closure){
        matrix_closure_6_t x = (matrix_closure_6_t)closure;
        x->count--;
        if (x->count <= 0){
         release_matrix__matrix((matrix__matrix_t)x->fvar_1);
         mpz_clear(x->fvar_2);
         release_matrix__matrix((matrix__matrix_t)x->fvar_3);
         mpz_clear(x->fvar_4);
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){mpz_clear(x->htbl->data[j].key);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_6_t copy_matrix_closure_6(matrix_closure_6_t x){
        matrix_closure_6_t y = new_matrix_closure_6();
        y->ftbl = x->ftbl;

        y->fvar_1 = x->fvar_1; x->fvar_1->count++;
        mpz_set(y->fvar_2, x->fvar_2);
        y->fvar_3 = x->fvar_3; x->fvar_3->count++;
        mpz_set(y->fvar_4, x->fvar_4);
        if (x->htbl != NULL){
            matrix_funtype_5_htbl_t new_htbl = (matrix_funtype_5_htbl_t) safe_malloc(sizeof(struct matrix_funtype_5_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_5_hashentry_t * new_data = (matrix_funtype_5_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_5_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  mpz_init(new_data[j].key); mpz_set(new_data[j].key, x->htbl->data[j].key);;
                  mpq_init(new_data[j].value); mpq_set(new_data[j].value, x->htbl->data[j].value);;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}

void release_matrix_funtype_7(matrix_funtype_7_t x){
        x->count--;
            if (x->count <= 0)

                x->ftbl->rptr(x);}

matrix_funtype_7_t copy_matrix_funtype_7(matrix_funtype_7_t x){return x->ftbl->cptr(x);}

bool_t equal_matrix_funtype_7(matrix_funtype_7_t x, matrix_funtype_7_t y){
        return false;}

char* json_matrix_funtype_7(matrix_funtype_7_t x){char * result = safe_malloc(26); sprintf(result, "%s", "\"matrix_funtype_7\""); return result;}


bool_t f_matrix_closure_8(struct matrix_closure_8_s * closure, matrix__matrix_t bvar){
        uint32_t fvar_1 = closure->fvar_1;
        matrix__matrix_t fvar_2 = closure->fvar_2;
        fvar_2->count++;
        release_matrix_funtype_7((matrix_funtype_7_t)closure);
        bool_t result;
        result = (bool_t)h_matrix_closure_8(bvar, fvar_1, fvar_2);
        return result;
}

bool_t m_matrix_closure_8(struct matrix_closure_8_s * closure, matrix__matrix_t bvar){
        uint32_t fvar_1 = closure->fvar_1;
        matrix__matrix_t fvar_2 = closure->fvar_2;
        fvar_2->count++;
        release_matrix_funtype_7((matrix_funtype_7_t)closure);
        return h_matrix_closure_8(bvar, fvar_1, fvar_2);}

bool_t h_matrix_closure_8(matrix__matrix_t ivar_5, uint32_t ivar_1, matrix__matrix_t ivar_2){
        bool_t result;

        matrix__matrix_t ivar_6;
        mpz_ptr_t ivar_14;
        //copying to mpz from uint32;
        mpz_mk_set_ui(ivar_14, ivar_1);
        mpz_ptr_t ivar_15;
        //copying to mpz from uint32;
        mpz_mk_set_ui(ivar_15, ivar_1);
        mpz_ptr_t ivar_16;
        //copying to mpz from uint32;
        mpz_mk_set_ui(ivar_16, ivar_1);
        matrix__matrix_t ivar_13;
        ivar_2->count++;
        ivar_13 = (matrix__matrix_t)matrix__mmult((mpz_ptr_t)ivar_14, (mpz_ptr_t)ivar_15, (mpz_ptr_t)ivar_16, (matrix__matrix_t)ivar_2, (matrix__matrix_t)ivar_5);
        //copying to matrix__matrix from matrix__matrix;
        ivar_6 = (matrix__matrix_t)ivar_13;
        if (ivar_6 != NULL) ivar_6->count++;
        release_matrix__matrix((matrix__matrix_t)ivar_13);
        matrix__matrix_t ivar_7;
        matrix__matrix_t ivar_20;
        ivar_20 = (matrix__matrix_t)matrix__I((uint32_t)ivar_1);
        //copying to matrix__matrix from matrix__matrix;
        ivar_7 = (matrix__matrix_t)ivar_20;
        if (ivar_7 != NULL) ivar_7->count++;
        release_matrix__matrix((matrix__matrix_t)ivar_20);
        result = (bool_t) equal_matrix__matrix(ivar_6, ivar_7);
        return result;
}

matrix_closure_8_t new_matrix_closure_8(void){
        static struct matrix_funtype_7_ftbl_s ftbl = {.fptr = (bool_t (*)(matrix_funtype_7_t, matrix__matrix_t))&f_matrix_closure_8, .mptr = (bool_t (*)(matrix_funtype_7_t, matrix__matrix_t))&m_matrix_closure_8, .rptr =  (void (*)(matrix_funtype_7_t))&release_matrix_closure_8, .cptr = (matrix_funtype_7_t (*)(matrix_funtype_7_t))&copy_matrix_closure_8};
        matrix_closure_8_t tmp = (matrix_closure_8_t) safe_malloc(sizeof(struct matrix_closure_8_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_8(matrix_funtype_7_t closure){
        matrix_closure_8_t x = (matrix_closure_8_t)closure;
        x->count--;
        if (x->count <= 0){
         release_matrix__matrix((matrix__matrix_t)x->fvar_2);
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix__matrix((matrix__matrix_t)x->htbl->data[j].key);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_8_t copy_matrix_closure_8(matrix_closure_8_t x){
        matrix_closure_8_t y = new_matrix_closure_8();
        y->ftbl = x->ftbl;

        y->fvar_1 = (uint32_t)x->fvar_1;
        y->fvar_2 = x->fvar_2; x->fvar_2->count++;
        if (x->htbl != NULL){
            matrix_funtype_7_htbl_t new_htbl = (matrix_funtype_7_htbl_t) safe_malloc(sizeof(struct matrix_funtype_7_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_7_hashentry_t * new_data = (matrix_funtype_7_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_7_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix__matrix_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (bool_t)x->htbl->data[j].value;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


bool_t f_matrix_closure_9(struct matrix_closure_9_s * closure, matrix__matrix_t bvar){
        uint32_t fvar_1 = closure->fvar_1;
        matrix__matrix_t fvar_2 = closure->fvar_2;
        fvar_2->count++;
        release_matrix_funtype_7((matrix_funtype_7_t)closure);
        bool_t result;
        result = (bool_t)h_matrix_closure_9(bvar, fvar_1, fvar_2);
        return result;
}

bool_t m_matrix_closure_9(struct matrix_closure_9_s * closure, matrix__matrix_t bvar){
        uint32_t fvar_1 = closure->fvar_1;
        matrix__matrix_t fvar_2 = closure->fvar_2;
        fvar_2->count++;
        release_matrix_funtype_7((matrix_funtype_7_t)closure);
        return h_matrix_closure_9(bvar, fvar_1, fvar_2);}

bool_t h_matrix_closure_9(matrix__matrix_t ivar_5, uint32_t ivar_1, matrix__matrix_t ivar_2){
        bool_t result;

        matrix__matrix_t ivar_6;
        mpz_ptr_t ivar_14;
        //copying to mpz from uint32;
        mpz_mk_set_ui(ivar_14, ivar_1);
        mpz_ptr_t ivar_15;
        //copying to mpz from uint32;
        mpz_mk_set_ui(ivar_15, ivar_1);
        mpz_ptr_t ivar_16;
        //copying to mpz from uint32;
        mpz_mk_set_ui(ivar_16, ivar_1);
        matrix__matrix_t ivar_13;
        ivar_2->count++;
        ivar_13 = (matrix__matrix_t)matrix__mmult((mpz_ptr_t)ivar_14, (mpz_ptr_t)ivar_15, (mpz_ptr_t)ivar_16, (matrix__matrix_t)ivar_5, (matrix__matrix_t)ivar_2);
        //copying to matrix__matrix from matrix__matrix;
        ivar_6 = (matrix__matrix_t)ivar_13;
        if (ivar_6 != NULL) ivar_6->count++;
        release_matrix__matrix((matrix__matrix_t)ivar_13);
        matrix__matrix_t ivar_7;
        matrix__matrix_t ivar_20;
        ivar_20 = (matrix__matrix_t)matrix__I((uint32_t)ivar_1);
        //copying to matrix__matrix from matrix__matrix;
        ivar_7 = (matrix__matrix_t)ivar_20;
        if (ivar_7 != NULL) ivar_7->count++;
        release_matrix__matrix((matrix__matrix_t)ivar_20);
        result = (bool_t) equal_matrix__matrix(ivar_6, ivar_7);
        return result;
}

matrix_closure_9_t new_matrix_closure_9(void){
        static struct matrix_funtype_7_ftbl_s ftbl = {.fptr = (bool_t (*)(matrix_funtype_7_t, matrix__matrix_t))&f_matrix_closure_9, .mptr = (bool_t (*)(matrix_funtype_7_t, matrix__matrix_t))&m_matrix_closure_9, .rptr =  (void (*)(matrix_funtype_7_t))&release_matrix_closure_9, .cptr = (matrix_funtype_7_t (*)(matrix_funtype_7_t))&copy_matrix_closure_9};
        matrix_closure_9_t tmp = (matrix_closure_9_t) safe_malloc(sizeof(struct matrix_closure_9_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_9(matrix_funtype_7_t closure){
        matrix_closure_9_t x = (matrix_closure_9_t)closure;
        x->count--;
        if (x->count <= 0){
         release_matrix__matrix((matrix__matrix_t)x->fvar_2);
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix__matrix((matrix__matrix_t)x->htbl->data[j].key);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_9_t copy_matrix_closure_9(matrix_closure_9_t x){
        matrix_closure_9_t y = new_matrix_closure_9();
        y->ftbl = x->ftbl;

        y->fvar_1 = (uint32_t)x->fvar_1;
        y->fvar_2 = x->fvar_2; x->fvar_2->count++;
        if (x->htbl != NULL){
            matrix_funtype_7_htbl_t new_htbl = (matrix_funtype_7_htbl_t) safe_malloc(sizeof(struct matrix_funtype_7_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_7_hashentry_t * new_data = (matrix_funtype_7_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_7_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix__matrix_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (bool_t)x->htbl->data[j].value;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


bool_t f_matrix_closure_10(struct matrix_closure_10_s * closure, matrix__matrix_t bvar){
        matrix__matrix_t fvar_1 = closure->fvar_1;
        uint32_t fvar_2 = closure->fvar_2;
        fvar_1->count++;
        release_matrix_funtype_7((matrix_funtype_7_t)closure);
        bool_t result;
        result = (bool_t)h_matrix_closure_10(bvar, fvar_1, fvar_2);
        return result;
}

bool_t m_matrix_closure_10(struct matrix_closure_10_s * closure, matrix__matrix_t bvar){
        matrix__matrix_t fvar_1 = closure->fvar_1;
        uint32_t fvar_2 = closure->fvar_2;
        fvar_1->count++;
        release_matrix_funtype_7((matrix_funtype_7_t)closure);
        return h_matrix_closure_10(bvar, fvar_1, fvar_2);}

bool_t h_matrix_closure_10(matrix__matrix_t ivar_5, matrix__matrix_t ivar_2, uint32_t ivar_1){
        bool_t result;

        bool_t ivar_6;
        matrix_funtype_7_t ivar_12;
        ivar_2->count++;
        ivar_12 = (matrix_funtype_7_t)matrix__right_inverse((uint32_t)ivar_1, (matrix__matrix_t)ivar_2);
        ivar_5->count++;
        ivar_6 = (bool_t)ivar_12->ftbl->fptr(ivar_12, ivar_5);
        if (ivar_6){
             matrix_funtype_7_t ivar_24;
             ivar_2->count++;
             ivar_24 = (matrix_funtype_7_t)matrix__left_inverse((uint32_t)ivar_1, (matrix__matrix_t)ivar_2);
             result = (bool_t)ivar_24->ftbl->fptr(ivar_24, ivar_5);
        } else {
             release_matrix__matrix((matrix__matrix_t)ivar_5);
             result = (bool_t) false;};
        return result;
}

matrix_closure_10_t new_matrix_closure_10(void){
        static struct matrix_funtype_7_ftbl_s ftbl = {.fptr = (bool_t (*)(matrix_funtype_7_t, matrix__matrix_t))&f_matrix_closure_10, .mptr = (bool_t (*)(matrix_funtype_7_t, matrix__matrix_t))&m_matrix_closure_10, .rptr =  (void (*)(matrix_funtype_7_t))&release_matrix_closure_10, .cptr = (matrix_funtype_7_t (*)(matrix_funtype_7_t))&copy_matrix_closure_10};
        matrix_closure_10_t tmp = (matrix_closure_10_t) safe_malloc(sizeof(struct matrix_closure_10_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_10(matrix_funtype_7_t closure){
        matrix_closure_10_t x = (matrix_closure_10_t)closure;
        x->count--;
        if (x->count <= 0){
         release_matrix__matrix((matrix__matrix_t)x->fvar_1);
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix__matrix((matrix__matrix_t)x->htbl->data[j].key);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_10_t copy_matrix_closure_10(matrix_closure_10_t x){
        matrix_closure_10_t y = new_matrix_closure_10();
        y->ftbl = x->ftbl;

        y->fvar_1 = x->fvar_1; x->fvar_1->count++;
        y->fvar_2 = (uint32_t)x->fvar_2;
        if (x->htbl != NULL){
            matrix_funtype_7_htbl_t new_htbl = (matrix_funtype_7_htbl_t) safe_malloc(sizeof(struct matrix_funtype_7_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_7_hashentry_t * new_data = (matrix_funtype_7_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_7_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix__matrix_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (bool_t)x->htbl->data[j].value;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


matrix__matrix_t f_matrix_closure_11(struct matrix_closure_11_s * closure, matrix_record_2_t bvar){
        matrix__matrix_t bvar_1;
        bvar_1 = (matrix__matrix_t)bvar->project_1;
        bvar->project_1->count++;
        matrix__matrix_t bvar_2;
        bvar_2 = (matrix__matrix_t)bvar->project_2;
        bvar->project_2->count++;
        release_matrix_record_2((matrix_record_2_t)bvar);
        uint32_t fvar_1 = closure->fvar_1;
        release_matrix_funtype_3((matrix_funtype_3_t)closure);
        matrix__matrix_t result;
        result = (matrix__matrix_t)h_matrix_closure_11(bvar_1, bvar_2, fvar_1);
        return result;
}

matrix__matrix_t m_matrix_closure_11(struct matrix_closure_11_s * closure, matrix__matrix_t bvar_1, matrix__matrix_t bvar_2){
        uint32_t fvar_1 = closure->fvar_1;
        release_matrix_funtype_3((matrix_funtype_3_t)closure);
        return h_matrix_closure_11(bvar_1, bvar_2, fvar_1);}

matrix__matrix_t h_matrix_closure_11(matrix__matrix_t ivar_16, matrix__matrix_t ivar_17, uint32_t ivar_2){
        matrix__matrix_t result;

        uint32_t size6493;
        //copying to uint32 from uint32;
        size6493 = (uint32_t)ivar_1;
        size6493 += 0;
        result = new_matrix__matrix(size6493);
        uint32_t ivar_28;
        for (uint32_t index6488 = 0; index6488 < size6493; index6488++){
             ivar_28 = (uint32_t)index6488;
             mpz_t ivar_39;
             mpz_init(ivar_39);
             uint32_t size6492;
             size6492 = (uint32_t)(ivar_2 + ivar_3);
             size6492 += 0;
             result->elems[index6488] = new_matrix_array_0(size6492);
             for (uint32_t index6489 = 0; index6489 < size6492; index6489++){
           mpz_t ivar_39;
           mpz_init(ivar_39);
           mpz_set_ui(ivar_39, index6489);
           bool_t ivar_43;
           mpz_ptr_t ivar_66; mpz_mk_set(ivar_66, ivar_39);
           int64_t tmp6490 = mpz_cmp_ui(ivar_66, ivar_2);
           ivar_43 = (tmp6490 < 0);
           mpz_clear(ivar_66);
           if (ivar_43){
           matrix_array_0_t ivar_49;
           matrix_array_0_t ivar_51;
           ivar_51 = (matrix_array_0_t)ivar_16->elems[ivar_28];
           ivar_51->count++;
           //copying to matrix_array_0 from matrix_array_0;
           ivar_49 = (matrix_array_0_t)ivar_51;
           if (ivar_49 != NULL) ivar_49->count++;
           release_matrix_array_0((matrix_array_0_t)ivar_51);
           uint32_t ivar_54;
           //copying to uint32 from mpz;
           ivar_54 = (uint32_t)mpz_get_ui(ivar_39);
           mpz_clear(ivar_39);
           result->elems[index6488]->elems[index6489] = safe_malloc(sizeof(mpq_t));
           mpq_init(result->elems[index6488]->elems[index6489]);
           mpq_set(result->elems[index6488]->elems[index6489], ivar_49->elems[ivar_54]);
           release_matrix_array_0((matrix_array_0_t)ivar_49);
           } else {
           matrix_array_0_t ivar_60;
           matrix_array_0_t ivar_62;
           ivar_62 = (matrix_array_0_t)ivar_17->elems[ivar_28];
           ivar_62->count++;
           //copying to matrix_array_0 from matrix_array_0;
           ivar_60 = (matrix_array_0_t)ivar_62;
           if (ivar_60 != NULL) ivar_60->count++;
           release_matrix_array_0((matrix_array_0_t)ivar_62);
           uint32_t ivar_65;
           mpz_t tmp6491;
           mpz_init(tmp6491);
           mpz_sub_ui(tmp6491, ivar_39, ivar_2);
           ivar_65 = (uint32_t) mpz_get_ui(tmp6491);
           mpz_clear(tmp6491);
           mpz_clear(ivar_39);
           result->elems[index6488]->elems[index6489] = safe_malloc(sizeof(mpq_t));
           mpq_init(result->elems[index6488]->elems[index6489]);
           mpq_set(result->elems[index6488]->elems[index6489], ivar_60->elems[ivar_65]);
           release_matrix_array_0((matrix_array_0_t)ivar_60);};
             };
        };
        release_matrix__matrix((matrix__matrix_t)ivar_16);
        release_matrix__matrix((matrix__matrix_t)ivar_17);
        return result;
}

matrix_closure_11_t new_matrix_closure_11(void){
        static struct matrix_funtype_3_ftbl_s ftbl = {.fptr = (matrix__matrix_t (*)(matrix_funtype_3_t, matrix_record_2_t))&f_matrix_closure_11, .mptr = (matrix__matrix_t (*)(matrix_funtype_3_t, matrix__matrix_t, matrix__matrix_t))&m_matrix_closure_11, .rptr =  (void (*)(matrix_funtype_3_t))&release_matrix_closure_11, .cptr = (matrix_funtype_3_t (*)(matrix_funtype_3_t))&copy_matrix_closure_11};
        matrix_closure_11_t tmp = (matrix_closure_11_t) safe_malloc(sizeof(struct matrix_closure_11_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_11(matrix_funtype_3_t closure){
        matrix_closure_11_t x = (matrix_closure_11_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix_record_2((matrix_record_2_t)x->htbl->data[j].key); release_matrix__matrix((matrix__matrix_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_11_t copy_matrix_closure_11(matrix_closure_11_t x){
        matrix_closure_11_t y = new_matrix_closure_11();
        y->ftbl = x->ftbl;

        y->fvar_1 = (uint32_t)x->fvar_1;
        if (x->htbl != NULL){
            matrix_funtype_3_htbl_t new_htbl = (matrix_funtype_3_htbl_t) safe_malloc(sizeof(struct matrix_funtype_3_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_3_hashentry_t * new_data = (matrix_funtype_3_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_3_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix_record_2_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (matrix__matrix_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


matrix__matrix_t f_matrix_closure_12(struct matrix_closure_12_s * closure, matrix_record_2_t bvar){
        matrix__matrix_t bvar_1;
        bvar_1 = (matrix__matrix_t)bvar->project_1;
        bvar->project_1->count++;
        matrix__matrix_t bvar_2;
        bvar_2 = (matrix__matrix_t)bvar->project_2;
        bvar->project_2->count++;
        release_matrix_record_2((matrix_record_2_t)bvar);
        uint32_t fvar_1 = closure->fvar_1;
        release_matrix_funtype_3((matrix_funtype_3_t)closure);
        matrix__matrix_t result;
        result = (matrix__matrix_t)h_matrix_closure_12(bvar_1, bvar_2, fvar_1);
        return result;
}

matrix__matrix_t m_matrix_closure_12(struct matrix_closure_12_s * closure, matrix__matrix_t bvar_1, matrix__matrix_t bvar_2){
        uint32_t fvar_1 = closure->fvar_1;
        release_matrix_funtype_3((matrix_funtype_3_t)closure);
        return h_matrix_closure_12(bvar_1, bvar_2, fvar_1);}

matrix__matrix_t h_matrix_closure_12(matrix__matrix_t ivar_13, matrix__matrix_t ivar_14, uint32_t ivar_1){
        matrix__matrix_t result;

        mpz_t ivar_25;
        mpz_init(ivar_25);
        uint32_t size6502;
        size6502 = (uint32_t)(ivar_1 + ivar_2);
        size6502 += 0;
        result = new_matrix__matrix(size6502);
        for (uint32_t index6499 = 0; index6499 < size6502; index6499++){
             mpz_t ivar_25;
             mpz_init(ivar_25);
             mpz_set_ui(ivar_25, index6499);
             bool_t ivar_29;
             mpz_ptr_t ivar_44; mpz_mk_set(ivar_44, ivar_25);
             int64_t tmp6500 = mpz_cmp_ui(ivar_44, ivar_1);
             ivar_29 = (tmp6500 < 0);
             mpz_clear(ivar_44);
             if (ivar_29){
           uint32_t ivar_36;
           //copying to uint32 from mpz;
           ivar_36 = (uint32_t)mpz_get_ui(ivar_25);
           mpz_clear(ivar_25);
           matrix_array_0_t ivar_34;
           ivar_34 = (matrix_array_0_t)ivar_13->elems[ivar_36];
           ivar_34->count++;
           //copying to matrix_array_0 from matrix_array_0;
           result->elems[index6499] = (matrix_array_0_t)ivar_34;
           if (result->elems[index6499] != NULL) result->elems[index6499]->count++;
           release_matrix_array_0((matrix_array_0_t)ivar_34);
             } else {
           uint32_t ivar_43;
           mpz_t tmp6501;
           mpz_init(tmp6501);
           mpz_sub_ui(tmp6501, ivar_25, ivar_1);
           ivar_43 = (uint32_t) mpz_get_ui(tmp6501);
           mpz_clear(tmp6501);
           mpz_clear(ivar_25);
           matrix_array_0_t ivar_41;
           ivar_41 = (matrix_array_0_t)ivar_14->elems[ivar_43];
           ivar_41->count++;
           //copying to matrix_array_0 from matrix_array_0;
           result->elems[index6499] = (matrix_array_0_t)ivar_41;
           if (result->elems[index6499] != NULL) result->elems[index6499]->count++;
           release_matrix_array_0((matrix_array_0_t)ivar_41);};
        };
        release_matrix__matrix((matrix__matrix_t)ivar_13);
        release_matrix__matrix((matrix__matrix_t)ivar_14);
        return result;
}

matrix_closure_12_t new_matrix_closure_12(void){
        static struct matrix_funtype_3_ftbl_s ftbl = {.fptr = (matrix__matrix_t (*)(matrix_funtype_3_t, matrix_record_2_t))&f_matrix_closure_12, .mptr = (matrix__matrix_t (*)(matrix_funtype_3_t, matrix__matrix_t, matrix__matrix_t))&m_matrix_closure_12, .rptr =  (void (*)(matrix_funtype_3_t))&release_matrix_closure_12, .cptr = (matrix_funtype_3_t (*)(matrix_funtype_3_t))&copy_matrix_closure_12};
        matrix_closure_12_t tmp = (matrix_closure_12_t) safe_malloc(sizeof(struct matrix_closure_12_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_12(matrix_funtype_3_t closure){
        matrix_closure_12_t x = (matrix_closure_12_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix_record_2((matrix_record_2_t)x->htbl->data[j].key); release_matrix__matrix((matrix__matrix_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_12_t copy_matrix_closure_12(matrix_closure_12_t x){
        matrix_closure_12_t y = new_matrix_closure_12();
        y->ftbl = x->ftbl;

        y->fvar_1 = (uint32_t)x->fvar_1;
        if (x->htbl != NULL){
            matrix_funtype_3_htbl_t new_htbl = (matrix_funtype_3_htbl_t) safe_malloc(sizeof(struct matrix_funtype_3_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_3_hashentry_t * new_data = (matrix_funtype_3_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_3_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix_record_2_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (matrix__matrix_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


matrix_record_13_t new_matrix_record_13(void){
        matrix_record_13_t tmp = (matrix_record_13_t) safe_malloc(sizeof(struct matrix_record_13_s));
        tmp->count = 1;
        return tmp;}

void release_matrix_record_13(matrix_record_13_t x){
        x->count--;
        if (x->count <= 0){
        //printf("\nFreeing\n");
        safe_free(x);}}

void release_matrix_record_13_ptr(pointer_t x, type_actual_t T){
        release_matrix_record_13((matrix_record_13_t)x);
}

matrix_record_13_t copy_matrix_record_13(matrix_record_13_t x){
        matrix_record_13_t y = new_matrix_record_13();
        y->project_1 = (uint32_t)x->project_1;
        y->project_2 = (uint32_t)x->project_2;
        y->count = 1;
        return y;}

bool_t equal_matrix_record_13(matrix_record_13_t x, matrix_record_13_t y){
        bool_t tmp = true; tmp = tmp && x->project_1 == y->project_1; tmp = tmp && x->project_2 == y->project_2;
        return tmp;}

char * json_matrix_record_13(matrix_record_13_t x){
        char * tmp[2]; 
        char * fld0 = safe_malloc(21);
         sprintf(fld0, "\"project_1\" : ");
        tmp[0] = safe_strcat(fld0, json_uint32(x->project_1));
        char * fld1 = safe_malloc(21);
         sprintf(fld1, "\"project_2\" : ");
        tmp[1] = safe_strcat(fld1, json_uint32(x->project_2));
         char * result = json_list_with_sep(tmp, 2,  '{', ',', '}');
         for (uint32_t i = 0; i < 2; i++) free(tmp[i]);
        return result;}

bool_t equal_matrix_record_13_ptr(pointer_t x, pointer_t y, actual_matrix_record_13_t T){
        return equal_matrix_record_13((matrix_record_13_t)x, (matrix_record_13_t)y);
}

char * json_matrix_record_13_ptr(pointer_t x, actual_matrix_record_13_t T){
        return json_matrix_record_13((matrix_record_13_t)x);
}

actual_matrix_record_13_t actual_matrix_record_13(void){
        actual_matrix_record_13_t new = (actual_matrix_record_13_t)safe_malloc(sizeof(struct actual_matrix_record_13_s));
        new->equal_ptr = (equal_ptr_t)(*equal_matrix_record_13_ptr);
 
        new->release_ptr = (release_ptr_t)(*release_matrix_record_13_ptr);
 
        new->json_ptr = (json_ptr_t)(*json_matrix_record_13_ptr);
 

 
        return new;
 }

matrix_record_13_t update_matrix_record_13_project_1(matrix_record_13_t x, uint32_t v){
        matrix_record_13_t y;
        if (x->count == 1){y = x;}
        else {y = copy_matrix_record_13(x); x->count--;};
        y->project_1 = (uint32_t)v;
        return y;}

matrix_record_13_t update_matrix_record_13_project_2(matrix_record_13_t x, uint32_t v){
        matrix_record_13_t y;
        if (x->count == 1){y = x;}
        else {y = copy_matrix_record_13(x); x->count--;};
        y->project_2 = (uint32_t)v;
        return y;}



void release_matrix_funtype_14(matrix_funtype_14_t x){
        x->count--;
            if (x->count <= 0)

                x->ftbl->rptr(x);}

matrix_funtype_14_t copy_matrix_funtype_14(matrix_funtype_14_t x){return x->ftbl->cptr(x);}

bool_t equal_matrix_funtype_14(matrix_funtype_14_t x, matrix_funtype_14_t y){
        return false;}

char* json_matrix_funtype_14(matrix_funtype_14_t x){char * result = safe_malloc(27); sprintf(result, "%s", "\"matrix_funtype_14\""); return result;}

void release_matrix_funtype_15(matrix_funtype_15_t x){
        x->count--;
            if (x->count <= 0)

                x->ftbl->rptr(x);}

matrix_funtype_15_t copy_matrix_funtype_15(matrix_funtype_15_t x){return x->ftbl->cptr(x);}

bool_t equal_matrix_funtype_15(matrix_funtype_15_t x, matrix_funtype_15_t y){
        return false;}

char* json_matrix_funtype_15(matrix_funtype_15_t x){char * result = safe_malloc(27); sprintf(result, "%s", "\"matrix_funtype_15\""); return result;}


matrix_funtype_14_t f_matrix_closure_16(struct matrix_closure_16_s * closure, matrix_record_13_t bvar){
        uint32_t bvar_1;
        bvar_1 = (uint32_t)bvar->project_1;
        uint32_t bvar_2;
        bvar_2 = (uint32_t)bvar->project_2;
        release_matrix_record_13((matrix_record_13_t)bvar);
        release_matrix_funtype_15((matrix_funtype_15_t)closure);
        matrix_funtype_14_t result;
        result = (matrix_funtype_14_t)h_matrix_closure_16(bvar_1, bvar_2);
        return result;
}

matrix_funtype_14_t m_matrix_closure_16(struct matrix_closure_16_s * closure, uint32_t bvar_1, uint32_t bvar_2){
        release_matrix_funtype_15((matrix_funtype_15_t)closure);
        return h_matrix_closure_16(bvar_1, bvar_2);}

matrix_funtype_14_t h_matrix_closure_16(uint32_t ivar_12, uint32_t ivar_13){
        matrix_funtype_14_t result;

        matrix_closure_17_t cl6521;
        cl6521 = new_matrix_closure_17();
        result = (matrix_funtype_14_t)cl6521;
        return result;
}

matrix_closure_16_t new_matrix_closure_16(void){
        static struct matrix_funtype_15_ftbl_s ftbl = {.fptr = (matrix_funtype_14_t (*)(matrix_funtype_15_t, matrix_record_13_t))&f_matrix_closure_16, .mptr = (matrix_funtype_14_t (*)(matrix_funtype_15_t, uint32_t, uint32_t))&m_matrix_closure_16, .rptr =  (void (*)(matrix_funtype_15_t))&release_matrix_closure_16, .cptr = (matrix_funtype_15_t (*)(matrix_funtype_15_t))&copy_matrix_closure_16};
        matrix_closure_16_t tmp = (matrix_closure_16_t) safe_malloc(sizeof(struct matrix_closure_16_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_16(matrix_funtype_15_t closure){
        matrix_closure_16_t x = (matrix_closure_16_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix_record_13((matrix_record_13_t)x->htbl->data[j].key); release_matrix_funtype_14((matrix_funtype_14_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_16_t copy_matrix_closure_16(matrix_closure_16_t x){
        matrix_closure_16_t y = new_matrix_closure_16();
        y->ftbl = x->ftbl;

        if (x->htbl != NULL){
            matrix_funtype_15_htbl_t new_htbl = (matrix_funtype_15_htbl_t) safe_malloc(sizeof(struct matrix_funtype_15_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_15_hashentry_t * new_data = (matrix_funtype_15_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_15_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix_record_13_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (matrix_funtype_14_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


matrix__matrix_t f_matrix_closure_17(struct matrix_closure_17_s * closure, matrix__matrix_t bvar){
        release_matrix_funtype_14((matrix_funtype_14_t)closure);
        matrix__matrix_t result;
        result = (matrix__matrix_t)h_matrix_closure_17(bvar);
        return result;
}

matrix__matrix_t m_matrix_closure_17(struct matrix_closure_17_s * closure, matrix__matrix_t bvar){
        release_matrix_funtype_14((matrix_funtype_14_t)closure);
        return h_matrix_closure_17(bvar);}

matrix__matrix_t h_matrix_closure_17(matrix__matrix_t ivar_16){
        matrix__matrix_t result;

        uint32_t size6520;
        //copying to uint32 from uint32;
        size6520 = (uint32_t)ivar_10;
        size6520 += 0;
        result = new_matrix__matrix(size6520);
        uint32_t ivar_18;
        for (uint32_t index6519 = 0; index6519 < size6520; index6519++){
             ivar_18 = (uint32_t)index6519;
             matrix_array_0_t ivar_22;
             ivar_22 = (matrix_array_0_t)ivar_16->elems[ivar_18];
             ivar_22->count++;
             //copying to matrix_array_0 from matrix_array_0;
             result->elems[index6519] = (matrix_array_0_t)ivar_22;
             if (result->elems[index6519] != NULL) result->elems[index6519]->count++;
             release_matrix_array_0((matrix_array_0_t)ivar_22);
        };
        release_matrix__matrix((matrix__matrix_t)ivar_16);
        return result;
}

matrix_closure_17_t new_matrix_closure_17(void){
        static struct matrix_funtype_14_ftbl_s ftbl = {.fptr = (matrix__matrix_t (*)(matrix_funtype_14_t, matrix__matrix_t))&f_matrix_closure_17, .mptr = (matrix__matrix_t (*)(matrix_funtype_14_t, matrix__matrix_t))&m_matrix_closure_17, .rptr =  (void (*)(matrix_funtype_14_t))&release_matrix_closure_17, .cptr = (matrix_funtype_14_t (*)(matrix_funtype_14_t))&copy_matrix_closure_17};
        matrix_closure_17_t tmp = (matrix_closure_17_t) safe_malloc(sizeof(struct matrix_closure_17_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_17(matrix_funtype_14_t closure){
        matrix_closure_17_t x = (matrix_closure_17_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix__matrix((matrix__matrix_t)x->htbl->data[j].key); release_matrix__matrix((matrix__matrix_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_17_t copy_matrix_closure_17(matrix_closure_17_t x){
        matrix_closure_17_t y = new_matrix_closure_17();
        y->ftbl = x->ftbl;

        if (x->htbl != NULL){
            matrix_funtype_14_htbl_t new_htbl = (matrix_funtype_14_htbl_t) safe_malloc(sizeof(struct matrix_funtype_14_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_14_hashentry_t * new_data = (matrix_funtype_14_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_14_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix__matrix_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (matrix__matrix_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


matrix_funtype_14_t f_matrix_closure_18(struct matrix_closure_18_s * closure, matrix_record_13_t bvar){
        uint32_t bvar_1;
        bvar_1 = (uint32_t)bvar->project_1;
        uint32_t bvar_2;
        bvar_2 = (uint32_t)bvar->project_2;
        release_matrix_record_13((matrix_record_13_t)bvar);
        release_matrix_funtype_15((matrix_funtype_15_t)closure);
        matrix_funtype_14_t result;
        result = (matrix_funtype_14_t)h_matrix_closure_18(bvar_1, bvar_2);
        return result;
}

matrix_funtype_14_t m_matrix_closure_18(struct matrix_closure_18_s * closure, uint32_t bvar_1, uint32_t bvar_2){
        release_matrix_funtype_15((matrix_funtype_15_t)closure);
        return h_matrix_closure_18(bvar_1, bvar_2);}

matrix_funtype_14_t h_matrix_closure_18(uint32_t ivar_21, uint32_t ivar_22){
        matrix_funtype_14_t result;

        matrix_closure_19_t cl6543;
        cl6543 = new_matrix_closure_19();
        cl6543->fvar_1 = (uint32_t)ivar_22;
        result = (matrix_funtype_14_t)cl6543;
        return result;
}

matrix_closure_18_t new_matrix_closure_18(void){
        static struct matrix_funtype_15_ftbl_s ftbl = {.fptr = (matrix_funtype_14_t (*)(matrix_funtype_15_t, matrix_record_13_t))&f_matrix_closure_18, .mptr = (matrix_funtype_14_t (*)(matrix_funtype_15_t, uint32_t, uint32_t))&m_matrix_closure_18, .rptr =  (void (*)(matrix_funtype_15_t))&release_matrix_closure_18, .cptr = (matrix_funtype_15_t (*)(matrix_funtype_15_t))&copy_matrix_closure_18};
        matrix_closure_18_t tmp = (matrix_closure_18_t) safe_malloc(sizeof(struct matrix_closure_18_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_18(matrix_funtype_15_t closure){
        matrix_closure_18_t x = (matrix_closure_18_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix_record_13((matrix_record_13_t)x->htbl->data[j].key); release_matrix_funtype_14((matrix_funtype_14_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_18_t copy_matrix_closure_18(matrix_closure_18_t x){
        matrix_closure_18_t y = new_matrix_closure_18();
        y->ftbl = x->ftbl;

        if (x->htbl != NULL){
            matrix_funtype_15_htbl_t new_htbl = (matrix_funtype_15_htbl_t) safe_malloc(sizeof(struct matrix_funtype_15_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_15_hashentry_t * new_data = (matrix_funtype_15_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_15_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix_record_13_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (matrix_funtype_14_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


matrix__matrix_t f_matrix_closure_19(struct matrix_closure_19_s * closure, matrix__matrix_t bvar){
        uint32_t fvar_1 = closure->fvar_1;
        release_matrix_funtype_14((matrix_funtype_14_t)closure);
        matrix__matrix_t result;
        result = (matrix__matrix_t)h_matrix_closure_19(bvar, fvar_1);
        return result;
}

matrix__matrix_t m_matrix_closure_19(struct matrix_closure_19_s * closure, matrix__matrix_t bvar){
        uint32_t fvar_1 = closure->fvar_1;
        release_matrix_funtype_14((matrix_funtype_14_t)closure);
        return h_matrix_closure_19(bvar, fvar_1);}

matrix__matrix_t h_matrix_closure_19(matrix__matrix_t ivar_34, uint32_t ivar_22){
        matrix__matrix_t result;

        uint32_t size6542;
        //copying to uint32 from uint32;
        size6542 = (uint32_t)ivar_19;
        size6542 += 0;
        result = new_matrix__matrix(size6542);
        uint32_t ivar_45;
        for (uint32_t index6538 = 0; index6538 < size6542; index6538++){
             ivar_45 = (uint32_t)index6538;
             mpz_t ivar_56;
             mpz_init(ivar_56);
             uint32_t size6541;
             size6541 = (uint32_t)(ivar_2 - ivar_22);
             size6541 += 0;
             result->elems[index6538] = new_matrix_array_0(size6541);
             for (uint32_t index6539 = 0; index6539 < size6541; index6539++){
           mpz_t ivar_56;
           mpz_init(ivar_56);
           mpz_set_ui(ivar_56, index6539);
           matrix_array_0_t ivar_65;
           matrix_array_0_t ivar_67;
           ivar_67 = (matrix_array_0_t)ivar_34->elems[ivar_45];
           ivar_67->count++;
           //copying to matrix_array_0 from matrix_array_0;
           ivar_65 = (matrix_array_0_t)ivar_67;
           if (ivar_65 != NULL) ivar_65->count++;
           release_matrix_array_0((matrix_array_0_t)ivar_67);
           uint32_t ivar_70;
           mpz_t tmp6540;
           mpz_init(tmp6540);
           mpz_add_ui(tmp6540, ivar_56, ivar_22);
           ivar_70 = (uint32_t)mpz_get_ui(tmp6540);
           mpz_clear(tmp6540);
           mpz_clear(ivar_56);
           result->elems[index6538]->elems[index6539] = safe_malloc(sizeof(mpq_t));
           mpq_init(result->elems[index6538]->elems[index6539]);
           mpq_set(result->elems[index6538]->elems[index6539], ivar_65->elems[ivar_70]);
           release_matrix_array_0((matrix_array_0_t)ivar_65);
             };
        };
        release_matrix__matrix((matrix__matrix_t)ivar_34);
        return result;
}

matrix_closure_19_t new_matrix_closure_19(void){
        static struct matrix_funtype_14_ftbl_s ftbl = {.fptr = (matrix__matrix_t (*)(matrix_funtype_14_t, matrix__matrix_t))&f_matrix_closure_19, .mptr = (matrix__matrix_t (*)(matrix_funtype_14_t, matrix__matrix_t))&m_matrix_closure_19, .rptr =  (void (*)(matrix_funtype_14_t))&release_matrix_closure_19, .cptr = (matrix_funtype_14_t (*)(matrix_funtype_14_t))&copy_matrix_closure_19};
        matrix_closure_19_t tmp = (matrix_closure_19_t) safe_malloc(sizeof(struct matrix_closure_19_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_19(matrix_funtype_14_t closure){
        matrix_closure_19_t x = (matrix_closure_19_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix__matrix((matrix__matrix_t)x->htbl->data[j].key); release_matrix__matrix((matrix__matrix_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_19_t copy_matrix_closure_19(matrix_closure_19_t x){
        matrix_closure_19_t y = new_matrix_closure_19();
        y->ftbl = x->ftbl;

        y->fvar_1 = (uint32_t)x->fvar_1;
        if (x->htbl != NULL){
            matrix_funtype_14_htbl_t new_htbl = (matrix_funtype_14_htbl_t) safe_malloc(sizeof(struct matrix_funtype_14_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_14_hashentry_t * new_data = (matrix_funtype_14_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_14_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix__matrix_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (matrix__matrix_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


matrix_funtype_14_t f_matrix_closure_20(struct matrix_closure_20_s * closure, matrix_record_13_t bvar){
        uint32_t bvar_1;
        bvar_1 = (uint32_t)bvar->project_1;
        uint32_t bvar_2;
        bvar_2 = (uint32_t)bvar->project_2;
        release_matrix_record_13((matrix_record_13_t)bvar);
        release_matrix_funtype_15((matrix_funtype_15_t)closure);
        matrix_funtype_14_t result;
        result = (matrix_funtype_14_t)h_matrix_closure_20(bvar_1, bvar_2);
        return result;
}

matrix_funtype_14_t m_matrix_closure_20(struct matrix_closure_20_s * closure, uint32_t bvar_1, uint32_t bvar_2){
        release_matrix_funtype_15((matrix_funtype_15_t)closure);
        return h_matrix_closure_20(bvar_1, bvar_2);}

matrix_funtype_14_t h_matrix_closure_20(uint32_t ivar_18, uint32_t ivar_19){
        matrix_funtype_14_t result;

        matrix_closure_21_t cl6563;
        cl6563 = new_matrix_closure_21();
        cl6563->fvar_1 = (uint32_t)ivar_18;
        result = (matrix_funtype_14_t)cl6563;
        return result;
}

matrix_closure_20_t new_matrix_closure_20(void){
        static struct matrix_funtype_15_ftbl_s ftbl = {.fptr = (matrix_funtype_14_t (*)(matrix_funtype_15_t, matrix_record_13_t))&f_matrix_closure_20, .mptr = (matrix_funtype_14_t (*)(matrix_funtype_15_t, uint32_t, uint32_t))&m_matrix_closure_20, .rptr =  (void (*)(matrix_funtype_15_t))&release_matrix_closure_20, .cptr = (matrix_funtype_15_t (*)(matrix_funtype_15_t))&copy_matrix_closure_20};
        matrix_closure_20_t tmp = (matrix_closure_20_t) safe_malloc(sizeof(struct matrix_closure_20_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_20(matrix_funtype_15_t closure){
        matrix_closure_20_t x = (matrix_closure_20_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix_record_13((matrix_record_13_t)x->htbl->data[j].key); release_matrix_funtype_14((matrix_funtype_14_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_20_t copy_matrix_closure_20(matrix_closure_20_t x){
        matrix_closure_20_t y = new_matrix_closure_20();
        y->ftbl = x->ftbl;

        if (x->htbl != NULL){
            matrix_funtype_15_htbl_t new_htbl = (matrix_funtype_15_htbl_t) safe_malloc(sizeof(struct matrix_funtype_15_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_15_hashentry_t * new_data = (matrix_funtype_15_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_15_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix_record_13_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (matrix_funtype_14_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


matrix__matrix_t f_matrix_closure_21(struct matrix_closure_21_s * closure, matrix__matrix_t bvar){
        uint32_t fvar_1 = closure->fvar_1;
        release_matrix_funtype_14((matrix_funtype_14_t)closure);
        matrix__matrix_t result;
        result = (matrix__matrix_t)h_matrix_closure_21(bvar, fvar_1);
        return result;
}

matrix__matrix_t m_matrix_closure_21(struct matrix_closure_21_s * closure, matrix__matrix_t bvar){
        uint32_t fvar_1 = closure->fvar_1;
        release_matrix_funtype_14((matrix_funtype_14_t)closure);
        return h_matrix_closure_21(bvar, fvar_1);}

matrix__matrix_t h_matrix_closure_21(matrix__matrix_t ivar_28, uint32_t ivar_18){
        matrix__matrix_t result;

        mpz_t ivar_39;
        mpz_init(ivar_39);
        uint32_t size6562;
        size6562 = (uint32_t)(ivar_1 - ivar_18);
        size6562 += 0;
        result = new_matrix__matrix(size6562);
        for (uint32_t index6560 = 0; index6560 < size6562; index6560++){
             mpz_t ivar_39;
             mpz_init(ivar_39);
             mpz_set_ui(ivar_39, index6560);
             uint32_t ivar_51;
             mpz_t tmp6561;
             mpz_init(tmp6561);
             mpz_add_ui(tmp6561, ivar_39, ivar_18);
             ivar_51 = (uint32_t)mpz_get_ui(tmp6561);
             mpz_clear(tmp6561);
             mpz_clear(ivar_39);
             matrix_array_0_t ivar_49;
             ivar_49 = (matrix_array_0_t)ivar_28->elems[ivar_51];
             ivar_49->count++;
             //copying to matrix_array_0 from matrix_array_0;
             result->elems[index6560] = (matrix_array_0_t)ivar_49;
             if (result->elems[index6560] != NULL) result->elems[index6560]->count++;
             release_matrix_array_0((matrix_array_0_t)ivar_49);
        };
        release_matrix__matrix((matrix__matrix_t)ivar_28);
        return result;
}

matrix_closure_21_t new_matrix_closure_21(void){
        static struct matrix_funtype_14_ftbl_s ftbl = {.fptr = (matrix__matrix_t (*)(matrix_funtype_14_t, matrix__matrix_t))&f_matrix_closure_21, .mptr = (matrix__matrix_t (*)(matrix_funtype_14_t, matrix__matrix_t))&m_matrix_closure_21, .rptr =  (void (*)(matrix_funtype_14_t))&release_matrix_closure_21, .cptr = (matrix_funtype_14_t (*)(matrix_funtype_14_t))&copy_matrix_closure_21};
        matrix_closure_21_t tmp = (matrix_closure_21_t) safe_malloc(sizeof(struct matrix_closure_21_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_21(matrix_funtype_14_t closure){
        matrix_closure_21_t x = (matrix_closure_21_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix__matrix((matrix__matrix_t)x->htbl->data[j].key); release_matrix__matrix((matrix__matrix_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_21_t copy_matrix_closure_21(matrix_closure_21_t x){
        matrix_closure_21_t y = new_matrix_closure_21();
        y->ftbl = x->ftbl;

        y->fvar_1 = (uint32_t)x->fvar_1;
        if (x->htbl != NULL){
            matrix_funtype_14_htbl_t new_htbl = (matrix_funtype_14_htbl_t) safe_malloc(sizeof(struct matrix_funtype_14_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_14_hashentry_t * new_data = (matrix_funtype_14_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_14_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix__matrix_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (matrix__matrix_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


matrix_funtype_14_t f_matrix_closure_22(struct matrix_closure_22_s * closure, matrix_record_13_t bvar){
        uint32_t bvar_1;
        bvar_1 = (uint32_t)bvar->project_1;
        uint32_t bvar_2;
        bvar_2 = (uint32_t)bvar->project_2;
        release_matrix_record_13((matrix_record_13_t)bvar);
        release_matrix_funtype_15((matrix_funtype_15_t)closure);
        matrix_funtype_14_t result;
        result = (matrix_funtype_14_t)h_matrix_closure_22(bvar_1, bvar_2);
        return result;
}

matrix_funtype_14_t m_matrix_closure_22(struct matrix_closure_22_s * closure, uint32_t bvar_1, uint32_t bvar_2){
        release_matrix_funtype_15((matrix_funtype_15_t)closure);
        return h_matrix_closure_22(bvar_1, bvar_2);}

matrix_funtype_14_t h_matrix_closure_22(uint32_t ivar_27, uint32_t ivar_28){
        matrix_funtype_14_t result;

        matrix_closure_23_t cl6586;
        cl6586 = new_matrix_closure_23();
        cl6586->fvar_1 = (uint32_t)ivar_28;
        cl6586->fvar_2 = (uint32_t)ivar_27;
        result = (matrix_funtype_14_t)cl6586;
        return result;
}

matrix_closure_22_t new_matrix_closure_22(void){
        static struct matrix_funtype_15_ftbl_s ftbl = {.fptr = (matrix_funtype_14_t (*)(matrix_funtype_15_t, matrix_record_13_t))&f_matrix_closure_22, .mptr = (matrix_funtype_14_t (*)(matrix_funtype_15_t, uint32_t, uint32_t))&m_matrix_closure_22, .rptr =  (void (*)(matrix_funtype_15_t))&release_matrix_closure_22, .cptr = (matrix_funtype_15_t (*)(matrix_funtype_15_t))&copy_matrix_closure_22};
        matrix_closure_22_t tmp = (matrix_closure_22_t) safe_malloc(sizeof(struct matrix_closure_22_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_22(matrix_funtype_15_t closure){
        matrix_closure_22_t x = (matrix_closure_22_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix_record_13((matrix_record_13_t)x->htbl->data[j].key); release_matrix_funtype_14((matrix_funtype_14_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_22_t copy_matrix_closure_22(matrix_closure_22_t x){
        matrix_closure_22_t y = new_matrix_closure_22();
        y->ftbl = x->ftbl;

        if (x->htbl != NULL){
            matrix_funtype_15_htbl_t new_htbl = (matrix_funtype_15_htbl_t) safe_malloc(sizeof(struct matrix_funtype_15_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_15_hashentry_t * new_data = (matrix_funtype_15_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_15_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix_record_13_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (matrix_funtype_14_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


matrix__matrix_t f_matrix_closure_23(struct matrix_closure_23_s * closure, matrix__matrix_t bvar){
        uint32_t fvar_1 = closure->fvar_1;
        uint32_t fvar_2 = closure->fvar_2;
        release_matrix_funtype_14((matrix_funtype_14_t)closure);
        matrix__matrix_t result;
        result = (matrix__matrix_t)h_matrix_closure_23(bvar, fvar_1, fvar_2);
        return result;
}

matrix__matrix_t m_matrix_closure_23(struct matrix_closure_23_s * closure, matrix__matrix_t bvar){
        uint32_t fvar_1 = closure->fvar_1;
        uint32_t fvar_2 = closure->fvar_2;
        release_matrix_funtype_14((matrix_funtype_14_t)closure);
        return h_matrix_closure_23(bvar, fvar_1, fvar_2);}

matrix__matrix_t h_matrix_closure_23(matrix__matrix_t ivar_46, uint32_t ivar_28, uint32_t ivar_27){
        matrix__matrix_t result;

        mpz_t ivar_66;
        mpz_init(ivar_66);
        uint32_t size6585;
        size6585 = (uint32_t)(ivar_1 - ivar_27);
        size6585 += 0;
        result = new_matrix__matrix(size6585);
        for (uint32_t index6580 = 0; index6580 < size6585; index6580++){
             mpz_t ivar_66;
             mpz_init(ivar_66);
             mpz_set_ui(ivar_66, index6580);
             mpz_t ivar_80;
             mpz_init(ivar_80);
             uint32_t size6584;
             size6584 = (uint32_t)(ivar_2 - ivar_28);
             size6584 += 0;
             result->elems[index6580] = new_matrix_array_0(size6584);
             for (uint32_t index6581 = 0; index6581 < size6584; index6581++){
           mpz_t ivar_80;
           mpz_init(ivar_80);
           mpz_set_ui(ivar_80, index6581);
           matrix_array_0_t ivar_89;
           uint32_t ivar_96;
           mpz_ptr_t ivar_98; mpz_mk_set(ivar_98, ivar_66);
           mpz_t tmp6582;
           mpz_init(tmp6582);
           mpz_add_ui(tmp6582, ivar_98, ivar_27);
           ivar_96 = (uint32_t)mpz_get_ui(tmp6582);
           mpz_clear(tmp6582);
           mpz_clear(ivar_98);
           matrix_array_0_t ivar_94;
           ivar_94 = (matrix_array_0_t)ivar_46->elems[ivar_96];
           ivar_94->count++;
           //copying to matrix_array_0 from matrix_array_0;
           ivar_89 = (matrix_array_0_t)ivar_94;
           if (ivar_89 != NULL) ivar_89->count++;
           release_matrix_array_0((matrix_array_0_t)ivar_94);
           uint32_t ivar_97;
           mpz_t tmp6583;
           mpz_init(tmp6583);
           mpz_add_ui(tmp6583, ivar_80, ivar_28);
           ivar_97 = (uint32_t)mpz_get_ui(tmp6583);
           mpz_clear(tmp6583);
           mpz_clear(ivar_80);
           result->elems[index6580]->elems[index6581] = safe_malloc(sizeof(mpq_t));
           mpq_init(result->elems[index6580]->elems[index6581]);
           mpq_set(result->elems[index6580]->elems[index6581], ivar_89->elems[ivar_97]);
           release_matrix_array_0((matrix_array_0_t)ivar_89);
             };
             mpz_clear(ivar_66);
        };
        release_matrix__matrix((matrix__matrix_t)ivar_46);
        return result;
}

matrix_closure_23_t new_matrix_closure_23(void){
        static struct matrix_funtype_14_ftbl_s ftbl = {.fptr = (matrix__matrix_t (*)(matrix_funtype_14_t, matrix__matrix_t))&f_matrix_closure_23, .mptr = (matrix__matrix_t (*)(matrix_funtype_14_t, matrix__matrix_t))&m_matrix_closure_23, .rptr =  (void (*)(matrix_funtype_14_t))&release_matrix_closure_23, .cptr = (matrix_funtype_14_t (*)(matrix_funtype_14_t))&copy_matrix_closure_23};
        matrix_closure_23_t tmp = (matrix_closure_23_t) safe_malloc(sizeof(struct matrix_closure_23_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_23(matrix_funtype_14_t closure){
        matrix_closure_23_t x = (matrix_closure_23_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix__matrix((matrix__matrix_t)x->htbl->data[j].key); release_matrix__matrix((matrix__matrix_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_23_t copy_matrix_closure_23(matrix_closure_23_t x){
        matrix_closure_23_t y = new_matrix_closure_23();
        y->ftbl = x->ftbl;

        y->fvar_1 = (uint32_t)x->fvar_1;
        y->fvar_2 = (uint32_t)x->fvar_2;
        if (x->htbl != NULL){
            matrix_funtype_14_htbl_t new_htbl = (matrix_funtype_14_htbl_t) safe_malloc(sizeof(struct matrix_funtype_14_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_14_hashentry_t * new_data = (matrix_funtype_14_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_14_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix__matrix_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (matrix__matrix_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


matrix__slice_t new_matrix__slice(void){
        matrix__slice_t tmp = (matrix__slice_t) safe_malloc(sizeof(struct matrix__slice_s));
        tmp->count = 1;
        return tmp;}

void release_matrix__slice(matrix__slice_t x){
        x->count--;
        if (x->count <= 0){
         mpz_clear(x->col0);
         mpz_clear(x->colhi);
         release_matrix__matrix((matrix__matrix_t)x->M);
         mpz_clear(x->row0);
         mpz_clear(x->rowhi);
        //printf("\nFreeing\n");
        safe_free(x);}}

void release_matrix__slice_ptr(pointer_t x, type_actual_t T){
        release_matrix__slice((matrix__slice_t)x);
}

matrix__slice_t copy_matrix__slice(matrix__slice_t x){
        matrix__slice_t y = new_matrix__slice();
        mpz_set(y->col0, x->col0);
        mpz_set(y->colhi, x->colhi);
        y->M = x->M;
        if (y->M != NULL){y->M->count++;};
        mpz_set(y->row0, x->row0);
        mpz_set(y->rowhi, x->rowhi);
        y->count = 1;
        return y;}

bool_t equal_matrix__slice(matrix__slice_t x, matrix__slice_t y){
        bool_t tmp = true; tmp = tmp && (mpz_cmp(x->col0, y->col0) == 0); tmp = tmp && (mpz_cmp(x->colhi, y->colhi) == 0); tmp = tmp && equal_matrix__matrix((matrix__matrix_t)x->M, (matrix__matrix_t)y->M); tmp = tmp && (mpz_cmp(x->row0, y->row0) == 0); tmp = tmp && (mpz_cmp(x->rowhi, y->rowhi) == 0);
        return tmp;}

char * json_matrix__slice(matrix__slice_t x){
        char * tmp[5]; 
        char * fld0 = safe_malloc(16);
         sprintf(fld0, "\"col0\" : ");
        tmp[0] = safe_strcat(fld0, json_mpz(x->col0));
        char * fld1 = safe_malloc(17);
         sprintf(fld1, "\"colhi\" : ");
        tmp[1] = safe_strcat(fld1, json_mpz(x->colhi));
        char * fld2 = safe_malloc(13);
         sprintf(fld2, "\"M\" : ");
        tmp[2] = safe_strcat(fld2, json_matrix__matrix((matrix__matrix_t)x->M));
        char * fld3 = safe_malloc(16);
         sprintf(fld3, "\"row0\" : ");
        tmp[3] = safe_strcat(fld3, json_mpz(x->row0));
        char * fld4 = safe_malloc(17);
         sprintf(fld4, "\"rowhi\" : ");
        tmp[4] = safe_strcat(fld4, json_mpz(x->rowhi));
         char * result = json_list_with_sep(tmp, 5,  '{', ',', '}');
         for (uint32_t i = 0; i < 5; i++) free(tmp[i]);
        return result;}

bool_t equal_matrix__slice_ptr(pointer_t x, pointer_t y, actual_matrix__slice_t T){
        return equal_matrix__slice((matrix__slice_t)x, (matrix__slice_t)y);
}

char * json_matrix__slice_ptr(pointer_t x, actual_matrix__slice_t T){
        return json_matrix__slice((matrix__slice_t)x);
}

actual_matrix__slice_t actual_matrix__slice(void){
        actual_matrix__slice_t new = (actual_matrix__slice_t)safe_malloc(sizeof(struct actual_matrix__slice_s));
        new->equal_ptr = (equal_ptr_t)(*equal_matrix__slice_ptr);
 
        new->release_ptr = (release_ptr_t)(*release_matrix__slice_ptr);
 
        new->json_ptr = (json_ptr_t)(*json_matrix__slice_ptr);
 

 
        return new;
 }

matrix__slice_t update_matrix__slice_col0(matrix__slice_t x, mpz_ptr_t v){
        matrix__slice_t y;
        if (x->count == 1){y = x;}
        else {y = copy_matrix__slice(x); x->count--;};
        mpz_set(y->col0, v);
        return y;}

matrix__slice_t update_matrix__slice_colhi(matrix__slice_t x, mpz_ptr_t v){
        matrix__slice_t y;
        if (x->count == 1){y = x;}
        else {y = copy_matrix__slice(x); x->count--;};
        mpz_set(y->colhi, v);
        return y;}

matrix__slice_t update_matrix__slice_M(matrix__slice_t x, matrix__matrix_t v){
        matrix__slice_t y;
        if (v != NULL){v->count++;};
        if (x->count == 1){y = x; if (x->M != NULL){release_matrix__matrix((matrix__matrix_t)x->M);};}
        else {y = copy_matrix__slice(x); x->count--; y->M->count--;};
        y->M = (matrix__matrix_t)v;
        return y;}

matrix__slice_t update_matrix__slice_row0(matrix__slice_t x, mpz_ptr_t v){
        matrix__slice_t y;
        if (x->count == 1){y = x;}
        else {y = copy_matrix__slice(x); x->count--;};
        mpz_set(y->row0, v);
        return y;}

matrix__slice_t update_matrix__slice_rowhi(matrix__slice_t x, mpz_ptr_t v){
        matrix__slice_t y;
        if (x->count == 1){y = x;}
        else {y = copy_matrix__slice(x); x->count--;};
        mpz_set(y->rowhi, v);
        return y;}




matrix_record_25_t new_matrix_record_25(void){
        matrix_record_25_t tmp = (matrix_record_25_t) safe_malloc(sizeof(struct matrix_record_25_s));
        tmp->count = 1;
        return tmp;}

void release_matrix_record_25(matrix_record_25_t x){
        x->count--;
        if (x->count <= 0){
         release_matrix__matrix((matrix__matrix_t)x->M);
        //printf("\nFreeing\n");
        safe_free(x);}}

void release_matrix_record_25_ptr(pointer_t x, type_actual_t T){
        release_matrix_record_25((matrix_record_25_t)x);
}

matrix_record_25_t copy_matrix_record_25(matrix_record_25_t x){
        matrix_record_25_t y = new_matrix_record_25();
        y->col0 = (uint32_t)x->col0;
        y->colhi = (uint32_t)x->colhi;
        y->M = x->M;
        if (y->M != NULL){y->M->count++;};
        y->row0 = (uint32_t)x->row0;
        y->rowhi = (uint32_t)x->rowhi;
        y->count = 1;
        return y;}

bool_t equal_matrix_record_25(matrix_record_25_t x, matrix_record_25_t y){
        bool_t tmp = true; tmp = tmp && x->col0 == y->col0; tmp = tmp && x->colhi == y->colhi; tmp = tmp && equal_matrix__matrix((matrix__matrix_t)x->M, (matrix__matrix_t)y->M); tmp = tmp && x->row0 == y->row0; tmp = tmp && x->rowhi == y->rowhi;
        return tmp;}

char * json_matrix_record_25(matrix_record_25_t x){
        char * tmp[5]; 
        char * fld0 = safe_malloc(16);
         sprintf(fld0, "\"col0\" : ");
        tmp[0] = safe_strcat(fld0, json_uint32(x->col0));
        char * fld1 = safe_malloc(17);
         sprintf(fld1, "\"colhi\" : ");
        tmp[1] = safe_strcat(fld1, json_uint32(x->colhi));
        char * fld2 = safe_malloc(13);
         sprintf(fld2, "\"M\" : ");
        tmp[2] = safe_strcat(fld2, json_matrix__matrix((matrix__matrix_t)x->M));
        char * fld3 = safe_malloc(16);
         sprintf(fld3, "\"row0\" : ");
        tmp[3] = safe_strcat(fld3, json_uint32(x->row0));
        char * fld4 = safe_malloc(17);
         sprintf(fld4, "\"rowhi\" : ");
        tmp[4] = safe_strcat(fld4, json_uint32(x->rowhi));
         char * result = json_list_with_sep(tmp, 5,  '{', ',', '}');
         for (uint32_t i = 0; i < 5; i++) free(tmp[i]);
        return result;}

bool_t equal_matrix_record_25_ptr(pointer_t x, pointer_t y, actual_matrix_record_25_t T){
        return equal_matrix_record_25((matrix_record_25_t)x, (matrix_record_25_t)y);
}

char * json_matrix_record_25_ptr(pointer_t x, actual_matrix_record_25_t T){
        return json_matrix_record_25((matrix_record_25_t)x);
}

actual_matrix_record_25_t actual_matrix_record_25(void){
        actual_matrix_record_25_t new = (actual_matrix_record_25_t)safe_malloc(sizeof(struct actual_matrix_record_25_s));
        new->equal_ptr = (equal_ptr_t)(*equal_matrix_record_25_ptr);
 
        new->release_ptr = (release_ptr_t)(*release_matrix_record_25_ptr);
 
        new->json_ptr = (json_ptr_t)(*json_matrix_record_25_ptr);
 

 
        return new;
 }

matrix_record_25_t update_matrix_record_25_col0(matrix_record_25_t x, uint32_t v){
        matrix_record_25_t y;
        if (x->count == 1){y = x;}
        else {y = copy_matrix_record_25(x); x->count--;};
        y->col0 = (uint32_t)v;
        return y;}

matrix_record_25_t update_matrix_record_25_colhi(matrix_record_25_t x, uint32_t v){
        matrix_record_25_t y;
        if (x->count == 1){y = x;}
        else {y = copy_matrix_record_25(x); x->count--;};
        y->colhi = (uint32_t)v;
        return y;}

matrix_record_25_t update_matrix_record_25_M(matrix_record_25_t x, matrix__matrix_t v){
        matrix_record_25_t y;
        if (v != NULL){v->count++;};
        if (x->count == 1){y = x; if (x->M != NULL){release_matrix__matrix((matrix__matrix_t)x->M);};}
        else {y = copy_matrix_record_25(x); x->count--; y->M->count--;};
        y->M = (matrix__matrix_t)v;
        return y;}

matrix_record_25_t update_matrix_record_25_row0(matrix_record_25_t x, uint32_t v){
        matrix_record_25_t y;
        if (x->count == 1){y = x;}
        else {y = copy_matrix_record_25(x); x->count--;};
        y->row0 = (uint32_t)v;
        return y;}

matrix_record_25_t update_matrix_record_25_rowhi(matrix_record_25_t x, uint32_t v){
        matrix_record_25_t y;
        if (x->count == 1){y = x;}
        else {y = copy_matrix_record_25(x); x->count--;};
        y->rowhi = (uint32_t)v;
        return y;}



void release_matrix_funtype_26(matrix_funtype_26_t x){
        x->count--;
            if (x->count <= 0)

                x->ftbl->rptr(x);}

matrix_funtype_26_t copy_matrix_funtype_26(matrix_funtype_26_t x){return x->ftbl->cptr(x);}

uint32_t lookup_matrix_funtype_26(matrix_funtype_26_htbl_t htbl, mpz_ptr_t i, uint32_t ihash){
        uint32_t mask = htbl->size - 1;
        uint32_t hashindex = ihash & mask;
        matrix_funtype_26_hashentry_t data = htbl->data[hashindex];
        bool_t keyzero;


        int64_t tmp6714 = mpz_cmp_ui(data.key, 0);
        keyzero = (tmp6714 == 0);
        bool_t keymatch;

        int64_t tmp6715 = mpz_cmp(data.key, i);
        keymatch = (tmp6715 == 0);
        while ((!keyzero || data.keyhash != 0) &&
                 (data.keyhash != ihash || !keymatch)){
                hashindex++;
                hashindex = hashindex & mask;
                data = htbl->data[hashindex];


                int64_t tmp6714 = mpz_cmp_ui(data.key, 0);
                keyzero = (tmp6714 == 0);


                int64_t tmp6715 = mpz_cmp(data.key, i);
                keymatch = (tmp6715 == 0);
                }
        return hashindex;
        }

matrix_funtype_26_t dupdate_matrix_funtype_26(matrix_funtype_26_t a, mpz_ptr_t i, matrix_funtype_5_t v){
        matrix_funtype_26_htbl_t htbl = a->htbl;
        if (htbl == NULL){//construct new htbl
                htbl = (matrix_funtype_26_htbl_t)safe_malloc(sizeof(struct matrix_funtype_26_htbl_s));
                htbl->size = HTBL_DEFAULT_SIZE; htbl->num_entries = 0;
                htbl->data = (matrix_funtype_26_hashentry_t *)safe_malloc(HTBL_DEFAULT_SIZE * sizeof(struct matrix_funtype_26_hashentry_s));
                for (uint32_t j = 0; j < HTBL_DEFAULT_SIZE; j++){mpz_init(htbl->data[j].key);mpz_set_ui(htbl->data[j].key, 0); htbl->data[j].keyhash = 0;
                }
                a->htbl = htbl;
        }
        uint32_t size = htbl->size;
        uint32_t num_entries = htbl->num_entries;
        matrix_funtype_26_hashentry_t * data = htbl->data;
        if (num_entries/3 >  size/5){//resize data
                uint32_t new_size = 2*size; uint32_t new_mask = new_size - 1;
                if (size >= HTBL_MAX_SIZE) out_of_memory();
                matrix_funtype_26_hashentry_t * new_data = (matrix_funtype_26_hashentry_t *)safe_malloc(new_size * sizeof(struct matrix_funtype_26_hashentry_s));
                for (uint32_t j = 0; j < new_size; j++){
                        mpz_init(new_data[j].key); mpz_set_ui(new_data[j].key, 0); 
                        new_data[j].keyhash = 0;}
                for (uint32_t j = 0; j < size; j++){//transfer entries
                        uint32_t keyhash = data[j].keyhash;
                        bool_t keyzero;
                        int64_t tmp6716 = mpz_cmp_ui(data[j].key, 0);
                        keyzero = (tmp6716 == 0);

                        if (!keyzero || keyhash != 0){
                                uint32_t new_loc = keyhash ^ new_mask;
                                bool_t newkeyzero;
                                int64_t tmp6717 = mpz_cmp_ui(new_data[new_loc].key, 0);
                                newkeyzero = (tmp6717 == 0);

                                while (!newkeyzero || new_data[new_loc].keyhash != 0){
                                        new_loc++;
                                        new_loc = new_loc ^ new_mask;

                                        int64_t tmp6718 = mpz_cmp_ui(new_data[new_loc].key, 0);
                                        newkeyzero = (tmp6718 == 0);

                                }
                                mpz_set(new_data[new_loc].key, data[j].key);
                                new_data[new_loc].keyhash = keyhash;
                                new_data[new_loc].value = (matrix_funtype_5_t)data[j].value;
                                }}
                htbl->size = new_size;
                htbl->num_entries = num_entries;
                htbl->data = new_data;
                for (uint32_t j=0; j < size; j++){mpz_clear(data[j].key); release_matrix_funtype_5((matrix_funtype_5_t)data[j].value);};
                safe_free(data);}
        uint32_t ihash = mpz_hash(i);
        uint32_t hashindex = lookup_matrix_funtype_26(htbl, i, ihash);
        matrix_funtype_26_hashentry_t hentry = htbl->data[hashindex];
        uint32_t hkeyhash = hentry.keyhash;
        bool_t hentrykeyzero;
        int64_t tmp6719 = mpz_cmp_ui(hentry.key, 0);
        hentrykeyzero = (tmp6719 == 0);

        if (hentrykeyzero && (hkeyhash == 0))
                {mpz_set(htbl->data[hashindex].key, i); htbl->data[hashindex].keyhash = ihash; htbl->data[hashindex].value = (matrix_funtype_5_t)v; htbl->num_entries++;}
            else {matrix_funtype_5_t tempvalue;tempvalue = (matrix_funtype_5_t)htbl->data[hashindex].value;htbl->data[hashindex].value = (matrix_funtype_5_t)v;if (v != NULL) v->count++;if (tempvalue != NULL)release_matrix_funtype_5(tempvalue);};
        return a;

}

matrix_funtype_26_t update_matrix_funtype_26(matrix_funtype_26_t a, mpz_ptr_t i, matrix_funtype_5_t v){
        if (a->count == 1){
                return dupdate_matrix_funtype_26(a, i, v);
            } else {
                matrix_funtype_26_t x = copy_matrix_funtype_26(a);
                a->count--;
                return dupdate_matrix_funtype_26(x, i, v);
            }}

bool_t equal_matrix_funtype_26(matrix_funtype_26_t x, matrix_funtype_26_t y){
        return false;}

char* json_matrix_funtype_26(matrix_funtype_26_t x){char * result = safe_malloc(27); sprintf(result, "%s", "\"matrix_funtype_26\""); return result;}

void release_matrix_funtype_27(matrix_funtype_27_t x){
        x->count--;
            if (x->count <= 0)

                x->ftbl->rptr(x);}

matrix_funtype_27_t copy_matrix_funtype_27(matrix_funtype_27_t x){return x->ftbl->cptr(x);}

bool_t equal_matrix_funtype_27(matrix_funtype_27_t x, matrix_funtype_27_t y){
        return false;}

char* json_matrix_funtype_27(matrix_funtype_27_t x){char * result = safe_malloc(27); sprintf(result, "%s", "\"matrix_funtype_27\""); return result;}


matrix_funtype_26_t f_matrix_closure_28(struct matrix_closure_28_s * closure, matrix_record_25_t bvar){
        release_matrix_funtype_27((matrix_funtype_27_t)closure);
        matrix_funtype_26_t result;
        result = (matrix_funtype_26_t)h_matrix_closure_28(bvar);
        return result;
}

matrix_funtype_26_t m_matrix_closure_28(struct matrix_closure_28_s * closure, matrix_record_25_t bvar){
        release_matrix_funtype_27((matrix_funtype_27_t)closure);
        return h_matrix_closure_28(bvar);}

matrix_funtype_26_t h_matrix_closure_28(matrix_record_25_t ivar_17){
        matrix_funtype_26_t result;

        matrix_closure_29_t cl6725;
        cl6725 = new_matrix_closure_29();
        cl6725->fvar_1 = (matrix_record_25_t)ivar_17;
        if (cl6725->fvar_1 != NULL) cl6725->fvar_1->count++;
        release_matrix_record_25((matrix_record_25_t)ivar_17);
        result = (matrix_funtype_26_t)cl6725;
        return result;
}

matrix_closure_28_t new_matrix_closure_28(void){
        static struct matrix_funtype_27_ftbl_s ftbl = {.fptr = (matrix_funtype_26_t (*)(matrix_funtype_27_t, matrix_record_25_t))&f_matrix_closure_28, .mptr = (matrix_funtype_26_t (*)(matrix_funtype_27_t, matrix_record_25_t))&m_matrix_closure_28, .rptr =  (void (*)(matrix_funtype_27_t))&release_matrix_closure_28, .cptr = (matrix_funtype_27_t (*)(matrix_funtype_27_t))&copy_matrix_closure_28};
        matrix_closure_28_t tmp = (matrix_closure_28_t) safe_malloc(sizeof(struct matrix_closure_28_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_28(matrix_funtype_27_t closure){
        matrix_closure_28_t x = (matrix_closure_28_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix_record_25((matrix_record_25_t)x->htbl->data[j].key); release_matrix_funtype_26((matrix_funtype_26_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_28_t copy_matrix_closure_28(matrix_closure_28_t x){
        matrix_closure_28_t y = new_matrix_closure_28();
        y->ftbl = x->ftbl;

        if (x->htbl != NULL){
            matrix_funtype_27_htbl_t new_htbl = (matrix_funtype_27_htbl_t) safe_malloc(sizeof(struct matrix_funtype_27_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_27_hashentry_t * new_data = (matrix_funtype_27_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_27_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix_record_25_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (matrix_funtype_26_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


matrix_funtype_5_t f_matrix_closure_29(struct matrix_closure_29_s * closure, mpz_ptr_t bvar){
if (closure->htbl != NULL){
        matrix_funtype_26_htbl_t htbl = closure->htbl;
        uint32_t hash = mpz_hash(bvar);
        uint32_t hashindex = lookup_matrix_funtype_26(htbl, bvar, hash);
        matrix_funtype_26_hashentry_t entry = htbl->data[hashindex];
        bool_t keyzero;
         int64_t tmp6720 = mpz_cmp_ui(entry.key, 0);
         keyzero = (tmp6720 == 0);
        if (!keyzero || entry.keyhash != 0){
                matrix_funtype_5_t result;
                release_matrix_funtype_26((matrix_funtype_26_t)closure);
                result = (matrix_funtype_5_t)entry.value;
                return result;}
        else {
            matrix_record_25_t fvar_1 = closure->fvar_1;

            fvar_1->count++;
            release_matrix_funtype_26((matrix_funtype_26_t)closure);
            matrix_funtype_5_t result;
            result = (matrix_funtype_5_t)h_matrix_closure_29(bvar, fvar_1);
            return result;};
        }

      else {
        matrix_record_25_t fvar_1 = closure->fvar_1;
        fvar_1->count++;
        release_matrix_funtype_26((matrix_funtype_26_t)closure);
        matrix_funtype_5_t result;
        result = (matrix_funtype_5_t)h_matrix_closure_29(bvar, fvar_1);
        return result;}
}

matrix_funtype_5_t m_matrix_closure_29(struct matrix_closure_29_s * closure, mpz_ptr_t bvar){
        matrix_record_25_t fvar_1 = closure->fvar_1;
        fvar_1->count++;
        release_matrix_funtype_26((matrix_funtype_26_t)closure);
        return h_matrix_closure_29(bvar, fvar_1);}

matrix_funtype_5_t h_matrix_closure_29(mpz_ptr_t ivar_36, matrix_record_25_t ivar_17){
        matrix_funtype_5_t result;

        matrix_closure_30_t cl6724;
        cl6724 = new_matrix_closure_30();
        cl6724->fvar_1 = (matrix_record_25_t)ivar_17;
        if (cl6724->fvar_1 != NULL) cl6724->fvar_1->count++;
        mpz_set(cl6724->fvar_2, ivar_36);
        mpz_clear(ivar_36);
        result = (matrix_funtype_5_t)cl6724;
        return result;
}

matrix_closure_29_t new_matrix_closure_29(void){
        static struct matrix_funtype_26_ftbl_s ftbl = {.fptr = (matrix_funtype_5_t (*)(matrix_funtype_26_t, mpz_ptr_t))&f_matrix_closure_29, .mptr = (matrix_funtype_5_t (*)(matrix_funtype_26_t, mpz_ptr_t))&m_matrix_closure_29, .rptr =  (void (*)(matrix_funtype_26_t))&release_matrix_closure_29, .cptr = (matrix_funtype_26_t (*)(matrix_funtype_26_t))&copy_matrix_closure_29};
        matrix_closure_29_t tmp = (matrix_closure_29_t) safe_malloc(sizeof(struct matrix_closure_29_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_29(matrix_funtype_26_t closure){
        matrix_closure_29_t x = (matrix_closure_29_t)closure;
        x->count--;
        if (x->count <= 0){
         release_matrix_record_25((matrix_record_25_t)x->fvar_1);
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){mpz_clear(x->htbl->data[j].key); release_matrix_funtype_5((matrix_funtype_5_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_29_t copy_matrix_closure_29(matrix_closure_29_t x){
        matrix_closure_29_t y = new_matrix_closure_29();
        y->ftbl = x->ftbl;

        y->fvar_1 = x->fvar_1; x->fvar_1->count++;
        if (x->htbl != NULL){
            matrix_funtype_26_htbl_t new_htbl = (matrix_funtype_26_htbl_t) safe_malloc(sizeof(struct matrix_funtype_26_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_26_hashentry_t * new_data = (matrix_funtype_26_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_26_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  mpz_init(new_data[j].key); mpz_set(new_data[j].key, x->htbl->data[j].key);;
                  new_data[j].value = (matrix_funtype_5_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


mpq_ptr_t f_matrix_closure_30(struct matrix_closure_30_s * closure, mpz_ptr_t bvar){
if (closure->htbl != NULL){
        matrix_funtype_5_htbl_t htbl = closure->htbl;
        uint32_t hash = mpz_hash(bvar);
        uint32_t hashindex = lookup_matrix_funtype_5(htbl, bvar, hash);
        matrix_funtype_5_hashentry_t entry = htbl->data[hashindex];
        bool_t keyzero;
         int64_t tmp6721 = mpz_cmp_ui(entry.key, 0);
         keyzero = (tmp6721 == 0);
        if (!keyzero || entry.keyhash != 0){
                mpq_ptr_t result;
                release_matrix_funtype_5((matrix_funtype_5_t)closure);
                result = (mpq_ptr_t)entry.value;
                return result;}
        else {
            matrix_record_25_t fvar_1 = closure->fvar_1;
            mpz_ptr_t fvar_2 = closure->fvar_2;

            fvar_1->count++;
            release_matrix_funtype_5((matrix_funtype_5_t)closure);
            mpq_ptr_t result;
            result = (mpq_ptr_t)h_matrix_closure_30(bvar, fvar_1, fvar_2);
            return result;};
        }

      else {
        matrix_record_25_t fvar_1 = closure->fvar_1;
        mpz_ptr_t fvar_2 = closure->fvar_2;
        fvar_1->count++;
        release_matrix_funtype_5((matrix_funtype_5_t)closure);
        mpq_ptr_t result;
        result = (mpq_ptr_t)h_matrix_closure_30(bvar, fvar_1, fvar_2);
        return result;}
}

mpq_ptr_t m_matrix_closure_30(struct matrix_closure_30_s * closure, mpz_ptr_t bvar){
        matrix_record_25_t fvar_1 = closure->fvar_1;
        mpz_ptr_t fvar_2 = closure->fvar_2;
        fvar_1->count++;
        release_matrix_funtype_5((matrix_funtype_5_t)closure);
        return h_matrix_closure_30(bvar, fvar_1, fvar_2);}

mpq_ptr_t h_matrix_closure_30(mpz_ptr_t ivar_54, matrix_record_25_t ivar_17, mpz_ptr_t ivar_36){
        mpq_ptr_t result;

        matrix_array_0_t ivar_66;
        matrix__matrix_t ivar_73;
        matrix__matrix_t ivar_76;
        ivar_76 = (matrix__matrix_t)ivar_17->M;
        ivar_76->count++;
        //copying to matrix__matrix from matrix__matrix;
        ivar_73 = (matrix__matrix_t)ivar_76;
        if (ivar_73 != NULL) ivar_73->count++;
        release_matrix__matrix((matrix__matrix_t)ivar_76);
        uint32_t ivar_77;
        uint32_t ivar_69;
        ivar_69 = (uint32_t)ivar_17->row0;
        mpz_ptr_t ivar_79; mpz_mk_set(ivar_79, ivar_36);
        mpz_t tmp6722;
        mpz_init(tmp6722);
        mpz_add_ui(tmp6722, ivar_79, ivar_69);
        ivar_77 = (uint32_t)mpz_get_ui(tmp6722);
        mpz_clear(tmp6722);
        mpz_clear(ivar_79);
        matrix_array_0_t ivar_72;
        ivar_72 = (matrix_array_0_t)ivar_73->elems[ivar_77];
        ivar_72->count++;
        release_matrix__matrix((matrix__matrix_t)ivar_73);
        //copying to matrix_array_0 from matrix_array_0;
        ivar_66 = (matrix_array_0_t)ivar_72;
        if (ivar_66 != NULL) ivar_66->count++;
        release_matrix_array_0((matrix_array_0_t)ivar_72);
        uint32_t ivar_78;
        uint32_t ivar_62;
        ivar_62 = (uint32_t)ivar_17->col0;
        mpz_t tmp6723;
        mpz_init(tmp6723);
        mpz_add_ui(tmp6723, ivar_54, ivar_62);
        ivar_78 = (uint32_t)mpz_get_ui(tmp6723);
        mpz_clear(tmp6723);
        mpz_clear(ivar_54);
        result = safe_malloc(sizeof(mpq_t));
        mpq_init(result);
        mpq_set(result, ivar_66->elems[ivar_78]);
        release_matrix_array_0((matrix_array_0_t)ivar_66);
        return result;
}

matrix_closure_30_t new_matrix_closure_30(void){
        static struct matrix_funtype_5_ftbl_s ftbl = {.fptr = (mpq_ptr_t (*)(matrix_funtype_5_t, mpz_ptr_t))&f_matrix_closure_30, .mptr = (mpq_ptr_t (*)(matrix_funtype_5_t, mpz_ptr_t))&m_matrix_closure_30, .rptr =  (void (*)(matrix_funtype_5_t))&release_matrix_closure_30, .cptr = (matrix_funtype_5_t (*)(matrix_funtype_5_t))&copy_matrix_closure_30};
        matrix_closure_30_t tmp = (matrix_closure_30_t) safe_malloc(sizeof(struct matrix_closure_30_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        mpz_init(tmp->fvar_2);
        return tmp;}

void release_matrix_closure_30(matrix_funtype_5_t closure){
        matrix_closure_30_t x = (matrix_closure_30_t)closure;
        x->count--;
        if (x->count <= 0){
         release_matrix_record_25((matrix_record_25_t)x->fvar_1);
         mpz_clear(x->fvar_2);
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){mpz_clear(x->htbl->data[j].key);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_30_t copy_matrix_closure_30(matrix_closure_30_t x){
        matrix_closure_30_t y = new_matrix_closure_30();
        y->ftbl = x->ftbl;

        y->fvar_1 = x->fvar_1; x->fvar_1->count++;
        mpz_set(y->fvar_2, x->fvar_2);
        if (x->htbl != NULL){
            matrix_funtype_5_htbl_t new_htbl = (matrix_funtype_5_htbl_t) safe_malloc(sizeof(struct matrix_funtype_5_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_5_hashentry_t * new_data = (matrix_funtype_5_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_5_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  mpz_init(new_data[j].key); mpz_set(new_data[j].key, x->htbl->data[j].key);;
                  mpq_init(new_data[j].value); mpq_set(new_data[j].value, x->htbl->data[j].value);;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}

void release_matrix_funtype_31(matrix_funtype_31_t x){
        x->count--;
            if (x->count <= 0)

                x->ftbl->rptr(x);}

matrix_funtype_31_t copy_matrix_funtype_31(matrix_funtype_31_t x){return x->ftbl->cptr(x);}

bool_t equal_matrix_funtype_31(matrix_funtype_31_t x, matrix_funtype_31_t y){
        return false;}

char* json_matrix_funtype_31(matrix_funtype_31_t x){char * result = safe_malloc(27); sprintf(result, "%s", "\"matrix_funtype_31\""); return result;}


mpz_ptr_t f_matrix_closure_32(struct matrix_closure_32_s * closure, matrix_record_25_t bvar){
        release_matrix_funtype_31((matrix_funtype_31_t)closure);
        mpz_ptr_t result;
        result = (mpz_ptr_t)h_matrix_closure_32(bvar);
        return result;
}

mpz_ptr_t m_matrix_closure_32(struct matrix_closure_32_s * closure, matrix_record_25_t bvar){
        release_matrix_funtype_31((matrix_funtype_31_t)closure);
        return h_matrix_closure_32(bvar);}

mpz_ptr_t h_matrix_closure_32(matrix_record_25_t ivar_10){
        mpz_ptr_t result;

        uint32_t ivar_16;
        ivar_16 = (uint32_t)ivar_10->rowhi;
        uint32_t ivar_17;
        ivar_17 = (uint32_t)ivar_10->row0;
        release_matrix_record_25((matrix_record_25_t)ivar_10);
        mpz_mk_set_ui(result, (uint64_t)ivar_16);
        mpz_sub_ui(result, result, (uint64_t)ivar_17);
        return result;
}

matrix_closure_32_t new_matrix_closure_32(void){
        static struct matrix_funtype_31_ftbl_s ftbl = {.fptr = (mpz_ptr_t (*)(matrix_funtype_31_t, matrix_record_25_t))&f_matrix_closure_32, .mptr = (mpz_ptr_t (*)(matrix_funtype_31_t, matrix_record_25_t))&m_matrix_closure_32, .rptr =  (void (*)(matrix_funtype_31_t))&release_matrix_closure_32, .cptr = (matrix_funtype_31_t (*)(matrix_funtype_31_t))&copy_matrix_closure_32};
        matrix_closure_32_t tmp = (matrix_closure_32_t) safe_malloc(sizeof(struct matrix_closure_32_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_32(matrix_funtype_31_t closure){
        matrix_closure_32_t x = (matrix_closure_32_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix_record_25((matrix_record_25_t)x->htbl->data[j].key);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_32_t copy_matrix_closure_32(matrix_closure_32_t x){
        matrix_closure_32_t y = new_matrix_closure_32();
        y->ftbl = x->ftbl;

        if (x->htbl != NULL){
            matrix_funtype_31_htbl_t new_htbl = (matrix_funtype_31_htbl_t) safe_malloc(sizeof(struct matrix_funtype_31_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_31_hashentry_t * new_data = (matrix_funtype_31_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_31_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix_record_25_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  mpz_init(new_data[j].value); mpz_set(new_data[j].value, x->htbl->data[j].value);;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


mpz_ptr_t f_matrix_closure_33(struct matrix_closure_33_s * closure, matrix_record_25_t bvar){
        release_matrix_funtype_31((matrix_funtype_31_t)closure);
        mpz_ptr_t result;
        result = (mpz_ptr_t)h_matrix_closure_33(bvar);
        return result;
}

mpz_ptr_t m_matrix_closure_33(struct matrix_closure_33_s * closure, matrix_record_25_t bvar){
        release_matrix_funtype_31((matrix_funtype_31_t)closure);
        return h_matrix_closure_33(bvar);}

mpz_ptr_t h_matrix_closure_33(matrix_record_25_t ivar_10){
        mpz_ptr_t result;

        uint32_t ivar_16;
        ivar_16 = (uint32_t)ivar_10->colhi;
        uint32_t ivar_17;
        ivar_17 = (uint32_t)ivar_10->col0;
        release_matrix_record_25((matrix_record_25_t)ivar_10);
        mpz_mk_set_ui(result, (uint64_t)ivar_16);
        mpz_sub_ui(result, result, (uint64_t)ivar_17);
        return result;
}

matrix_closure_33_t new_matrix_closure_33(void){
        static struct matrix_funtype_31_ftbl_s ftbl = {.fptr = (mpz_ptr_t (*)(matrix_funtype_31_t, matrix_record_25_t))&f_matrix_closure_33, .mptr = (mpz_ptr_t (*)(matrix_funtype_31_t, matrix_record_25_t))&m_matrix_closure_33, .rptr =  (void (*)(matrix_funtype_31_t))&release_matrix_closure_33, .cptr = (matrix_funtype_31_t (*)(matrix_funtype_31_t))&copy_matrix_closure_33};
        matrix_closure_33_t tmp = (matrix_closure_33_t) safe_malloc(sizeof(struct matrix_closure_33_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_33(matrix_funtype_31_t closure){
        matrix_closure_33_t x = (matrix_closure_33_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix_record_25((matrix_record_25_t)x->htbl->data[j].key);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_33_t copy_matrix_closure_33(matrix_closure_33_t x){
        matrix_closure_33_t y = new_matrix_closure_33();
        y->ftbl = x->ftbl;

        if (x->htbl != NULL){
            matrix_funtype_31_htbl_t new_htbl = (matrix_funtype_31_htbl_t) safe_malloc(sizeof(struct matrix_funtype_31_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_31_hashentry_t * new_data = (matrix_funtype_31_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_31_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix_record_25_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  mpz_init(new_data[j].value); mpz_set(new_data[j].value, x->htbl->data[j].value);;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}

void release_matrix_funtype_34(matrix_funtype_34_t x){
        x->count--;
            if (x->count <= 0)

                x->ftbl->rptr(x);}

matrix_funtype_34_t copy_matrix_funtype_34(matrix_funtype_34_t x){return x->ftbl->cptr(x);}

bool_t equal_matrix_funtype_34(matrix_funtype_34_t x, matrix_funtype_34_t y){
        return false;}

char* json_matrix_funtype_34(matrix_funtype_34_t x){char * result = safe_malloc(27); sprintf(result, "%s", "\"matrix_funtype_34\""); return result;}


matrix__slice_t f_matrix_closure_35(struct matrix_closure_35_s * closure, matrix__matrix_t bvar){
        mpz_ptr_t fvar_1 = closure->fvar_1;
        mpz_ptr_t fvar_2 = closure->fvar_2;
        release_matrix_funtype_34((matrix_funtype_34_t)closure);
        matrix__slice_t result;
        result = (matrix__slice_t)h_matrix_closure_35(bvar, fvar_1, fvar_2);
        return result;
}

matrix__slice_t m_matrix_closure_35(struct matrix_closure_35_s * closure, matrix__matrix_t bvar){
        mpz_ptr_t fvar_1 = closure->fvar_1;
        mpz_ptr_t fvar_2 = closure->fvar_2;
        release_matrix_funtype_34((matrix_funtype_34_t)closure);
        return h_matrix_closure_35(bvar, fvar_1, fvar_2);}

matrix__slice_t h_matrix_closure_35(matrix__matrix_t ivar_5, mpz_ptr_t ivar_1, mpz_ptr_t ivar_2){
        matrix__slice_t result;

        mpz_ptr_t ivar_6;
        ivar_6 = safe_malloc(sizeof(mpz_t));
        mpz_init(ivar_6);
        mpz_mk_set_ui(ivar_6, 0);
        mpz_ptr_t ivar_9;
        ivar_9 = safe_malloc(sizeof(mpz_t));
        mpz_init(ivar_9);
        mpz_mk_set_ui(ivar_9, 0);
        matrix__slice_t tmp6836 = new_matrix__slice();;
        result = (matrix__slice_t)tmp6836;
        mpz_init(tmp6836->col0);
        mpz_set(tmp6836->col0, ivar_6);
        mpz_clear(ivar_6);
        mpz_init(tmp6836->colhi);
        mpz_set(tmp6836->colhi, ivar_2);
        tmp6836->M = (matrix__matrix_t)ivar_5;
        mpz_init(tmp6836->row0);
        mpz_set(tmp6836->row0, ivar_9);
        mpz_clear(ivar_9);
        mpz_init(tmp6836->rowhi);
        mpz_set(tmp6836->rowhi, ivar_1);
        return result;
}

matrix_closure_35_t new_matrix_closure_35(void){
        static struct matrix_funtype_34_ftbl_s ftbl = {.fptr = (matrix__slice_t (*)(matrix_funtype_34_t, matrix__matrix_t))&f_matrix_closure_35, .mptr = (matrix__slice_t (*)(matrix_funtype_34_t, matrix__matrix_t))&m_matrix_closure_35, .rptr =  (void (*)(matrix_funtype_34_t))&release_matrix_closure_35, .cptr = (matrix_funtype_34_t (*)(matrix_funtype_34_t))&copy_matrix_closure_35};
        matrix_closure_35_t tmp = (matrix_closure_35_t) safe_malloc(sizeof(struct matrix_closure_35_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        mpz_init(tmp->fvar_1);
        mpz_init(tmp->fvar_2);
        return tmp;}

void release_matrix_closure_35(matrix_funtype_34_t closure){
        matrix_closure_35_t x = (matrix_closure_35_t)closure;
        x->count--;
        if (x->count <= 0){
         mpz_clear(x->fvar_1);
         mpz_clear(x->fvar_2);
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix__matrix((matrix__matrix_t)x->htbl->data[j].key); release_matrix__slice((matrix__slice_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_35_t copy_matrix_closure_35(matrix_closure_35_t x){
        matrix_closure_35_t y = new_matrix_closure_35();
        y->ftbl = x->ftbl;

        mpz_set(y->fvar_1, x->fvar_1);
        mpz_set(y->fvar_2, x->fvar_2);
        if (x->htbl != NULL){
            matrix_funtype_34_htbl_t new_htbl = (matrix_funtype_34_htbl_t) safe_malloc(sizeof(struct matrix_funtype_34_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_34_hashentry_t * new_data = (matrix_funtype_34_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_34_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix__matrix_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (matrix__slice_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


matrix_record_36_t new_matrix_record_36(void){
        matrix_record_36_t tmp = (matrix_record_36_t) safe_malloc(sizeof(struct matrix_record_36_s));
        tmp->count = 1;
        return tmp;}

void release_matrix_record_36(matrix_record_36_t x){
        x->count--;
        if (x->count <= 0){
         release_matrix__slice((matrix__slice_t)x->project_1);
         mpz_clear(x->project_2);
        //printf("\nFreeing\n");
        safe_free(x);}}

void release_matrix_record_36_ptr(pointer_t x, type_actual_t T){
        release_matrix_record_36((matrix_record_36_t)x);
}

matrix_record_36_t copy_matrix_record_36(matrix_record_36_t x){
        matrix_record_36_t y = new_matrix_record_36();
        y->project_1 = x->project_1;
        if (y->project_1 != NULL){y->project_1->count++;};
        mpz_set(y->project_2, x->project_2);
        y->count = 1;
        return y;}

bool_t equal_matrix_record_36(matrix_record_36_t x, matrix_record_36_t y){
        bool_t tmp = true; tmp = tmp && equal_matrix__slice((matrix__slice_t)x->project_1, (matrix__slice_t)y->project_1); tmp = tmp && (mpz_cmp(x->project_2, y->project_2) == 0);
        return tmp;}

char * json_matrix_record_36(matrix_record_36_t x){
        char * tmp[2]; 
        char * fld0 = safe_malloc(21);
         sprintf(fld0, "\"project_1\" : ");
        tmp[0] = safe_strcat(fld0, json_matrix__slice((matrix__slice_t)x->project_1));
        char * fld1 = safe_malloc(21);
         sprintf(fld1, "\"project_2\" : ");
        tmp[1] = safe_strcat(fld1, json_mpz(x->project_2));
         char * result = json_list_with_sep(tmp, 2,  '{', ',', '}');
         for (uint32_t i = 0; i < 2; i++) free(tmp[i]);
        return result;}

bool_t equal_matrix_record_36_ptr(pointer_t x, pointer_t y, actual_matrix_record_36_t T){
        return equal_matrix_record_36((matrix_record_36_t)x, (matrix_record_36_t)y);
}

char * json_matrix_record_36_ptr(pointer_t x, actual_matrix_record_36_t T){
        return json_matrix_record_36((matrix_record_36_t)x);
}

actual_matrix_record_36_t actual_matrix_record_36(void){
        actual_matrix_record_36_t new = (actual_matrix_record_36_t)safe_malloc(sizeof(struct actual_matrix_record_36_s));
        new->equal_ptr = (equal_ptr_t)(*equal_matrix_record_36_ptr);
 
        new->release_ptr = (release_ptr_t)(*release_matrix_record_36_ptr);
 
        new->json_ptr = (json_ptr_t)(*json_matrix_record_36_ptr);
 

 
        return new;
 }

matrix_record_36_t update_matrix_record_36_project_1(matrix_record_36_t x, matrix__slice_t v){
        matrix_record_36_t y;
        if (v != NULL){v->count++;};
        if (x->count == 1){y = x; if (x->project_1 != NULL){release_matrix__slice((matrix__slice_t)x->project_1);};}
        else {y = copy_matrix_record_36(x); x->count--; y->project_1->count--;};
        y->project_1 = (matrix__slice_t)v;
        return y;}

matrix_record_36_t update_matrix_record_36_project_2(matrix_record_36_t x, mpz_ptr_t v){
        matrix_record_36_t y;
        if (x->count == 1){y = x;}
        else {y = copy_matrix_record_36(x); x->count--;};
        mpz_set(y->project_2, v);
        return y;}



void release_matrix_funtype_37(matrix_funtype_37_t x){
        x->count--;
            if (x->count <= 0)

                x->ftbl->rptr(x);}

matrix_funtype_37_t copy_matrix_funtype_37(matrix_funtype_37_t x){return x->ftbl->cptr(x);}

bool_t equal_matrix_funtype_37(matrix_funtype_37_t x, matrix_funtype_37_t y){
        return false;}

char* json_matrix_funtype_37(matrix_funtype_37_t x){char * result = safe_malloc(27); sprintf(result, "%s", "\"matrix_funtype_37\""); return result;}


matrix__slice_t f_matrix_closure_38(struct matrix_closure_38_s * closure, matrix_record_36_t bvar){
        matrix__slice_t bvar_1;
        bvar_1 = (matrix__slice_t)bvar->project_1;
        bvar->project_1->count++;
        mpz_t bvar_2;
        mpz_init(bvar_2);
        mpz_set(bvar_2, bvar->project_2);
        release_matrix_record_36((matrix_record_36_t)bvar);
        release_matrix_funtype_37((matrix_funtype_37_t)closure);
        matrix__slice_t result;
        result = (matrix__slice_t)h_matrix_closure_38(bvar_1, bvar_2);
        return result;
}

matrix__slice_t m_matrix_closure_38(struct matrix_closure_38_s * closure, matrix__slice_t bvar_1, mpz_ptr_t bvar_2){
        release_matrix_funtype_37((matrix_funtype_37_t)closure);
        return h_matrix_closure_38(bvar_1, bvar_2);}

matrix__slice_t h_matrix_closure_38(matrix__slice_t ivar_80, mpz_ptr_t ivar_81){
        matrix__slice_t result;

        mpz_ptr_t ivar_119;
        mpz_ptr_t ivar_120;
        ivar_120 = safe_malloc(sizeof(mpz_t));
        mpz_init(ivar_120);
        mpz_set(ivar_120, ivar_80->row0);
        mpz_mk_add(ivar_119, ivar_81, ivar_120);
        mpz_clear(ivar_120);
        mpz_clear(ivar_81);
        result = (matrix__slice_t)update_matrix__slice_rowhi(ivar_80, ivar_119);
        return result;
}

matrix_closure_38_t new_matrix_closure_38(void){
        static struct matrix_funtype_37_ftbl_s ftbl = {.fptr = (matrix__slice_t (*)(matrix_funtype_37_t, matrix_record_36_t))&f_matrix_closure_38, .mptr = (matrix__slice_t (*)(matrix_funtype_37_t, matrix__slice_t, mpz_ptr_t))&m_matrix_closure_38, .rptr =  (void (*)(matrix_funtype_37_t))&release_matrix_closure_38, .cptr = (matrix_funtype_37_t (*)(matrix_funtype_37_t))&copy_matrix_closure_38};
        matrix_closure_38_t tmp = (matrix_closure_38_t) safe_malloc(sizeof(struct matrix_closure_38_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_38(matrix_funtype_37_t closure){
        matrix_closure_38_t x = (matrix_closure_38_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix_record_36((matrix_record_36_t)x->htbl->data[j].key); release_matrix__slice((matrix__slice_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_38_t copy_matrix_closure_38(matrix_closure_38_t x){
        matrix_closure_38_t y = new_matrix_closure_38();
        y->ftbl = x->ftbl;

        if (x->htbl != NULL){
            matrix_funtype_37_htbl_t new_htbl = (matrix_funtype_37_htbl_t) safe_malloc(sizeof(struct matrix_funtype_37_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_37_hashentry_t * new_data = (matrix_funtype_37_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_37_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix_record_36_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (matrix__slice_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


matrix__slice_t f_matrix_closure_39(struct matrix_closure_39_s * closure, matrix_record_36_t bvar){
        matrix__slice_t bvar_1;
        bvar_1 = (matrix__slice_t)bvar->project_1;
        bvar->project_1->count++;
        mpz_t bvar_2;
        mpz_init(bvar_2);
        mpz_set(bvar_2, bvar->project_2);
        release_matrix_record_36((matrix_record_36_t)bvar);
        release_matrix_funtype_37((matrix_funtype_37_t)closure);
        matrix__slice_t result;
        result = (matrix__slice_t)h_matrix_closure_39(bvar_1, bvar_2);
        return result;
}

matrix__slice_t m_matrix_closure_39(struct matrix_closure_39_s * closure, matrix__slice_t bvar_1, mpz_ptr_t bvar_2){
        release_matrix_funtype_37((matrix_funtype_37_t)closure);
        return h_matrix_closure_39(bvar_1, bvar_2);}

matrix__slice_t h_matrix_closure_39(matrix__slice_t ivar_80, mpz_ptr_t ivar_81){
        matrix__slice_t result;

        mpz_ptr_t ivar_119;
        mpz_ptr_t ivar_120;
        ivar_120 = safe_malloc(sizeof(mpz_t));
        mpz_init(ivar_120);
        mpz_set(ivar_120, ivar_80->row0);
        mpz_mk_add(ivar_119, ivar_81, ivar_120);
        mpz_clear(ivar_120);
        mpz_clear(ivar_81);
        result = (matrix__slice_t)update_matrix__slice_row0(ivar_80, ivar_119);
        return result;
}

matrix_closure_39_t new_matrix_closure_39(void){
        static struct matrix_funtype_37_ftbl_s ftbl = {.fptr = (matrix__slice_t (*)(matrix_funtype_37_t, matrix_record_36_t))&f_matrix_closure_39, .mptr = (matrix__slice_t (*)(matrix_funtype_37_t, matrix__slice_t, mpz_ptr_t))&m_matrix_closure_39, .rptr =  (void (*)(matrix_funtype_37_t))&release_matrix_closure_39, .cptr = (matrix_funtype_37_t (*)(matrix_funtype_37_t))&copy_matrix_closure_39};
        matrix_closure_39_t tmp = (matrix_closure_39_t) safe_malloc(sizeof(struct matrix_closure_39_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_39(matrix_funtype_37_t closure){
        matrix_closure_39_t x = (matrix_closure_39_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix_record_36((matrix_record_36_t)x->htbl->data[j].key); release_matrix__slice((matrix__slice_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_39_t copy_matrix_closure_39(matrix_closure_39_t x){
        matrix_closure_39_t y = new_matrix_closure_39();
        y->ftbl = x->ftbl;

        if (x->htbl != NULL){
            matrix_funtype_37_htbl_t new_htbl = (matrix_funtype_37_htbl_t) safe_malloc(sizeof(struct matrix_funtype_37_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_37_hashentry_t * new_data = (matrix_funtype_37_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_37_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix_record_36_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (matrix__slice_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


matrix__slice_t f_matrix_closure_40(struct matrix_closure_40_s * closure, matrix_record_36_t bvar){
        matrix__slice_t bvar_1;
        bvar_1 = (matrix__slice_t)bvar->project_1;
        bvar->project_1->count++;
        mpz_t bvar_2;
        mpz_init(bvar_2);
        mpz_set(bvar_2, bvar->project_2);
        release_matrix_record_36((matrix_record_36_t)bvar);
        release_matrix_funtype_37((matrix_funtype_37_t)closure);
        matrix__slice_t result;
        result = (matrix__slice_t)h_matrix_closure_40(bvar_1, bvar_2);
        return result;
}

matrix__slice_t m_matrix_closure_40(struct matrix_closure_40_s * closure, matrix__slice_t bvar_1, mpz_ptr_t bvar_2){
        release_matrix_funtype_37((matrix_funtype_37_t)closure);
        return h_matrix_closure_40(bvar_1, bvar_2);}

matrix__slice_t h_matrix_closure_40(matrix__slice_t ivar_80, mpz_ptr_t ivar_81){
        matrix__slice_t result;

        mpz_ptr_t ivar_119;
        mpz_ptr_t ivar_120;
        ivar_120 = safe_malloc(sizeof(mpz_t));
        mpz_init(ivar_120);
        mpz_set(ivar_120, ivar_80->col0);
        mpz_mk_add(ivar_119, ivar_81, ivar_120);
        mpz_clear(ivar_120);
        mpz_clear(ivar_81);
        result = (matrix__slice_t)update_matrix__slice_colhi(ivar_80, ivar_119);
        return result;
}

matrix_closure_40_t new_matrix_closure_40(void){
        static struct matrix_funtype_37_ftbl_s ftbl = {.fptr = (matrix__slice_t (*)(matrix_funtype_37_t, matrix_record_36_t))&f_matrix_closure_40, .mptr = (matrix__slice_t (*)(matrix_funtype_37_t, matrix__slice_t, mpz_ptr_t))&m_matrix_closure_40, .rptr =  (void (*)(matrix_funtype_37_t))&release_matrix_closure_40, .cptr = (matrix_funtype_37_t (*)(matrix_funtype_37_t))&copy_matrix_closure_40};
        matrix_closure_40_t tmp = (matrix_closure_40_t) safe_malloc(sizeof(struct matrix_closure_40_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_40(matrix_funtype_37_t closure){
        matrix_closure_40_t x = (matrix_closure_40_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix_record_36((matrix_record_36_t)x->htbl->data[j].key); release_matrix__slice((matrix__slice_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_40_t copy_matrix_closure_40(matrix_closure_40_t x){
        matrix_closure_40_t y = new_matrix_closure_40();
        y->ftbl = x->ftbl;

        if (x->htbl != NULL){
            matrix_funtype_37_htbl_t new_htbl = (matrix_funtype_37_htbl_t) safe_malloc(sizeof(struct matrix_funtype_37_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_37_hashentry_t * new_data = (matrix_funtype_37_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_37_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix_record_36_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (matrix__slice_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


matrix__slice_t f_matrix_closure_41(struct matrix_closure_41_s * closure, matrix_record_36_t bvar){
        matrix__slice_t bvar_1;
        bvar_1 = (matrix__slice_t)bvar->project_1;
        bvar->project_1->count++;
        mpz_t bvar_2;
        mpz_init(bvar_2);
        mpz_set(bvar_2, bvar->project_2);
        release_matrix_record_36((matrix_record_36_t)bvar);
        release_matrix_funtype_37((matrix_funtype_37_t)closure);
        matrix__slice_t result;
        result = (matrix__slice_t)h_matrix_closure_41(bvar_1, bvar_2);
        return result;
}

matrix__slice_t m_matrix_closure_41(struct matrix_closure_41_s * closure, matrix__slice_t bvar_1, mpz_ptr_t bvar_2){
        release_matrix_funtype_37((matrix_funtype_37_t)closure);
        return h_matrix_closure_41(bvar_1, bvar_2);}

matrix__slice_t h_matrix_closure_41(matrix__slice_t ivar_80, mpz_ptr_t ivar_81){
        matrix__slice_t result;

        mpz_ptr_t ivar_119;
        mpz_ptr_t ivar_120;
        ivar_120 = safe_malloc(sizeof(mpz_t));
        mpz_init(ivar_120);
        mpz_set(ivar_120, ivar_80->col0);
        mpz_mk_add(ivar_119, ivar_81, ivar_120);
        mpz_clear(ivar_120);
        mpz_clear(ivar_81);
        result = (matrix__slice_t)update_matrix__slice_col0(ivar_80, ivar_119);
        return result;
}

matrix_closure_41_t new_matrix_closure_41(void){
        static struct matrix_funtype_37_ftbl_s ftbl = {.fptr = (matrix__slice_t (*)(matrix_funtype_37_t, matrix_record_36_t))&f_matrix_closure_41, .mptr = (matrix__slice_t (*)(matrix_funtype_37_t, matrix__slice_t, mpz_ptr_t))&m_matrix_closure_41, .rptr =  (void (*)(matrix_funtype_37_t))&release_matrix_closure_41, .cptr = (matrix_funtype_37_t (*)(matrix_funtype_37_t))&copy_matrix_closure_41};
        matrix_closure_41_t tmp = (matrix_closure_41_t) safe_malloc(sizeof(struct matrix_closure_41_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_matrix_closure_41(matrix_funtype_37_t closure){
        matrix_closure_41_t x = (matrix_closure_41_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_matrix_record_36((matrix_record_36_t)x->htbl->data[j].key); release_matrix__slice((matrix__slice_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

matrix_closure_41_t copy_matrix_closure_41(matrix_closure_41_t x){
        matrix_closure_41_t y = new_matrix_closure_41();
        y->ftbl = x->ftbl;

        if (x->htbl != NULL){
            matrix_funtype_37_htbl_t new_htbl = (matrix_funtype_37_htbl_t) safe_malloc(sizeof(struct matrix_funtype_37_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            matrix_funtype_37_hashentry_t * new_data = (matrix_funtype_37_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct matrix_funtype_37_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (matrix_record_36_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (matrix__slice_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}
matrix__matrix_t matrix__I(uint32_t ivar_1){
        matrix__matrix_t  result;

        uint32_t size6449;
        //copying to uint32 from uint32;
        size6449 = (uint32_t)ivar_1;
        size6449 += 0;
        result = new_matrix__matrix(size6449);
        uint32_t ivar_3;
        for (uint32_t index6446 = 0; index6446 < size6449; index6446++){
             ivar_3 = (uint32_t)index6446;
             uint32_t size6448;
             //copying to uint32 from uint32;
             size6448 = (uint32_t)ivar_1;
             size6448 += 0;
             result->elems[index6446] = new_matrix_array_0(size6448);
             uint32_t ivar_5;
             for (uint32_t index6447 = 0; index6447 < size6448; index6447++){
           ivar_5 = (uint32_t)index6447;
           bool_t ivar_6;
           ivar_6 = (ivar_3 == ivar_5);
           if (ivar_6){
           result->elems[index6446]->elems[index6447] = safe_malloc(sizeof(mpq_t));
           mpq_init(result->elems[index6446]->elems[index6447]);
           mpq_mk_set_ui(result->elems[index6446]->elems[index6447], 1);
           } else {
           result->elems[index6446]->elems[index6447] = safe_malloc(sizeof(mpq_t));
           mpq_init(result->elems[index6446]->elems[index6447]);
           mpq_mk_set_ui(result->elems[index6446]->elems[index6447], 0);};
             };
        };
        
        
        return result;
}

matrix__matrix_t matrix__Z(uint32_t ivar_1, uint32_t ivar_2){
        matrix__matrix_t  result;

        uint32_t size6453;
        //copying to uint32 from uint32;
        size6453 = (uint32_t)ivar_1;
        size6453 += 0;
        result = new_matrix__matrix(size6453);
        uint32_t ivar_4;
        for (uint32_t index6450 = 0; index6450 < size6453; index6450++){
             ivar_4 = (uint32_t)index6450;
             uint32_t size6452;
             //copying to uint32 from uint32;
             size6452 = (uint32_t)ivar_2;
             size6452 += 0;
             result->elems[index6450] = new_matrix_array_0(size6452);
             uint32_t ivar_6;
             for (uint32_t index6451 = 0; index6451 < size6452; index6451++){
           ivar_6 = (uint32_t)index6451;
           result->elems[index6450]->elems[index6451] = safe_malloc(sizeof(mpq_t));
           mpq_init(result->elems[index6450]->elems[index6451]);
           mpq_mk_set_ui(result->elems[index6450]->elems[index6451], 0);
             };
        };
        
        
        return result;
}

matrix_funtype_3_t matrix__madd(uint32_t ivar_1, uint32_t ivar_2){
        matrix_funtype_3_t  result;

        matrix_closure_4_t cl6462;
        cl6462 = new_matrix_closure_4();
        result = (matrix_funtype_3_t)cl6462;
        
        
        return result;
}

matrix__matrix_t matrix__mmult(mpz_ptr_t ivar_1, mpz_ptr_t ivar_2, mpz_ptr_t ivar_3, matrix__matrix_t ivar_4, matrix__matrix_t ivar_5){
        matrix__matrix_t  result;

        mpz_t ivar_7;
        mpz_init(ivar_7);
        uint32_t size6475;
        //copying to uint32 from mpz;
        size6475 = (uint32_t)mpz_get_ui(ivar_1);
        size6475 += 0;
        result = new_matrix__matrix(size6475);
        for (uint32_t index6463 = 0; index6463 < size6475; index6463++){
             mpz_t ivar_7;
             mpz_init(ivar_7);
             mpz_set_ui(ivar_7, index6463);
             mpz_t ivar_9;
             mpz_init(ivar_9);
             uint32_t size6474;
             //copying to uint32 from mpz;
             size6474 = (uint32_t)mpz_get_ui(ivar_3);
             size6474 += 0;
             result->elems[index6463] = new_matrix_array_0(size6474);
             for (uint32_t index6464 = 0; index6464 < size6474; index6464++){
           mpz_t ivar_9;
           mpz_init(ivar_9);
           mpz_set_ui(ivar_9, index6464);
           uint32_t ivar_35;
           //copying to uint32 from mpz;
           ivar_35 = (uint32_t)mpz_get_ui(ivar_2);
           matrix_funtype_5_t ivar_38;
           matrix_closure_6_t cl6472;
           cl6472 = new_matrix_closure_6();
           cl6472->fvar_1 = (matrix__matrix_t)ivar_5;
           if (cl6472->fvar_1 != NULL) cl6472->fvar_1->count++;
           mpz_set(cl6472->fvar_2, ivar_9);
           cl6472->fvar_3 = (matrix__matrix_t)ivar_4;
           if (cl6472->fvar_3 != NULL) cl6472->fvar_3->count++;
           mpz_set(cl6472->fvar_4, ivar_7);
           mpz_clear(ivar_9);
           ivar_38 = (matrix_funtype_5_t)cl6472;
           matrix_array_0_t ivar_36;
           //copying to matrix_array_0 from matrix_funtype_5;
           uint32_t tmp6473;
           //copying to uint32 from uint32;
           tmp6473 = (uint32_t)ivar_35;
           tmp6473 += 0;
           ivar_36 = new_matrix_array_0(tmp6473);
           for (uint32_t index_39 = 0; index_39 < tmp6473; index_39++){
           mpz_t index_40;
           mpz_init(index_40);
           mpz_set_ui(index_40, index_39);
           ivar_36->elems[index_39] = (mpq_ptr_t)safe_malloc(sizeof(mpq_t));
           mpq_init(ivar_36->elems[index_39]);
           mpq_mk_set(ivar_36->elems[index_39], ivar_38->ftbl->fptr(ivar_38, index_40));
           };
           release_matrix_funtype_5((matrix_funtype_5_t)ivar_38);
           result->elems[index6463]->elems[index6464] = (mpq_ptr_t)sigma__sigma((uint32_t)ivar_35, (sigma__vector_t)ivar_36);
             };
             mpz_clear(ivar_7);
        };
        release_matrix__matrix((matrix__matrix_t)ivar_5);
        release_matrix__matrix((matrix__matrix_t)ivar_4);
        mpz_clear(ivar_2);
        
        
        return result;
}

matrix_funtype_7_t matrix__right_inverse(uint32_t ivar_1, matrix__matrix_t ivar_2){
        matrix_funtype_7_t  result;

        matrix_closure_8_t cl6476;
        cl6476 = new_matrix_closure_8();
        cl6476->fvar_1 = (uint32_t)ivar_1;
        cl6476->fvar_2 = (matrix__matrix_t)ivar_2;
        if (cl6476->fvar_2 != NULL) cl6476->fvar_2->count++;
        release_matrix__matrix((matrix__matrix_t)ivar_2);
        result = (matrix_funtype_7_t)cl6476;
        
        
        return result;
}

matrix_funtype_7_t matrix__left_inverse(uint32_t ivar_1, matrix__matrix_t ivar_2){
        matrix_funtype_7_t  result;

        matrix_closure_9_t cl6477;
        cl6477 = new_matrix_closure_9();
        cl6477->fvar_1 = (uint32_t)ivar_1;
        cl6477->fvar_2 = (matrix__matrix_t)ivar_2;
        if (cl6477->fvar_2 != NULL) cl6477->fvar_2->count++;
        release_matrix__matrix((matrix__matrix_t)ivar_2);
        result = (matrix_funtype_7_t)cl6477;
        
        
        return result;
}

matrix_funtype_7_t matrix__inverse(uint32_t ivar_1, matrix__matrix_t ivar_2){
        matrix_funtype_7_t  result;

        matrix_closure_10_t cl6478;
        cl6478 = new_matrix_closure_10();
        cl6478->fvar_1 = (matrix__matrix_t)ivar_2;
        if (cl6478->fvar_1 != NULL) cl6478->fvar_1->count++;
        cl6478->fvar_2 = (uint32_t)ivar_1;
        release_matrix__matrix((matrix__matrix_t)ivar_2);
        result = (matrix_funtype_7_t)cl6478;
        
        
        return result;
}

bool_t matrix__lower_triangularp(uint32_t ivar_1, matrix__matrix_t ivar_2){
        bool_t  result;

        uint32_t low6479;
        uint32_t highvar6480;
        result = true;
        low6479 = (uint32_t) 0;
        //copying to uint32 from uint32;
        highvar6480 = (uint32_t)ivar_1;
        highvar6480 += 0;
        for (uint32_t ivar_3 = low6479; ivar_3 < highvar6480; ivar_3++){
             uint32_t low6481;
             uint32_t highvar6482;
             result = true;
             low6481 = (uint32_t) 0;
             //copying to uint32 from uint32;
             highvar6482 = (uint32_t)ivar_1;
             highvar6482 += 0;
             for (uint32_t ivar_4 = low6481; ivar_4 < highvar6482; ivar_4++){
           bool_t ivar_5;
           ivar_5 = (ivar_4 > ivar_3);
           if (ivar_5){
           mpq_ptr_t ivar_10;
           matrix_array_0_t ivar_14;
           matrix_array_0_t ivar_16;
           ivar_16 = (matrix_array_0_t)ivar_2->elems[ivar_3];
           ivar_16->count++;
           release_matrix__matrix((matrix__matrix_t)ivar_2);
           //copying to matrix_array_0 from matrix_array_0;
           ivar_14 = (matrix_array_0_t)ivar_16;
           if (ivar_14 != NULL) ivar_14->count++;
           release_matrix_array_0((matrix_array_0_t)ivar_16);
           ivar_10 = safe_malloc(sizeof(mpq_t));
           mpq_init(ivar_10);
           mpq_set(ivar_10, ivar_14->elems[ivar_4]);
           release_matrix_array_0((matrix_array_0_t)ivar_14);
           uint8_t ivar_11;
           ivar_11 = (uint8_t)0;
           int64_t tmp6483 = mpq_cmp_ui(ivar_10, ivar_11, 1);
           result = (tmp6483 == 0);
           mpq_clear(ivar_10);
           } else {
           release_matrix__matrix((matrix__matrix_t)ivar_2);
           result = (bool_t) true;};
           if (!result) break;
             };
             if (!result) break;
        };
        
        
        return result;
}

matrix_funtype_3_t matrix__concat(uint32_t ivar_1, uint32_t ivar_2, uint32_t ivar_3){
        matrix_funtype_3_t  result;

        matrix_closure_11_t cl6494;
        cl6494 = new_matrix_closure_11();
        cl6494->fvar_1 = (uint32_t)ivar_2;
        result = (matrix_funtype_3_t)cl6494;
        
        
        return result;
}

matrix_funtype_3_t matrix__stack(uint32_t ivar_1, uint32_t ivar_2, uint32_t ivar_3){
        matrix_funtype_3_t  result;

        matrix_closure_12_t cl6503;
        cl6503 = new_matrix_closure_12();
        cl6503->fvar_1 = (uint32_t)ivar_1;
        result = (matrix_funtype_3_t)cl6503;
        
        
        return result;
}

matrix_funtype_15_t matrix__topleft(uint32_t ivar_1, uint32_t ivar_2){
        matrix_funtype_15_t  result;

        matrix_closure_16_t cl6522;
        cl6522 = new_matrix_closure_16();
        result = (matrix_funtype_15_t)cl6522;
        
        
        return result;
}

matrix_funtype_15_t matrix__topright(uint32_t ivar_1, uint32_t ivar_2){
        matrix_funtype_15_t  result;

        matrix_closure_18_t cl6544;
        cl6544 = new_matrix_closure_18();
        result = (matrix_funtype_15_t)cl6544;
        
        
        return result;
}

matrix_funtype_15_t matrix__botleft(uint32_t ivar_1, uint32_t ivar_2){
        matrix_funtype_15_t  result;

        matrix_closure_20_t cl6564;
        cl6564 = new_matrix_closure_20();
        result = (matrix_funtype_15_t)cl6564;
        
        
        return result;
}

matrix_funtype_15_t matrix__botright(uint32_t ivar_1, uint32_t ivar_2){
        matrix_funtype_15_t  result;

        matrix_closure_22_t cl6587;
        cl6587 = new_matrix_closure_22();
        result = (matrix_funtype_15_t)cl6587;
        
        
        return result;
}

matrix_funtype_27_t matrix__slice2matrix(uint32_t ivar_1, uint32_t ivar_2){
        matrix_funtype_27_t  result;

        matrix_closure_28_t cl6726;
        cl6726 = new_matrix_closure_28();
        result = (matrix_funtype_27_t)cl6726;
        
        
        return result;
}

matrix_funtype_31_t matrix__numrows(uint32_t ivar_1, uint32_t ivar_2){
        matrix_funtype_31_t  result;

        matrix_closure_32_t cl6773;
        cl6773 = new_matrix_closure_32();
        result = (matrix_funtype_31_t)cl6773;
        
        
        return result;
}

matrix_funtype_31_t matrix__numcols(uint32_t ivar_1, uint32_t ivar_2){
        matrix_funtype_31_t  result;

        matrix_closure_33_t cl6820;
        cl6820 = new_matrix_closure_33();
        result = (matrix_funtype_31_t)cl6820;
        
        
        return result;
}

matrix_funtype_34_t matrix__fullslice(mpz_ptr_t ivar_1, mpz_ptr_t ivar_2){
        matrix_funtype_34_t  result;

        matrix_closure_35_t cl6837;
        cl6837 = new_matrix_closure_35();
        mpz_set(cl6837->fvar_1, ivar_1);
        mpz_set(cl6837->fvar_2, ivar_2);
        mpz_clear(ivar_1);
        mpz_clear(ivar_2);
        result = (matrix_funtype_34_t)cl6837;
        
        
        return result;
}

matrix_funtype_37_t matrix__choptop(mpz_ptr_t ivar_1, mpz_ptr_t ivar_2){
        matrix_funtype_37_t  result;

        matrix_closure_38_t cl7086;
        cl7086 = new_matrix_closure_38();
        result = (matrix_funtype_37_t)cl7086;
        
        
        return result;
}

matrix_funtype_37_t matrix__chopbot(mpz_ptr_t ivar_1, mpz_ptr_t ivar_2){
        matrix_funtype_37_t  result;

        matrix_closure_39_t cl7336;
        cl7336 = new_matrix_closure_39();
        result = (matrix_funtype_37_t)cl7336;
        
        
        return result;
}

matrix_funtype_37_t matrix__diceleft(mpz_ptr_t ivar_1, mpz_ptr_t ivar_2){
        matrix_funtype_37_t  result;

        matrix_closure_40_t cl7589;
        cl7589 = new_matrix_closure_40();
        result = (matrix_funtype_37_t)cl7589;
        
        
        return result;
}

matrix_funtype_37_t matrix__diceright(mpz_ptr_t ivar_1, mpz_ptr_t ivar_2){
        matrix_funtype_37_t  result;

        matrix_closure_41_t cl7839;
        cl7839 = new_matrix_closure_41();
        result = (matrix_funtype_37_t)cl7839;
        
        
        return result;
}

bool_t matrix__test1(void){
        bool_t  static  result;

        static bool_t defined = false;
        if (!defined){
            
        matrix__matrix_t ivar_1;
        uint8_t ivar_29;
        ivar_29 = (uint8_t)3;
        mpz_ptr_t ivar_19;
        //copying to mpz from uint8;
        mpz_mk_set_ui(ivar_19, ivar_29);
        uint8_t ivar_28;
        ivar_28 = (uint8_t)3;
        mpz_ptr_t ivar_20;
        //copying to mpz from uint8;
        mpz_mk_set_ui(ivar_20, ivar_28);
        uint8_t ivar_27;
        ivar_27 = (uint8_t)3;
        mpz_ptr_t ivar_21;
        //copying to mpz from uint8;
        mpz_mk_set_ui(ivar_21, ivar_27);
        matrix__matrix_t ivar_22;
        uint8_t ivar_12;
        ivar_12 = (uint8_t)3;
        uint32_t ivar_10;
        //copying to uint32 from uint8;
        ivar_10 = (uint32_t)ivar_12;
        matrix__matrix_t ivar_9;
        ivar_9 = (matrix__matrix_t)matrix__I((uint32_t)ivar_10);
        //copying to matrix__matrix from matrix__matrix;
        ivar_22 = (matrix__matrix_t)ivar_9;
        if (ivar_22 != NULL) ivar_22->count++;
        release_matrix__matrix((matrix__matrix_t)ivar_9);
        matrix__matrix_t ivar_23;
        uint8_t ivar_17;
        ivar_17 = (uint8_t)3;
        uint32_t ivar_15;
        //copying to uint32 from uint8;
        ivar_15 = (uint32_t)ivar_17;
        matrix__matrix_t ivar_14;
        ivar_14 = (matrix__matrix_t)matrix__I((uint32_t)ivar_15);
        //copying to matrix__matrix from matrix__matrix;
        ivar_23 = (matrix__matrix_t)ivar_14;
        if (ivar_23 != NULL) ivar_23->count++;
        release_matrix__matrix((matrix__matrix_t)ivar_14);
        matrix__matrix_t ivar_18;
        ivar_18 = (matrix__matrix_t)matrix__mmult((mpz_ptr_t)ivar_19, (mpz_ptr_t)ivar_20, (mpz_ptr_t)ivar_21, (matrix__matrix_t)ivar_22, (matrix__matrix_t)ivar_23);
        //copying to matrix__matrix from matrix__matrix;
        ivar_1 = (matrix__matrix_t)ivar_18;
        if (ivar_1 != NULL) ivar_1->count++;
        release_matrix__matrix((matrix__matrix_t)ivar_18);
        matrix__matrix_t ivar_2;
        uint8_t ivar_34;
        ivar_34 = (uint8_t)3;
        uint32_t ivar_32;
        //copying to uint32 from uint8;
        ivar_32 = (uint32_t)ivar_34;
        matrix__matrix_t ivar_31;
        ivar_31 = (matrix__matrix_t)matrix__I((uint32_t)ivar_32);
        //copying to matrix__matrix from matrix__matrix;
        ivar_2 = (matrix__matrix_t)ivar_31;
        if (ivar_2 != NULL) ivar_2->count++;
        release_matrix__matrix((matrix__matrix_t)ivar_31);
        result = (bool_t) equal_matrix__matrix(ivar_1, ivar_2);
        defined = true;};
        
        
        return result;
}
