# Auto-generated fragment for strassen
OBJS_strassen := $(SRCDIR)/strassen.o $(SRCDIR)/strassen_c.o $(SRCDIR)/sigma_c.o $(SRCDIR)/matrix_c.o  
pvs2c/bin/strassen: $(OBJS_strassen) | $(BINDIR)
	$(CC) $(CFLAGS) $(LDFLAGS) -o $@ $^ $(LDLIBS)

.PHONY: strassen
strassen: pvs2c/bin/strassen

.PHONY: run_strassen
run_strassen: strassen
	./pvs2c/bin/strassen
