//Code generated using pvs2ir2c
#include "strassen_c.h"



strassen_array_0_t new_strassen_array_0(uint32_t size){
        strassen_array_0_t tmp = (strassen_array_0_t) safe_malloc(sizeof(struct strassen_array_0_s) + (size * sizeof(mpq_ptr_t)));
        tmp->count = 1;
        tmp->size = size;;
        tmp->max = size;
         return tmp;}

void release_strassen_array_0(strassen_array_0_t x){
        x->count--;
         if (x->count <= 0){safe_free(x);}
}

void release_strassen_array_0_ptr(pointer_t x, type_actual_t T){
        release_strassen_array_0((strassen_array_0_t)x);
}

strassen_array_0_t copy_strassen_array_0(strassen_array_0_t x){
        strassen_array_0_t tmp = new_strassen_array_0(x->max);
        tmp->count = 1;
        tmp->size = x->max;
        for (uint32_t i = 0; i < x->max; i++){ tmp->elems[i] = (mpq_ptr_t)safe_malloc(sizeof(mpq_t));
                mpq_init(tmp->elems[i]);
                if (i < x->size) mpq_set(tmp->elems[i], x->elems[i]);};
         return tmp;}

bool_t equal_strassen_array_0(strassen_array_0_t x, strassen_array_0_t y){
        bool_t tmp = true;
        uint32_t i = 0;
        while  (i < x->size && tmp){tmp = (mpq_cmp(x->elems[i], y->elems[i]) == 0); i++;};
        return tmp;}

char * json_strassen_array_0(strassen_array_0_t x){
        char ** tmp = (char **)safe_malloc(sizeof(void *) * x->size);
        for (uint32_t i = 0; i < x->size; i++){tmp[i] = json_mpq(x->elems[i]);};
        char * result = json_list_with_sep(tmp, x->size, '[', ',', ']');
        for (uint32_t i = 0; i < x->size; i++) free(tmp[i]);
        free(tmp);
        return result;}

bool_t equal_strassen_array_0_ptr(pointer_t x, pointer_t y, type_actual_t T){
        return equal_strassen_array_0((strassen_array_0_t)x, (strassen_array_0_t)y);
}

char * json_strassen_array_0_ptr(pointer_t x, type_actual_t T){
        return json_strassen_array_0((strassen_array_0_t)x);
}

actual_strassen_array_0_t actual_strassen_array_0(void){
        actual_strassen_array_0_t new = (actual_strassen_array_0_t)safe_malloc(sizeof(struct actual_strassen_array_0_s));
        new->equal_ptr = (equal_ptr_t)(*equal_strassen_array_0_ptr);
 
        new->release_ptr = (release_ptr_t)(*release_strassen_array_0_ptr);
 
        new->json_ptr = (json_ptr_t)(*json_strassen_array_0_ptr);
 

 
        return new;
 }

strassen_array_0_t update_strassen_array_0(strassen_array_0_t x, uint32_t i, mpq_t v){
        strassen_array_0_t y; 
         if (x->count == 1){y = x;}
           else {y = copy_strassen_array_0(x );
                x->count--;};
        mpq_set(y->elems[i], v);
        return y;}

strassen_array_0_t upgrade_strassen_array_0(strassen_array_0_t x, uint32_t i, mpq_t v){
        strassen_array_0_t y;
        uint32_t xmax = x->max;
         if (x->count == 1 && i < xmax){y = x;}
           else if (i >= xmax){uint32_t newmax = ((xmax < UINT32_MAX/2) ? ((i < 2 * (xmax + 1)) ? 2 * (xmax + 1) : i + 1) : UINT32_MAX);
                y = safe_realloc(x, sizeof(struct strassen_array_0_s) + (newmax * sizeof(mpq_t)));
                y->count = 1;
                y->size = i+1;
                y->max = newmax;}
           else {y = copy_strassen_array_0(x );
                x->count--;};
        mpq_set(y->elems[i], v);
        return y;}




strassen_array_1_t new_strassen_array_1(uint32_t size){
        strassen_array_1_t tmp = (strassen_array_1_t) safe_malloc(sizeof(struct strassen_array_1_s) + (size * sizeof(strassen_array_0_t)));
        tmp->count = 1;
        tmp->size = size;
        tmp->max = size;
        return tmp;}

void release_strassen_array_1(strassen_array_1_t x){
        x->count--;
        if (x->count <= 0){
                for (int i = 0; i < x->size; i++){release_strassen_array_0((strassen_array_0_t)x->elems[i]);};
        //printf("\nFreeing\n");
        safe_free(x);}
}

void release_strassen_array_1_ptr(pointer_t x, type_actual_t T){
        release_strassen_array_1((strassen_array_1_t)x);
}

strassen_array_1_t copy_strassen_array_1(strassen_array_1_t x){
        strassen_array_1_t tmp = new_strassen_array_1(x->max);
        tmp->count = 1;
        tmp->size = x->max;
        for (uint32_t i = 0; i < x->max; i++){tmp->elems[i] = x->elems[i];
                if (i < x->size) x->elems[i]->count++;};
         return tmp;}

bool_t equal_strassen_array_1(strassen_array_1_t x, strassen_array_1_t y){
        bool_t tmp = true;
        uint32_t i = 0;
        while (i < x->size && tmp){tmp = equal_strassen_array_0(x->elems[i], y->elems[i]); i++;};
        return tmp;}

char * json_strassen_array_1(strassen_array_1_t x){
        char ** tmp = (char **)safe_malloc(sizeof(void *) * x->size);
        for (uint32_t i = 0; i < x->size; i++){tmp[i] = json_strassen_array_0(x->elems[i]);};
        char * result = json_list_with_sep(tmp, x->size, '[', ',', ']');
        for (uint32_t i = 0; i < x->size; i++) free(tmp[i]);
        free(tmp);
        return result;}

bool_t equal_strassen_array_1_ptr(pointer_t x, pointer_t y, type_actual_t T){
        return equal_strassen_array_1((strassen_array_1_t)x, (strassen_array_1_t)y);
}

char * json_strassen_array_1_ptr(pointer_t x, type_actual_t T){
        return json_strassen_array_1((strassen_array_1_t)x);
}

actual_strassen_array_1_t actual_strassen_array_1(void){
        actual_strassen_array_1_t new = (actual_strassen_array_1_t)safe_malloc(sizeof(struct actual_strassen_array_1_s));
        new->equal_ptr = (equal_ptr_t)(*equal_strassen_array_1_ptr);
 
        new->release_ptr = (release_ptr_t)(*release_strassen_array_1_ptr);
 
        new->json_ptr = (json_ptr_t)(*json_strassen_array_1_ptr);
 

 
        return new;
 }

strassen_array_1_t update_strassen_array_1(strassen_array_1_t x, uint32_t i, strassen_array_0_t v){
         strassen_array_1_t y;
         if (x->count == 1){y = x;}
                 else {y = copy_strassen_array_1(x);
                      x->count--;};
        strassen_array_0_t * yelems = y->elems;
        if (v != NULL){v->count++;}
        if (yelems[i] != NULL){release_strassen_array_0((strassen_array_0_t)yelems[i]);};
         yelems[i] = v;
         return y;}

strassen_array_1_t upgrade_strassen_array_1(strassen_array_1_t x, uint32_t i, strassen_array_0_t v){
         strassen_array_1_t y;
        uint32_t xmax = x->max;
        uint32_t xsize = x->size;
         if (x->count == 1 && i < xmax){y = x;}
                 else if (i >= xmax){
                            uint32_t newmax = ((xmax < UINT32_MAX/2)  ? ((i < 2 * (xmax + 1))  ? 2 * (xmax + 1) : i + 1) : UINT32_MAX);
                            y = safe_realloc(x, sizeof(struct strassen_array_1_s) + (newmax * sizeof(strassen_array_0_t)));
                            y->count = 1;
                            y->max = newmax;
                            for (uint32_t j = xsize; j < newmax; j++){y->elems[j] = NULL;};}
                         else {y = copy_strassen_array_1(x);
                            x->count--;};
        strassen_array_0_t * yelems = y->elems;
        if (v != NULL){v->count++;};
        y->size = xsize > i ? xsize : i + 1;
        if (i < xmax && yelems[i] != NULL){release_strassen_array_0((strassen_array_0_t)yelems[i]);};
         yelems[i] = v;
         return y;}




strassen_record_2_t new_strassen_record_2(void){
        strassen_record_2_t tmp = (strassen_record_2_t) safe_malloc(sizeof(struct strassen_record_2_s));
        tmp->count = 1;
        return tmp;}

void release_strassen_record_2(strassen_record_2_t x){
        x->count--;
        if (x->count <= 0){
         release_strassen_array_1((strassen_array_1_t)x->project_1);
         release_strassen_array_1((strassen_array_1_t)x->project_2);
        //printf("\nFreeing\n");
        safe_free(x);}}

void release_strassen_record_2_ptr(pointer_t x, type_actual_t T){
        release_strassen_record_2((strassen_record_2_t)x);
}

strassen_record_2_t copy_strassen_record_2(strassen_record_2_t x){
        strassen_record_2_t y = new_strassen_record_2();
        y->project_1 = x->project_1;
        if (y->project_1 != NULL){y->project_1->count++;};
        y->project_2 = x->project_2;
        if (y->project_2 != NULL){y->project_2->count++;};
        y->count = 1;
        return y;}

bool_t equal_strassen_record_2(strassen_record_2_t x, strassen_record_2_t y){
        bool_t tmp = true; tmp = tmp && equal_strassen_array_1((strassen_array_1_t)x->project_1, (strassen_array_1_t)y->project_1); tmp = tmp && equal_strassen_array_1((strassen_array_1_t)x->project_2, (strassen_array_1_t)y->project_2);
        return tmp;}

char * json_strassen_record_2(strassen_record_2_t x){
        char * tmp[2]; 
        char * fld0 = safe_malloc(21);
         sprintf(fld0, "\"project_1\" : ");
        tmp[0] = safe_strcat(fld0, json_strassen_array_1((strassen_array_1_t)x->project_1));
        char * fld1 = safe_malloc(21);
         sprintf(fld1, "\"project_2\" : ");
        tmp[1] = safe_strcat(fld1, json_strassen_array_1((strassen_array_1_t)x->project_2));
         char * result = json_list_with_sep(tmp, 2,  '{', ',', '}');
         for (uint32_t i = 0; i < 2; i++) free(tmp[i]);
        return result;}

bool_t equal_strassen_record_2_ptr(pointer_t x, pointer_t y, actual_strassen_record_2_t T){
        return equal_strassen_record_2((strassen_record_2_t)x, (strassen_record_2_t)y);
}

char * json_strassen_record_2_ptr(pointer_t x, actual_strassen_record_2_t T){
        return json_strassen_record_2((strassen_record_2_t)x);
}

actual_strassen_record_2_t actual_strassen_record_2(void){
        actual_strassen_record_2_t new = (actual_strassen_record_2_t)safe_malloc(sizeof(struct actual_strassen_record_2_s));
        new->equal_ptr = (equal_ptr_t)(*equal_strassen_record_2_ptr);
 
        new->release_ptr = (release_ptr_t)(*release_strassen_record_2_ptr);
 
        new->json_ptr = (json_ptr_t)(*json_strassen_record_2_ptr);
 

 
        return new;
 }

strassen_record_2_t update_strassen_record_2_project_1(strassen_record_2_t x, strassen_array_1_t v){
        strassen_record_2_t y;
        if (v != NULL){v->count++;};
        if (x->count == 1){y = x; if (x->project_1 != NULL){release_strassen_array_1((strassen_array_1_t)x->project_1);};}
        else {y = copy_strassen_record_2(x); x->count--; y->project_1->count--;};
        y->project_1 = (strassen_array_1_t)v;
        return y;}

strassen_record_2_t update_strassen_record_2_project_2(strassen_record_2_t x, strassen_array_1_t v){
        strassen_record_2_t y;
        if (v != NULL){v->count++;};
        if (x->count == 1){y = x; if (x->project_2 != NULL){release_strassen_array_1((strassen_array_1_t)x->project_2);};}
        else {y = copy_strassen_record_2(x); x->count--; y->project_2->count--;};
        y->project_2 = (strassen_array_1_t)v;
        return y;}



void release_strassen_funtype_3(strassen_funtype_3_t x){
        x->count--;
            if (x->count <= 0)

                x->ftbl->rptr(x);}

strassen_funtype_3_t copy_strassen_funtype_3(strassen_funtype_3_t x){return x->ftbl->cptr(x);}

bool_t equal_strassen_funtype_3(strassen_funtype_3_t x, strassen_funtype_3_t y){
        return false;}

char* json_strassen_funtype_3(strassen_funtype_3_t x){char * result = safe_malloc(28); sprintf(result, "%s", "\"strassen_funtype_3\""); return result;}


strassen_array_1_t f_strassen_closure_4(struct strassen_closure_4_s * closure, strassen_record_2_t bvar){
        strassen_array_1_t bvar_1;
        bvar_1 = (strassen_array_1_t)bvar->project_1;
        bvar->project_1->count++;
        strassen_array_1_t bvar_2;
        bvar_2 = (strassen_array_1_t)bvar->project_2;
        bvar->project_2->count++;
        release_strassen_record_2((strassen_record_2_t)bvar);
        release_strassen_funtype_3((strassen_funtype_3_t)closure);
        strassen_array_1_t result;
        result = (strassen_array_1_t)h_strassen_closure_4(bvar_1, bvar_2);
        return result;
}

strassen_array_1_t m_strassen_closure_4(struct strassen_closure_4_s * closure, strassen_array_1_t bvar_1, strassen_array_1_t bvar_2){
        release_strassen_funtype_3((strassen_funtype_3_t)closure);
        return h_strassen_closure_4(bvar_1, bvar_2);}

strassen_array_1_t h_strassen_closure_4(strassen_array_1_t ivar_5, strassen_array_1_t ivar_6){
        strassen_array_1_t result;

        uint32_t size7847;
        //copying to uint32 from uint32;
        size7847 = (uint32_t)ivar_1;
        size7847 += 0;
        result = new_strassen_array_1(size7847);
        uint32_t ivar_8;
        for (uint32_t index7844 = 0; index7844 < size7847; index7844++){
             ivar_8 = (uint32_t)index7844;
             uint32_t size7846;
             //copying to uint32 from uint32;
             size7846 = (uint32_t)ivar_1;
             size7846 += 0;
             result->elems[index7844] = new_strassen_array_0(size7846);
             uint32_t ivar_10;
             for (uint32_t index7845 = 0; index7845 < size7846; index7845++){
           ivar_10 = (uint32_t)index7845;
           mpq_ptr_t ivar_11;
           strassen_array_0_t ivar_15;
           strassen_array_0_t ivar_17;
           ivar_17 = (strassen_array_0_t)ivar_5->elems[ivar_8];
           ivar_17->count++;
           //copying to strassen_array_0 from strassen_array_0;
           ivar_15 = (strassen_array_0_t)ivar_17;
           if (ivar_15 != NULL) ivar_15->count++;
           release_strassen_array_0((strassen_array_0_t)ivar_17);
           ivar_11 = safe_malloc(sizeof(mpq_t));
           mpq_init(ivar_11);
           mpq_set(ivar_11, ivar_15->elems[ivar_10]);
           release_strassen_array_0((strassen_array_0_t)ivar_15);
           mpq_ptr_t ivar_12;
           strassen_array_0_t ivar_23;
           strassen_array_0_t ivar_25;
           ivar_25 = (strassen_array_0_t)ivar_6->elems[ivar_8];
           ivar_25->count++;
           //copying to strassen_array_0 from strassen_array_0;
           ivar_23 = (strassen_array_0_t)ivar_25;
           if (ivar_23 != NULL) ivar_23->count++;
           release_strassen_array_0((strassen_array_0_t)ivar_25);
           ivar_12 = safe_malloc(sizeof(mpq_t));
           mpq_init(ivar_12);
           mpq_set(ivar_12, ivar_23->elems[ivar_10]);
           release_strassen_array_0((strassen_array_0_t)ivar_23);
           mpq_mk_sub(result->elems[index7844]->elems[index7845], ivar_11, ivar_12);
           mpq_clear(ivar_11);
           mpq_clear(ivar_12);
             };
        };
        release_strassen_array_1((strassen_array_1_t)ivar_5);
        release_strassen_array_1((strassen_array_1_t)ivar_6);
        return result;
}

strassen_closure_4_t new_strassen_closure_4(void){
        static struct strassen_funtype_3_ftbl_s ftbl = {.fptr = (strassen_array_1_t (*)(strassen_funtype_3_t, strassen_record_2_t))&f_strassen_closure_4, .mptr = (strassen_array_1_t (*)(strassen_funtype_3_t, strassen_array_1_t, strassen_array_1_t))&m_strassen_closure_4, .rptr =  (void (*)(strassen_funtype_3_t))&release_strassen_closure_4, .cptr = (strassen_funtype_3_t (*)(strassen_funtype_3_t))&copy_strassen_closure_4};
        strassen_closure_4_t tmp = (strassen_closure_4_t) safe_malloc(sizeof(struct strassen_closure_4_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_strassen_closure_4(strassen_funtype_3_t closure){
        strassen_closure_4_t x = (strassen_closure_4_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_strassen_record_2((strassen_record_2_t)x->htbl->data[j].key); release_strassen_array_1((strassen_array_1_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

strassen_closure_4_t copy_strassen_closure_4(strassen_closure_4_t x){
        strassen_closure_4_t y = new_strassen_closure_4();
        y->ftbl = x->ftbl;

        if (x->htbl != NULL){
            strassen_funtype_3_htbl_t new_htbl = (strassen_funtype_3_htbl_t) safe_malloc(sizeof(struct strassen_funtype_3_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            strassen_funtype_3_hashentry_t * new_data = (strassen_funtype_3_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct strassen_funtype_3_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (strassen_record_2_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (strassen_array_1_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}

void release_strassen_funtype_5(strassen_funtype_5_t x){
        x->count--;
            if (x->count <= 0)

                x->ftbl->rptr(x);}

strassen_funtype_5_t copy_strassen_funtype_5(strassen_funtype_5_t x){return x->ftbl->cptr(x);}

bool_t equal_strassen_funtype_5(strassen_funtype_5_t x, strassen_funtype_5_t y){
        return false;}

char* json_strassen_funtype_5(strassen_funtype_5_t x){char * result = safe_malloc(28); sprintf(result, "%s", "\"strassen_funtype_5\""); return result;}


strassen_record_6_t new_strassen_record_6(void){
        strassen_record_6_t tmp = (strassen_record_6_t) safe_malloc(sizeof(struct strassen_record_6_s));
        tmp->count = 1;
        return tmp;}

void release_strassen_record_6(strassen_record_6_t x){
        x->count--;
        if (x->count <= 0){
         mpz_clear(x->project_1);
         mpz_clear(x->project_2);
        //printf("\nFreeing\n");
        safe_free(x);}}

void release_strassen_record_6_ptr(pointer_t x, type_actual_t T){
        release_strassen_record_6((strassen_record_6_t)x);
}

strassen_record_6_t copy_strassen_record_6(strassen_record_6_t x){
        strassen_record_6_t y = new_strassen_record_6();
        mpz_set(y->project_1, x->project_1);
        mpz_set(y->project_2, x->project_2);
        y->count = 1;
        return y;}

bool_t equal_strassen_record_6(strassen_record_6_t x, strassen_record_6_t y){
        bool_t tmp = true; tmp = tmp && (mpz_cmp(x->project_1, y->project_1) == 0); tmp = tmp && (mpz_cmp(x->project_2, y->project_2) == 0);
        return tmp;}

char * json_strassen_record_6(strassen_record_6_t x){
        char * tmp[2]; 
        char * fld0 = safe_malloc(21);
         sprintf(fld0, "\"project_1\" : ");
        tmp[0] = safe_strcat(fld0, json_mpz(x->project_1));
        char * fld1 = safe_malloc(21);
         sprintf(fld1, "\"project_2\" : ");
        tmp[1] = safe_strcat(fld1, json_mpz(x->project_2));
         char * result = json_list_with_sep(tmp, 2,  '{', ',', '}');
         for (uint32_t i = 0; i < 2; i++) free(tmp[i]);
        return result;}

bool_t equal_strassen_record_6_ptr(pointer_t x, pointer_t y, actual_strassen_record_6_t T){
        return equal_strassen_record_6((strassen_record_6_t)x, (strassen_record_6_t)y);
}

char * json_strassen_record_6_ptr(pointer_t x, actual_strassen_record_6_t T){
        return json_strassen_record_6((strassen_record_6_t)x);
}

actual_strassen_record_6_t actual_strassen_record_6(void){
        actual_strassen_record_6_t new = (actual_strassen_record_6_t)safe_malloc(sizeof(struct actual_strassen_record_6_s));
        new->equal_ptr = (equal_ptr_t)(*equal_strassen_record_6_ptr);
 
        new->release_ptr = (release_ptr_t)(*release_strassen_record_6_ptr);
 
        new->json_ptr = (json_ptr_t)(*json_strassen_record_6_ptr);
 

 
        return new;
 }

strassen_record_6_t update_strassen_record_6_project_1(strassen_record_6_t x, mpz_ptr_t v){
        strassen_record_6_t y;
        if (x->count == 1){y = x;}
        else {y = copy_strassen_record_6(x); x->count--;};
        mpz_set(y->project_1, v);
        return y;}

strassen_record_6_t update_strassen_record_6_project_2(strassen_record_6_t x, mpz_ptr_t v){
        strassen_record_6_t y;
        if (x->count == 1){y = x;}
        else {y = copy_strassen_record_6(x); x->count--;};
        mpz_set(y->project_2, v);
        return y;}



void release_strassen_funtype_7(strassen_funtype_7_t x){
        x->count--;
            if (x->count <= 0)

                x->ftbl->rptr(x);}

strassen_funtype_7_t copy_strassen_funtype_7(strassen_funtype_7_t x){return x->ftbl->cptr(x);}

bool_t equal_strassen_funtype_7(strassen_funtype_7_t x, strassen_funtype_7_t y){
        return false;}

char* json_strassen_funtype_7(strassen_funtype_7_t x){char * result = safe_malloc(28); sprintf(result, "%s", "\"strassen_funtype_7\""); return result;}


strassen_record_8_t new_strassen_record_8(void){
        strassen_record_8_t tmp = (strassen_record_8_t) safe_malloc(sizeof(struct strassen_record_8_s));
        tmp->count = 1;
        return tmp;}

void release_strassen_record_8(strassen_record_8_t x){
        x->count--;
        if (x->count <= 0){
         release_strassen_array_1((strassen_array_1_t)x->project_1);
         release_strassen_array_1((strassen_array_1_t)x->project_2);
         release_strassen_array_1((strassen_array_1_t)x->project_3);
         release_strassen_array_1((strassen_array_1_t)x->project_4);
        //printf("\nFreeing\n");
        safe_free(x);}}

void release_strassen_record_8_ptr(pointer_t x, type_actual_t T){
        release_strassen_record_8((strassen_record_8_t)x);
}

strassen_record_8_t copy_strassen_record_8(strassen_record_8_t x){
        strassen_record_8_t y = new_strassen_record_8();
        y->project_1 = x->project_1;
        if (y->project_1 != NULL){y->project_1->count++;};
        y->project_2 = x->project_2;
        if (y->project_2 != NULL){y->project_2->count++;};
        y->project_3 = x->project_3;
        if (y->project_3 != NULL){y->project_3->count++;};
        y->project_4 = x->project_4;
        if (y->project_4 != NULL){y->project_4->count++;};
        y->count = 1;
        return y;}

bool_t equal_strassen_record_8(strassen_record_8_t x, strassen_record_8_t y){
        bool_t tmp = true; tmp = tmp && equal_strassen_array_1((strassen_array_1_t)x->project_1, (strassen_array_1_t)y->project_1); tmp = tmp && equal_strassen_array_1((strassen_array_1_t)x->project_2, (strassen_array_1_t)y->project_2); tmp = tmp && equal_strassen_array_1((strassen_array_1_t)x->project_3, (strassen_array_1_t)y->project_3); tmp = tmp && equal_strassen_array_1((strassen_array_1_t)x->project_4, (strassen_array_1_t)y->project_4);
        return tmp;}

char * json_strassen_record_8(strassen_record_8_t x){
        char * tmp[4]; 
        char * fld0 = safe_malloc(21);
         sprintf(fld0, "\"project_1\" : ");
        tmp[0] = safe_strcat(fld0, json_strassen_array_1((strassen_array_1_t)x->project_1));
        char * fld1 = safe_malloc(21);
         sprintf(fld1, "\"project_2\" : ");
        tmp[1] = safe_strcat(fld1, json_strassen_array_1((strassen_array_1_t)x->project_2));
        char * fld2 = safe_malloc(21);
         sprintf(fld2, "\"project_3\" : ");
        tmp[2] = safe_strcat(fld2, json_strassen_array_1((strassen_array_1_t)x->project_3));
        char * fld3 = safe_malloc(21);
         sprintf(fld3, "\"project_4\" : ");
        tmp[3] = safe_strcat(fld3, json_strassen_array_1((strassen_array_1_t)x->project_4));
         char * result = json_list_with_sep(tmp, 4,  '{', ',', '}');
         for (uint32_t i = 0; i < 4; i++) free(tmp[i]);
        return result;}

bool_t equal_strassen_record_8_ptr(pointer_t x, pointer_t y, actual_strassen_record_8_t T){
        return equal_strassen_record_8((strassen_record_8_t)x, (strassen_record_8_t)y);
}

char * json_strassen_record_8_ptr(pointer_t x, actual_strassen_record_8_t T){
        return json_strassen_record_8((strassen_record_8_t)x);
}

actual_strassen_record_8_t actual_strassen_record_8(void){
        actual_strassen_record_8_t new = (actual_strassen_record_8_t)safe_malloc(sizeof(struct actual_strassen_record_8_s));
        new->equal_ptr = (equal_ptr_t)(*equal_strassen_record_8_ptr);
 
        new->release_ptr = (release_ptr_t)(*release_strassen_record_8_ptr);
 
        new->json_ptr = (json_ptr_t)(*json_strassen_record_8_ptr);
 

 
        return new;
 }

strassen_record_8_t update_strassen_record_8_project_1(strassen_record_8_t x, strassen_array_1_t v){
        strassen_record_8_t y;
        if (v != NULL){v->count++;};
        if (x->count == 1){y = x; if (x->project_1 != NULL){release_strassen_array_1((strassen_array_1_t)x->project_1);};}
        else {y = copy_strassen_record_8(x); x->count--; y->project_1->count--;};
        y->project_1 = (strassen_array_1_t)v;
        return y;}

strassen_record_8_t update_strassen_record_8_project_2(strassen_record_8_t x, strassen_array_1_t v){
        strassen_record_8_t y;
        if (v != NULL){v->count++;};
        if (x->count == 1){y = x; if (x->project_2 != NULL){release_strassen_array_1((strassen_array_1_t)x->project_2);};}
        else {y = copy_strassen_record_8(x); x->count--; y->project_2->count--;};
        y->project_2 = (strassen_array_1_t)v;
        return y;}

strassen_record_8_t update_strassen_record_8_project_3(strassen_record_8_t x, strassen_array_1_t v){
        strassen_record_8_t y;
        if (v != NULL){v->count++;};
        if (x->count == 1){y = x; if (x->project_3 != NULL){release_strassen_array_1((strassen_array_1_t)x->project_3);};}
        else {y = copy_strassen_record_8(x); x->count--; y->project_3->count--;};
        y->project_3 = (strassen_array_1_t)v;
        return y;}

strassen_record_8_t update_strassen_record_8_project_4(strassen_record_8_t x, strassen_array_1_t v){
        strassen_record_8_t y;
        if (v != NULL){v->count++;};
        if (x->count == 1){y = x; if (x->project_4 != NULL){release_strassen_array_1((strassen_array_1_t)x->project_4);};}
        else {y = copy_strassen_record_8(x); x->count--; y->project_4->count--;};
        y->project_4 = (strassen_array_1_t)v;
        return y;}



void release_strassen_funtype_9(strassen_funtype_9_t x){
        x->count--;
            if (x->count <= 0)

                x->ftbl->rptr(x);}

strassen_funtype_9_t copy_strassen_funtype_9(strassen_funtype_9_t x){return x->ftbl->cptr(x);}

bool_t equal_strassen_funtype_9(strassen_funtype_9_t x, strassen_funtype_9_t y){
        return false;}

char* json_strassen_funtype_9(strassen_funtype_9_t x){char * result = safe_malloc(28); sprintf(result, "%s", "\"strassen_funtype_9\""); return result;}


strassen_array_1_t f_strassen_closure_10(struct strassen_closure_10_s * closure, strassen_record_8_t bvar){
        strassen_array_1_t bvar_1;
        bvar_1 = (strassen_array_1_t)bvar->project_1;
        bvar->project_1->count++;
        strassen_array_1_t bvar_2;
        bvar_2 = (strassen_array_1_t)bvar->project_2;
        bvar->project_2->count++;
        strassen_array_1_t bvar_3;
        bvar_3 = (strassen_array_1_t)bvar->project_3;
        bvar->project_3->count++;
        strassen_array_1_t bvar_4;
        bvar_4 = (strassen_array_1_t)bvar->project_4;
        bvar->project_4->count++;
        release_strassen_record_8((strassen_record_8_t)bvar);
        uint32_t fvar_1 = closure->fvar_1;
        release_strassen_funtype_9((strassen_funtype_9_t)closure);
        strassen_array_1_t result;
        result = (strassen_array_1_t)h_strassen_closure_10(bvar_1, bvar_2, bvar_3, bvar_4, fvar_1);
        return result;
}

strassen_array_1_t m_strassen_closure_10(struct strassen_closure_10_s * closure, strassen_array_1_t bvar_1, strassen_array_1_t bvar_2, strassen_array_1_t bvar_3, strassen_array_1_t bvar_4){
        uint32_t fvar_1 = closure->fvar_1;
        release_strassen_funtype_9((strassen_funtype_9_t)closure);
        return h_strassen_closure_10(bvar_1, bvar_2, bvar_3, bvar_4, fvar_1);}

strassen_array_1_t h_strassen_closure_10(strassen_array_1_t ivar_19, strassen_array_1_t ivar_20, strassen_array_1_t ivar_21, strassen_array_1_t ivar_22, uint32_t ivar_1){
        strassen_array_1_t result;

        strassen_funtype_3_t ivar_261;
        uint32_t ivar_305;
        uint8_t ivar_299;
        ivar_299 = (uint8_t)2;
        ivar_305 = (uint32_t)((uint64_t)ivar_299 * (uint64_t)ivar_1);
        ivar_261 = (strassen_funtype_3_t)matrix__stack((uint32_t)ivar_1, (uint32_t)ivar_1, (uint32_t)ivar_305);
        strassen_array_1_t ivar_306;
        strassen_funtype_3_t ivar_84;
        ivar_84 = (strassen_funtype_3_t)matrix__concat((uint32_t)ivar_1, (uint32_t)ivar_1, (uint32_t)ivar_1);
        strassen_array_1_t ivar_63;
        ivar_63 = (strassen_array_1_t)ivar_84->ftbl->mptr(ivar_84, ivar_19, ivar_20);
        //copying to strassen_array_1 from strassen_array_1;
        ivar_306 = (strassen_array_1_t)ivar_63;
        if (ivar_306 != NULL) ivar_306->count++;
        release_strassen_array_1((strassen_array_1_t)ivar_63);
        strassen_array_1_t ivar_307;
        strassen_funtype_3_t ivar_136;
        ivar_136 = (strassen_funtype_3_t)matrix__concat((uint32_t)ivar_1, (uint32_t)ivar_1, (uint32_t)ivar_1);
        strassen_array_1_t ivar_115;
        ivar_115 = (strassen_array_1_t)ivar_136->ftbl->mptr(ivar_136, ivar_21, ivar_22);
        //copying to strassen_array_1 from strassen_array_1;
        ivar_307 = (strassen_array_1_t)ivar_115;
        if (ivar_307 != NULL) ivar_307->count++;
        release_strassen_array_1((strassen_array_1_t)ivar_115);
        strassen_array_1_t ivar_192;
        ivar_192 = (strassen_array_1_t)ivar_261->ftbl->mptr(ivar_261, ivar_306, ivar_307);
        //copying to strassen_array_1 from strassen_array_1;
        result = (strassen_array_1_t)ivar_192;
        if (result != NULL) result->count++;
        release_strassen_array_1((strassen_array_1_t)ivar_192);
        return result;
}

strassen_closure_10_t new_strassen_closure_10(void){
        static struct strassen_funtype_9_ftbl_s ftbl = {.fptr = (strassen_array_1_t (*)(strassen_funtype_9_t, strassen_record_8_t))&f_strassen_closure_10, .mptr = (strassen_array_1_t (*)(strassen_funtype_9_t, strassen_array_1_t, strassen_array_1_t, strassen_array_1_t, strassen_array_1_t))&m_strassen_closure_10, .rptr =  (void (*)(strassen_funtype_9_t))&release_strassen_closure_10, .cptr = (strassen_funtype_9_t (*)(strassen_funtype_9_t))&copy_strassen_closure_10};
        strassen_closure_10_t tmp = (strassen_closure_10_t) safe_malloc(sizeof(struct strassen_closure_10_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_strassen_closure_10(strassen_funtype_9_t closure){
        strassen_closure_10_t x = (strassen_closure_10_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_strassen_record_8((strassen_record_8_t)x->htbl->data[j].key); release_strassen_array_1((strassen_array_1_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

strassen_closure_10_t copy_strassen_closure_10(strassen_closure_10_t x){
        strassen_closure_10_t y = new_strassen_closure_10();
        y->ftbl = x->ftbl;

        y->fvar_1 = (uint32_t)x->fvar_1;
        if (x->htbl != NULL){
            strassen_funtype_9_htbl_t new_htbl = (strassen_funtype_9_htbl_t) safe_malloc(sizeof(struct strassen_funtype_9_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            strassen_funtype_9_hashentry_t * new_data = (strassen_funtype_9_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct strassen_funtype_9_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (strassen_record_8_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (strassen_array_1_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}


strassen_array_1_t f_strassen_closure_11(struct strassen_closure_11_s * closure, strassen_record_2_t bvar){
        strassen_array_1_t bvar_1;
        bvar_1 = (strassen_array_1_t)bvar->project_1;
        bvar->project_1->count++;
        strassen_array_1_t bvar_2;
        bvar_2 = (strassen_array_1_t)bvar->project_2;
        bvar->project_2->count++;
        release_strassen_record_2((strassen_record_2_t)bvar);
        uint32_t fvar_1 = closure->fvar_1;
        release_strassen_funtype_3((strassen_funtype_3_t)closure);
        strassen_array_1_t result;
        result = (strassen_array_1_t)h_strassen_closure_11(bvar_1, bvar_2, fvar_1);
        return result;
}

strassen_array_1_t m_strassen_closure_11(struct strassen_closure_11_s * closure, strassen_array_1_t bvar_1, strassen_array_1_t bvar_2){
        uint32_t fvar_1 = closure->fvar_1;
        release_strassen_funtype_3((strassen_funtype_3_t)closure);
        return h_strassen_closure_11(bvar_1, bvar_2, fvar_1);}

strassen_array_1_t h_strassen_closure_11(strassen_array_1_t ivar_65, strassen_array_1_t ivar_78, uint32_t ivar_1){
        strassen_array_1_t result;

        bool_t ivar_103;
        uint8_t ivar_105;
        ivar_105 = (uint8_t)0;
        ivar_103 = (ivar_1 == ivar_105);
        if (ivar_103){
             uint8_t ivar_125;
             ivar_125 = (uint8_t)1;
             mpz_ptr_t ivar_115;
             //copying to mpz from uint8;
             mpz_mk_set_ui(ivar_115, ivar_125);
             uint8_t ivar_124;
             ivar_124 = (uint8_t)1;
             mpz_ptr_t ivar_116;
             //copying to mpz from uint8;
             mpz_mk_set_ui(ivar_116, ivar_124);
             uint8_t ivar_123;
             ivar_123 = (uint8_t)1;
             mpz_ptr_t ivar_117;
             //copying to mpz from uint8;
             mpz_mk_set_ui(ivar_117, ivar_123);
             strassen_array_1_t ivar_114;
             ivar_114 = (strassen_array_1_t)matrix__mmult((mpz_ptr_t)ivar_115, (mpz_ptr_t)ivar_116, (mpz_ptr_t)ivar_117, (matrix__matrix_t)ivar_65, (matrix__matrix_t)ivar_78);
             //copying to strassen_array_1 from strassen_array_1;
             result = (strassen_array_1_t)ivar_114;
             if (result != NULL) result->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_114);
        } else {
             /* h */ uint32_t ivar_126;
             int32_t ivar_134;
             uint8_t ivar_129;
             ivar_129 = (uint8_t)1;
             ivar_134 = (int32_t)((uint64_t)ivar_1 - (uint64_t)ivar_129);
             uint32_t ivar_132;
             //copying to uint32 from int32;
             ivar_132 = (uint32_t)ivar_134;
             ivar_126 = (uint32_t)strassen__dim((uint32_t)ivar_132);
             /* A11 */ strassen_array_1_t ivar_185;
             strassen_funtype_5_t ivar_214;
             ivar_214 = (strassen_funtype_5_t)strassen__tl((uint32_t)ivar_126);
             strassen_array_1_t ivar_187;
             ivar_65->count++;
             ivar_187 = (strassen_array_1_t)ivar_214->ftbl->fptr(ivar_214, ivar_65);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_185 = (strassen_array_1_t)ivar_187;
             if (ivar_185 != NULL) ivar_185->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_187);
             /* A12 */ strassen_array_1_t ivar_232;
             strassen_funtype_5_t ivar_261;
             ivar_261 = (strassen_funtype_5_t)strassen__tr((uint32_t)ivar_126);
             strassen_array_1_t ivar_234;
             ivar_65->count++;
             ivar_234 = (strassen_array_1_t)ivar_261->ftbl->fptr(ivar_261, ivar_65);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_232 = (strassen_array_1_t)ivar_234;
             if (ivar_232 != NULL) ivar_232->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_234);
             /* A21 */ strassen_array_1_t ivar_279;
             strassen_funtype_5_t ivar_308;
             ivar_308 = (strassen_funtype_5_t)strassen__bl((uint32_t)ivar_126);
             strassen_array_1_t ivar_281;
             ivar_65->count++;
             ivar_281 = (strassen_array_1_t)ivar_308->ftbl->fptr(ivar_308, ivar_65);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_279 = (strassen_array_1_t)ivar_281;
             if (ivar_279 != NULL) ivar_279->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_281);
             /* A22 */ strassen_array_1_t ivar_326;
             strassen_funtype_5_t ivar_355;
             ivar_355 = (strassen_funtype_5_t)strassen__br((uint32_t)ivar_126);
             strassen_array_1_t ivar_328;
             ivar_328 = (strassen_array_1_t)ivar_355->ftbl->fptr(ivar_355, ivar_65);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_326 = (strassen_array_1_t)ivar_328;
             if (ivar_326 != NULL) ivar_326->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_328);
             /* B11 */ strassen_array_1_t ivar_373;
             strassen_funtype_5_t ivar_402;
             ivar_402 = (strassen_funtype_5_t)strassen__tl((uint32_t)ivar_126);
             strassen_array_1_t ivar_375;
             ivar_78->count++;
             ivar_375 = (strassen_array_1_t)ivar_402->ftbl->fptr(ivar_402, ivar_78);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_373 = (strassen_array_1_t)ivar_375;
             if (ivar_373 != NULL) ivar_373->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_375);
             /* B12 */ strassen_array_1_t ivar_420;
             strassen_funtype_5_t ivar_449;
             ivar_449 = (strassen_funtype_5_t)strassen__tr((uint32_t)ivar_126);
             strassen_array_1_t ivar_422;
             ivar_78->count++;
             ivar_422 = (strassen_array_1_t)ivar_449->ftbl->fptr(ivar_449, ivar_78);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_420 = (strassen_array_1_t)ivar_422;
             if (ivar_420 != NULL) ivar_420->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_422);
             /* B21 */ strassen_array_1_t ivar_467;
             strassen_funtype_5_t ivar_496;
             ivar_496 = (strassen_funtype_5_t)strassen__bl((uint32_t)ivar_126);
             strassen_array_1_t ivar_469;
             ivar_78->count++;
             ivar_469 = (strassen_array_1_t)ivar_496->ftbl->fptr(ivar_496, ivar_78);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_467 = (strassen_array_1_t)ivar_469;
             if (ivar_467 != NULL) ivar_467->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_469);
             /* B22 */ strassen_array_1_t ivar_514;
             strassen_funtype_5_t ivar_543;
             ivar_543 = (strassen_funtype_5_t)strassen__br((uint32_t)ivar_126);
             strassen_array_1_t ivar_516;
             ivar_516 = (strassen_array_1_t)ivar_543->ftbl->fptr(ivar_543, ivar_78);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_514 = (strassen_array_1_t)ivar_516;
             if (ivar_514 != NULL) ivar_514->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_516);
             /* M1 */ strassen_array_1_t ivar_561;
             strassen_funtype_3_t ivar_851;
             int32_t ivar_956;
             uint8_t ivar_951;
             ivar_951 = (uint8_t)1;
             ivar_956 = (int32_t)((uint64_t)ivar_1 - (uint64_t)ivar_951);
             uint32_t ivar_954;
             //copying to uint32 from int32;
             ivar_954 = (uint32_t)ivar_956;
             ivar_851 = (strassen_funtype_3_t)strassen__strassen((uint32_t)ivar_954);
             strassen_array_1_t ivar_957;
             strassen_funtype_3_t ivar_633;
             ivar_633 = (strassen_funtype_3_t)matrix__madd((uint32_t)ivar_126, (uint32_t)ivar_126);
             strassen_array_1_t ivar_630;
             ivar_185->count++;
             ivar_326->count++;
             ivar_630 = (strassen_array_1_t)ivar_633->ftbl->mptr(ivar_633, ivar_185, ivar_326);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_957 = (strassen_array_1_t)ivar_630;
             if (ivar_957 != NULL) ivar_957->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_630);
             strassen_array_1_t ivar_958;
             strassen_funtype_3_t ivar_647;
             ivar_647 = (strassen_funtype_3_t)matrix__madd((uint32_t)ivar_126, (uint32_t)ivar_126);
             strassen_array_1_t ivar_644;
             ivar_373->count++;
             ivar_514->count++;
             ivar_644 = (strassen_array_1_t)ivar_647->ftbl->mptr(ivar_647, ivar_373, ivar_514);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_958 = (strassen_array_1_t)ivar_644;
             if (ivar_958 != NULL) ivar_958->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_644);
             strassen_array_1_t ivar_656;
             ivar_656 = (strassen_array_1_t)ivar_851->ftbl->mptr(ivar_851, ivar_957, ivar_958);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_561 = (strassen_array_1_t)ivar_656;
             if (ivar_561 != NULL) ivar_561->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_656);
             /* M2 */ strassen_array_1_t ivar_959;
             strassen_funtype_3_t ivar_1235;
             int32_t ivar_1340;
             uint8_t ivar_1335;
             ivar_1335 = (uint8_t)1;
             ivar_1340 = (int32_t)((uint64_t)ivar_1 - (uint64_t)ivar_1335);
             uint32_t ivar_1338;
             //copying to uint32 from int32;
             ivar_1338 = (uint32_t)ivar_1340;
             ivar_1235 = (strassen_funtype_3_t)strassen__strassen((uint32_t)ivar_1338);
             strassen_array_1_t ivar_1341;
             strassen_funtype_3_t ivar_1031;
             ivar_1031 = (strassen_funtype_3_t)matrix__madd((uint32_t)ivar_126, (uint32_t)ivar_126);
             strassen_array_1_t ivar_1028;
             ivar_279->count++;
             ivar_326->count++;
             ivar_1028 = (strassen_array_1_t)ivar_1031->ftbl->mptr(ivar_1031, ivar_279, ivar_326);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_1341 = (strassen_array_1_t)ivar_1028;
             if (ivar_1341 != NULL) ivar_1341->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_1028);
             strassen_array_1_t ivar_1040;
             ivar_373->count++;
             ivar_1040 = (strassen_array_1_t)ivar_1235->ftbl->mptr(ivar_1235, ivar_1341, ivar_373);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_959 = (strassen_array_1_t)ivar_1040;
             if (ivar_959 != NULL) ivar_959->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_1040);
             /* M3 */ strassen_array_1_t ivar_1343;
             strassen_funtype_3_t ivar_1617;
             int32_t ivar_1722;
             uint8_t ivar_1717;
             ivar_1717 = (uint8_t)1;
             ivar_1722 = (int32_t)((uint64_t)ivar_1 - (uint64_t)ivar_1717);
             uint32_t ivar_1720;
             //copying to uint32 from int32;
             ivar_1720 = (uint32_t)ivar_1722;
             ivar_1617 = (strassen_funtype_3_t)strassen__strassen((uint32_t)ivar_1720);
             strassen_array_1_t ivar_1724;
             strassen_funtype_3_t ivar_1415;
             ivar_1415 = (strassen_funtype_3_t)strassen__msub((uint32_t)ivar_126);
             strassen_array_1_t ivar_1412;
             ivar_420->count++;
             ivar_514->count++;
             ivar_1412 = (strassen_array_1_t)ivar_1415->ftbl->mptr(ivar_1415, ivar_420, ivar_514);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_1724 = (strassen_array_1_t)ivar_1412;
             if (ivar_1724 != NULL) ivar_1724->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_1412);
             strassen_array_1_t ivar_1422;
             ivar_185->count++;
             ivar_1422 = (strassen_array_1_t)ivar_1617->ftbl->mptr(ivar_1617, ivar_185, ivar_1724);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_1343 = (strassen_array_1_t)ivar_1422;
             if (ivar_1343 != NULL) ivar_1343->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_1422);
             /* M4 */ strassen_array_1_t ivar_1725;
             strassen_funtype_3_t ivar_1999;
             int32_t ivar_2104;
             uint8_t ivar_2099;
             ivar_2099 = (uint8_t)1;
             ivar_2104 = (int32_t)((uint64_t)ivar_1 - (uint64_t)ivar_2099);
             uint32_t ivar_2102;
             //copying to uint32 from int32;
             ivar_2102 = (uint32_t)ivar_2104;
             ivar_1999 = (strassen_funtype_3_t)strassen__strassen((uint32_t)ivar_2102);
             strassen_array_1_t ivar_2106;
             strassen_funtype_3_t ivar_1797;
             ivar_1797 = (strassen_funtype_3_t)strassen__msub((uint32_t)ivar_126);
             strassen_array_1_t ivar_1794;
             ivar_467->count++;
             ivar_373->count++;
             ivar_1794 = (strassen_array_1_t)ivar_1797->ftbl->mptr(ivar_1797, ivar_467, ivar_373);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_2106 = (strassen_array_1_t)ivar_1794;
             if (ivar_2106 != NULL) ivar_2106->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_1794);
             strassen_array_1_t ivar_1804;
             ivar_326->count++;
             ivar_1804 = (strassen_array_1_t)ivar_1999->ftbl->mptr(ivar_1999, ivar_326, ivar_2106);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_1725 = (strassen_array_1_t)ivar_1804;
             if (ivar_1725 != NULL) ivar_1725->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_1804);
             /* M5 */ strassen_array_1_t ivar_2107;
             strassen_funtype_3_t ivar_2383;
             int32_t ivar_2488;
             uint8_t ivar_2483;
             ivar_2483 = (uint8_t)1;
             ivar_2488 = (int32_t)((uint64_t)ivar_1 - (uint64_t)ivar_2483);
             uint32_t ivar_2486;
             //copying to uint32 from int32;
             ivar_2486 = (uint32_t)ivar_2488;
             ivar_2383 = (strassen_funtype_3_t)strassen__strassen((uint32_t)ivar_2486);
             strassen_array_1_t ivar_2489;
             strassen_funtype_3_t ivar_2179;
             ivar_2179 = (strassen_funtype_3_t)matrix__madd((uint32_t)ivar_126, (uint32_t)ivar_126);
             strassen_array_1_t ivar_2176;
             ivar_185->count++;
             ivar_232->count++;
             ivar_2176 = (strassen_array_1_t)ivar_2179->ftbl->mptr(ivar_2179, ivar_185, ivar_232);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_2489 = (strassen_array_1_t)ivar_2176;
             if (ivar_2489 != NULL) ivar_2489->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_2176);
             strassen_array_1_t ivar_2188;
             ivar_514->count++;
             ivar_2188 = (strassen_array_1_t)ivar_2383->ftbl->mptr(ivar_2383, ivar_2489, ivar_514);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_2107 = (strassen_array_1_t)ivar_2188;
             if (ivar_2107 != NULL) ivar_2107->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_2188);
             /* M6 */ strassen_array_1_t ivar_2491;
             strassen_funtype_3_t ivar_2779;
             int32_t ivar_2884;
             uint8_t ivar_2879;
             ivar_2879 = (uint8_t)1;
             ivar_2884 = (int32_t)((uint64_t)ivar_1 - (uint64_t)ivar_2879);
             uint32_t ivar_2882;
             //copying to uint32 from int32;
             ivar_2882 = (uint32_t)ivar_2884;
             ivar_2779 = (strassen_funtype_3_t)strassen__strassen((uint32_t)ivar_2882);
             strassen_array_1_t ivar_2885;
             strassen_funtype_3_t ivar_2563;
             ivar_2563 = (strassen_funtype_3_t)strassen__msub((uint32_t)ivar_126);
             strassen_array_1_t ivar_2560;
             ivar_2560 = (strassen_array_1_t)ivar_2563->ftbl->mptr(ivar_2563, ivar_279, ivar_185);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_2885 = (strassen_array_1_t)ivar_2560;
             if (ivar_2885 != NULL) ivar_2885->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_2560);
             strassen_array_1_t ivar_2886;
             strassen_funtype_3_t ivar_2575;
             ivar_2575 = (strassen_funtype_3_t)matrix__madd((uint32_t)ivar_126, (uint32_t)ivar_126);
             strassen_array_1_t ivar_2572;
             ivar_2572 = (strassen_array_1_t)ivar_2575->ftbl->mptr(ivar_2575, ivar_373, ivar_420);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_2886 = (strassen_array_1_t)ivar_2572;
             if (ivar_2886 != NULL) ivar_2886->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_2572);
             strassen_array_1_t ivar_2584;
             ivar_2584 = (strassen_array_1_t)ivar_2779->ftbl->mptr(ivar_2779, ivar_2885, ivar_2886);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_2491 = (strassen_array_1_t)ivar_2584;
             if (ivar_2491 != NULL) ivar_2491->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_2584);
             /* M7 */ strassen_array_1_t ivar_2887;
             strassen_funtype_3_t ivar_3175;
             int32_t ivar_3280;
             uint8_t ivar_3275;
             ivar_3275 = (uint8_t)1;
             ivar_3280 = (int32_t)((uint64_t)ivar_1 - (uint64_t)ivar_3275);
             uint32_t ivar_3278;
             //copying to uint32 from int32;
             ivar_3278 = (uint32_t)ivar_3280;
             ivar_3175 = (strassen_funtype_3_t)strassen__strassen((uint32_t)ivar_3278);
             strassen_array_1_t ivar_3281;
             strassen_funtype_3_t ivar_2959;
             ivar_2959 = (strassen_funtype_3_t)strassen__msub((uint32_t)ivar_126);
             strassen_array_1_t ivar_2956;
             ivar_2956 = (strassen_array_1_t)ivar_2959->ftbl->mptr(ivar_2959, ivar_232, ivar_326);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_3281 = (strassen_array_1_t)ivar_2956;
             if (ivar_3281 != NULL) ivar_3281->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_2956);
             strassen_array_1_t ivar_3282;
             strassen_funtype_3_t ivar_2971;
             ivar_2971 = (strassen_funtype_3_t)matrix__madd((uint32_t)ivar_126, (uint32_t)ivar_126);
             strassen_array_1_t ivar_2968;
             ivar_2968 = (strassen_array_1_t)ivar_2971->ftbl->mptr(ivar_2971, ivar_467, ivar_514);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_3282 = (strassen_array_1_t)ivar_2968;
             if (ivar_3282 != NULL) ivar_3282->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_2968);
             strassen_array_1_t ivar_2980;
             ivar_2980 = (strassen_array_1_t)ivar_3175->ftbl->mptr(ivar_3175, ivar_3281, ivar_3282);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_2887 = (strassen_array_1_t)ivar_2980;
             if (ivar_2887 != NULL) ivar_2887->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_2980);
             /* C11 */ strassen_array_1_t ivar_3283;
             strassen_funtype_3_t ivar_3317;
             ivar_3317 = (strassen_funtype_3_t)strassen__msub((uint32_t)ivar_126);
             strassen_array_1_t ivar_3322;
             strassen_funtype_3_t ivar_3305;
             ivar_3305 = (strassen_funtype_3_t)matrix__madd((uint32_t)ivar_126, (uint32_t)ivar_126);
             strassen_array_1_t ivar_3312;
             strassen_funtype_3_t ivar_3293;
             ivar_3293 = (strassen_funtype_3_t)matrix__madd((uint32_t)ivar_126, (uint32_t)ivar_126);
             strassen_array_1_t ivar_3290;
             ivar_561->count++;
             ivar_1725->count++;
             ivar_3290 = (strassen_array_1_t)ivar_3293->ftbl->mptr(ivar_3293, ivar_561, ivar_1725);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_3312 = (strassen_array_1_t)ivar_3290;
             if (ivar_3312 != NULL) ivar_3312->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_3290);
             strassen_array_1_t ivar_3302;
             ivar_3302 = (strassen_array_1_t)ivar_3305->ftbl->mptr(ivar_3305, ivar_3312, ivar_2887);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_3322 = (strassen_array_1_t)ivar_3302;
             if (ivar_3322 != NULL) ivar_3322->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_3302);
             strassen_array_1_t ivar_3314;
             ivar_2107->count++;
             ivar_3314 = (strassen_array_1_t)ivar_3317->ftbl->mptr(ivar_3317, ivar_3322, ivar_2107);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_3283 = (strassen_array_1_t)ivar_3314;
             if (ivar_3283 != NULL) ivar_3283->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_3314);
             /* C12 */ strassen_array_1_t ivar_3324;
             strassen_funtype_3_t ivar_3330;
             ivar_3330 = (strassen_funtype_3_t)matrix__madd((uint32_t)ivar_126, (uint32_t)ivar_126);
             strassen_array_1_t ivar_3327;
             ivar_1343->count++;
             ivar_3327 = (strassen_array_1_t)ivar_3330->ftbl->mptr(ivar_3330, ivar_1343, ivar_2107);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_3324 = (strassen_array_1_t)ivar_3327;
             if (ivar_3324 != NULL) ivar_3324->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_3327);
             /* C21 */ strassen_array_1_t ivar_3339;
             strassen_funtype_3_t ivar_3345;
             ivar_3345 = (strassen_funtype_3_t)matrix__madd((uint32_t)ivar_126, (uint32_t)ivar_126);
             strassen_array_1_t ivar_3342;
             ivar_959->count++;
             ivar_3342 = (strassen_array_1_t)ivar_3345->ftbl->mptr(ivar_3345, ivar_959, ivar_1725);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_3339 = (strassen_array_1_t)ivar_3342;
             if (ivar_3339 != NULL) ivar_3339->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_3342);
             /* C22 */ strassen_array_1_t ivar_3354;
             strassen_funtype_3_t ivar_3386;
             ivar_3386 = (strassen_funtype_3_t)matrix__madd((uint32_t)ivar_126, (uint32_t)ivar_126);
             strassen_array_1_t ivar_3393;
             strassen_funtype_3_t ivar_3376;
             ivar_3376 = (strassen_funtype_3_t)strassen__msub((uint32_t)ivar_126);
             strassen_array_1_t ivar_3381;
             strassen_funtype_3_t ivar_3364;
             ivar_3364 = (strassen_funtype_3_t)matrix__madd((uint32_t)ivar_126, (uint32_t)ivar_126);
             strassen_array_1_t ivar_3361;
             ivar_3361 = (strassen_array_1_t)ivar_3364->ftbl->mptr(ivar_3364, ivar_561, ivar_1343);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_3381 = (strassen_array_1_t)ivar_3361;
             if (ivar_3381 != NULL) ivar_3381->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_3361);
             strassen_array_1_t ivar_3373;
             ivar_3373 = (strassen_array_1_t)ivar_3376->ftbl->mptr(ivar_3376, ivar_3381, ivar_959);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_3393 = (strassen_array_1_t)ivar_3373;
             if (ivar_3393 != NULL) ivar_3393->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_3373);
             strassen_array_1_t ivar_3383;
             ivar_3383 = (strassen_array_1_t)ivar_3386->ftbl->mptr(ivar_3386, ivar_3393, ivar_2491);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_3354 = (strassen_array_1_t)ivar_3383;
             if (ivar_3354 != NULL) ivar_3354->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_3383);
             /* C */ strassen_array_1_t ivar_3395;
             strassen_funtype_9_t ivar_3451;
             ivar_3451 = (strassen_funtype_9_t)strassen__join4((uint32_t)ivar_126);
             strassen_array_1_t ivar_3424;
             ivar_3424 = (strassen_array_1_t)ivar_3451->ftbl->mptr(ivar_3451, ivar_3283, ivar_3324, ivar_3339, ivar_3354);
             //copying to strassen_array_1 from strassen_array_1;
             ivar_3395 = (strassen_array_1_t)ivar_3424;
             if (ivar_3395 != NULL) ivar_3395->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_3424);
             //copying to strassen_array_1 from strassen_array_1;
             result = (strassen_array_1_t)ivar_3395;
             if (result != NULL) result->count++;
             release_strassen_array_1((strassen_array_1_t)ivar_3395);};
        return result;
}

strassen_closure_11_t new_strassen_closure_11(void){
        static struct strassen_funtype_3_ftbl_s ftbl = {.fptr = (strassen_array_1_t (*)(strassen_funtype_3_t, strassen_record_2_t))&f_strassen_closure_11, .mptr = (strassen_array_1_t (*)(strassen_funtype_3_t, strassen_array_1_t, strassen_array_1_t))&m_strassen_closure_11, .rptr =  (void (*)(strassen_funtype_3_t))&release_strassen_closure_11, .cptr = (strassen_funtype_3_t (*)(strassen_funtype_3_t))&copy_strassen_closure_11};
        strassen_closure_11_t tmp = (strassen_closure_11_t) safe_malloc(sizeof(struct strassen_closure_11_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_strassen_closure_11(strassen_funtype_3_t closure){
        strassen_closure_11_t x = (strassen_closure_11_t)closure;
        x->count--;
        if (x->count <= 0){
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){release_strassen_record_2((strassen_record_2_t)x->htbl->data[j].key); release_strassen_array_1((strassen_array_1_t)x->htbl->data[j].value);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

strassen_closure_11_t copy_strassen_closure_11(strassen_closure_11_t x){
        strassen_closure_11_t y = new_strassen_closure_11();
        y->ftbl = x->ftbl;

        y->fvar_1 = (uint32_t)x->fvar_1;
        if (x->htbl != NULL){
            strassen_funtype_3_htbl_t new_htbl = (strassen_funtype_3_htbl_t) safe_malloc(sizeof(struct strassen_funtype_3_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            strassen_funtype_3_hashentry_t * new_data = (strassen_funtype_3_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct strassen_funtype_3_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  new_data[j].key = (strassen_record_2_t)x->htbl->data[j].key;
                  if (new_data[j].key != NULL) new_data[j].key->count++;
                  new_data[j].value = (strassen_array_1_t)x->htbl->data[j].value;
                  if (new_data[j].value != NULL) new_data[j].value->count++;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}
uint32_t strassen__dim(uint32_t ivar_1){
        uint32_t  result;

        bool_t ivar_2;
        uint8_t ivar_4;
        ivar_4 = (uint8_t)0;
        ivar_2 = (ivar_1 == ivar_4);
        if (ivar_2){
             result = (uint32_t)1;
        } else {
             uint8_t ivar_6;
             ivar_6 = (uint8_t)2;
             uint32_t ivar_7;
             int32_t ivar_15;
             uint8_t ivar_10;
             ivar_10 = (uint8_t)1;
             ivar_15 = (int32_t)((uint64_t)ivar_1 - (uint64_t)ivar_10);
             uint32_t ivar_13;
             //copying to uint32 from int32;
             ivar_13 = (uint32_t)ivar_15;
             ivar_7 = (uint32_t)strassen__dim((uint32_t)ivar_13);
             result = (uint32_t)((uint64_t)ivar_6 * (uint64_t)ivar_7);};
        
        
        return result;
}

strassen_funtype_3_t strassen__msub(uint32_t ivar_1){
        strassen_funtype_3_t  result;

        strassen_closure_4_t cl7848;
        cl7848 = new_strassen_closure_4();
        result = (strassen_funtype_3_t)cl7848;
        
        
        return result;
}

strassen_funtype_5_t strassen__tl(uint32_t ivar_1){
        strassen_funtype_5_t  result;

        strassen_funtype_7_t ivar_218;
        uint32_t ivar_307;
        uint8_t ivar_300;
        ivar_300 = (uint8_t)2;
        ivar_307 = (uint32_t)((uint64_t)ivar_300 * (uint64_t)ivar_1);
        uint32_t ivar_308;
        uint8_t ivar_303;
        ivar_303 = (uint8_t)2;
        ivar_308 = (uint32_t)((uint64_t)ivar_303 * (uint64_t)ivar_1);
        ivar_218 = (strassen_funtype_7_t)matrix__topleft((uint32_t)ivar_307, (uint32_t)ivar_308);
        mpz_ptr_t ivar_309;
        //copying to mpz from uint32;
        mpz_mk_set_ui(ivar_309, ivar_1);
        mpz_ptr_t ivar_310;
        //copying to mpz from uint32;
        mpz_mk_set_ui(ivar_310, ivar_1);
        result = (strassen_funtype_5_t)ivar_218->ftbl->mptr(ivar_218, ivar_309, ivar_310);
        
        
        return result;
}

strassen_funtype_5_t strassen__tr(uint32_t ivar_1){
        strassen_funtype_5_t  result;

        strassen_funtype_7_t ivar_266;
        uint32_t ivar_379;
        uint8_t ivar_372;
        ivar_372 = (uint8_t)2;
        ivar_379 = (uint32_t)((uint64_t)ivar_372 * (uint64_t)ivar_1);
        uint32_t ivar_380;
        uint8_t ivar_375;
        ivar_375 = (uint8_t)2;
        ivar_380 = (uint32_t)((uint64_t)ivar_375 * (uint64_t)ivar_1);
        ivar_266 = (strassen_funtype_7_t)matrix__topright((uint32_t)ivar_379, (uint32_t)ivar_380);
        mpz_ptr_t ivar_381;
        //copying to mpz from uint32;
        mpz_mk_set_ui(ivar_381, ivar_1);
        mpz_ptr_t ivar_382;
        //copying to mpz from uint32;
        mpz_mk_set_ui(ivar_382, ivar_1);
        result = (strassen_funtype_5_t)ivar_266->ftbl->mptr(ivar_266, ivar_381, ivar_382);
        
        
        return result;
}

strassen_funtype_5_t strassen__bl(uint32_t ivar_1){
        strassen_funtype_5_t  result;

        strassen_funtype_7_t ivar_248;
        uint32_t ivar_352;
        uint8_t ivar_345;
        ivar_345 = (uint8_t)2;
        ivar_352 = (uint32_t)((uint64_t)ivar_345 * (uint64_t)ivar_1);
        uint32_t ivar_353;
        uint8_t ivar_348;
        ivar_348 = (uint8_t)2;
        ivar_353 = (uint32_t)((uint64_t)ivar_348 * (uint64_t)ivar_1);
        ivar_248 = (strassen_funtype_7_t)matrix__botleft((uint32_t)ivar_352, (uint32_t)ivar_353);
        mpz_ptr_t ivar_354;
        //copying to mpz from uint32;
        mpz_mk_set_ui(ivar_354, ivar_1);
        mpz_ptr_t ivar_355;
        //copying to mpz from uint32;
        mpz_mk_set_ui(ivar_355, ivar_1);
        result = (strassen_funtype_5_t)ivar_248->ftbl->mptr(ivar_248, ivar_354, ivar_355);
        
        
        return result;
}

strassen_funtype_5_t strassen__br(uint32_t ivar_1){
        strassen_funtype_5_t  result;

        strassen_funtype_7_t ivar_296;
        uint32_t ivar_424;
        uint8_t ivar_417;
        ivar_417 = (uint8_t)2;
        ivar_424 = (uint32_t)((uint64_t)ivar_417 * (uint64_t)ivar_1);
        uint32_t ivar_425;
        uint8_t ivar_420;
        ivar_420 = (uint8_t)2;
        ivar_425 = (uint32_t)((uint64_t)ivar_420 * (uint64_t)ivar_1);
        ivar_296 = (strassen_funtype_7_t)matrix__botright((uint32_t)ivar_424, (uint32_t)ivar_425);
        mpz_ptr_t ivar_426;
        //copying to mpz from uint32;
        mpz_mk_set_ui(ivar_426, ivar_1);
        mpz_ptr_t ivar_427;
        //copying to mpz from uint32;
        mpz_mk_set_ui(ivar_427, ivar_1);
        result = (strassen_funtype_5_t)ivar_296->ftbl->mptr(ivar_296, ivar_426, ivar_427);
        
        
        return result;
}

strassen_funtype_9_t strassen__join4(uint32_t ivar_1){
        strassen_funtype_9_t  result;

        strassen_closure_10_t cl8033;
        cl8033 = new_strassen_closure_10();
        cl8033->fvar_1 = (uint32_t)ivar_1;
        result = (strassen_funtype_9_t)cl8033;
        
        
        return result;
}

strassen_funtype_3_t strassen__strassen(uint32_t ivar_1){
        strassen_funtype_3_t  result;

        strassen_closure_11_t cl8201;
        cl8201 = new_strassen_closure_11();
        cl8201->fvar_1 = (uint32_t)ivar_1;
        result = (strassen_funtype_3_t)cl8201;
        
        
        return result;
}

bool_t strassen__strassen_id_2(void){
        bool_t  static  result;

        static bool_t defined = false;
        if (!defined){
            
        strassen_array_1_t ivar_1;
        strassen_funtype_3_t ivar_184;
        uint8_t ivar_220;
        ivar_220 = (uint8_t)1;
        uint32_t ivar_218;
        //copying to uint32 from uint8;
        ivar_218 = (uint32_t)ivar_220;
        ivar_184 = (strassen_funtype_3_t)strassen__strassen((uint32_t)ivar_218);
        strassen_array_1_t ivar_221;
        uint32_t ivar_37;
        uint8_t ivar_35;
        ivar_35 = (uint8_t)1;
        uint32_t ivar_33;
        //copying to uint32 from uint8;
        ivar_33 = (uint32_t)ivar_35;
        ivar_37 = (uint32_t)strassen__dim((uint32_t)ivar_33);
        strassen_array_1_t ivar_36;
        ivar_36 = (strassen_array_1_t)matrix__I((uint32_t)ivar_37);
        //copying to strassen_array_1 from strassen_array_1;
        ivar_221 = (strassen_array_1_t)ivar_36;
        if (ivar_221 != NULL) ivar_221->count++;
        release_strassen_array_1((strassen_array_1_t)ivar_36);
        strassen_array_1_t ivar_222;
        uint32_t ivar_60;
        uint8_t ivar_58;
        ivar_58 = (uint8_t)1;
        uint32_t ivar_56;
        //copying to uint32 from uint8;
        ivar_56 = (uint32_t)ivar_58;
        ivar_60 = (uint32_t)strassen__dim((uint32_t)ivar_56);
        strassen_array_1_t ivar_59;
        ivar_59 = (strassen_array_1_t)matrix__I((uint32_t)ivar_60);
        //copying to strassen_array_1 from strassen_array_1;
        ivar_222 = (strassen_array_1_t)ivar_59;
        if (ivar_222 != NULL) ivar_222->count++;
        release_strassen_array_1((strassen_array_1_t)ivar_59);
        strassen_array_1_t ivar_121;
        ivar_121 = (strassen_array_1_t)ivar_184->ftbl->mptr(ivar_184, ivar_221, ivar_222);
        //copying to strassen_array_1 from strassen_array_1;
        ivar_1 = (strassen_array_1_t)ivar_121;
        if (ivar_1 != NULL) ivar_1->count++;
        release_strassen_array_1((strassen_array_1_t)ivar_121);
        strassen_array_1_t ivar_2;
        uint32_t ivar_245;
        uint8_t ivar_243;
        ivar_243 = (uint8_t)1;
        uint32_t ivar_241;
        //copying to uint32 from uint8;
        ivar_241 = (uint32_t)ivar_243;
        ivar_245 = (uint32_t)strassen__dim((uint32_t)ivar_241);
        strassen_array_1_t ivar_244;
        ivar_244 = (strassen_array_1_t)matrix__I((uint32_t)ivar_245);
        //copying to strassen_array_1 from strassen_array_1;
        ivar_2 = (strassen_array_1_t)ivar_244;
        if (ivar_2 != NULL) ivar_2->count++;
        release_strassen_array_1((strassen_array_1_t)ivar_244);
        result = (bool_t) equal_strassen_array_1(ivar_1, ivar_2);
        defined = true;};
        
        
        return result;
}

bool_t strassen__strassen_id_4(void){
        bool_t  static  result;

        static bool_t defined = false;
        if (!defined){
            
        strassen_array_1_t ivar_1;
        strassen_funtype_3_t ivar_184;
        uint8_t ivar_220;
        ivar_220 = (uint8_t)2;
        uint32_t ivar_218;
        //copying to uint32 from uint8;
        ivar_218 = (uint32_t)ivar_220;
        ivar_184 = (strassen_funtype_3_t)strassen__strassen((uint32_t)ivar_218);
        strassen_array_1_t ivar_221;
        uint32_t ivar_37;
        uint8_t ivar_35;
        ivar_35 = (uint8_t)2;
        uint32_t ivar_33;
        //copying to uint32 from uint8;
        ivar_33 = (uint32_t)ivar_35;
        ivar_37 = (uint32_t)strassen__dim((uint32_t)ivar_33);
        strassen_array_1_t ivar_36;
        ivar_36 = (strassen_array_1_t)matrix__I((uint32_t)ivar_37);
        //copying to strassen_array_1 from strassen_array_1;
        ivar_221 = (strassen_array_1_t)ivar_36;
        if (ivar_221 != NULL) ivar_221->count++;
        release_strassen_array_1((strassen_array_1_t)ivar_36);
        strassen_array_1_t ivar_222;
        uint32_t ivar_60;
        uint8_t ivar_58;
        ivar_58 = (uint8_t)2;
        uint32_t ivar_56;
        //copying to uint32 from uint8;
        ivar_56 = (uint32_t)ivar_58;
        ivar_60 = (uint32_t)strassen__dim((uint32_t)ivar_56);
        strassen_array_1_t ivar_59;
        ivar_59 = (strassen_array_1_t)matrix__I((uint32_t)ivar_60);
        //copying to strassen_array_1 from strassen_array_1;
        ivar_222 = (strassen_array_1_t)ivar_59;
        if (ivar_222 != NULL) ivar_222->count++;
        release_strassen_array_1((strassen_array_1_t)ivar_59);
        strassen_array_1_t ivar_121;
        ivar_121 = (strassen_array_1_t)ivar_184->ftbl->mptr(ivar_184, ivar_221, ivar_222);
        //copying to strassen_array_1 from strassen_array_1;
        ivar_1 = (strassen_array_1_t)ivar_121;
        if (ivar_1 != NULL) ivar_1->count++;
        release_strassen_array_1((strassen_array_1_t)ivar_121);
        strassen_array_1_t ivar_2;
        uint32_t ivar_245;
        uint8_t ivar_243;
        ivar_243 = (uint8_t)2;
        uint32_t ivar_241;
        //copying to uint32 from uint8;
        ivar_241 = (uint32_t)ivar_243;
        ivar_245 = (uint32_t)strassen__dim((uint32_t)ivar_241);
        strassen_array_1_t ivar_244;
        ivar_244 = (strassen_array_1_t)matrix__I((uint32_t)ivar_245);
        //copying to strassen_array_1 from strassen_array_1;
        ivar_2 = (strassen_array_1_t)ivar_244;
        if (ivar_2 != NULL) ivar_2->count++;
        release_strassen_array_1((strassen_array_1_t)ivar_244);
        result = (bool_t) equal_strassen_array_1(ivar_1, ivar_2);
        defined = true;};
        
        
        return result;
}
