//Code generated using pvs2ir2c
#include "sigma_c.h"



sigma__vector_t new_sigma__vector(uint32_t size){
        sigma__vector_t tmp = (sigma__vector_t) safe_malloc(sizeof(struct sigma__vector_s) + (size * sizeof(mpq_ptr_t)));
        tmp->count = 1;
        tmp->size = size;;
        tmp->max = size;
         return tmp;}

void release_sigma__vector(sigma__vector_t x){
        x->count--;
         if (x->count <= 0){safe_free(x);}
}

void release_sigma__vector_ptr(pointer_t x, type_actual_t T){
        release_sigma__vector((sigma__vector_t)x);
}

sigma__vector_t copy_sigma__vector(sigma__vector_t x){
        sigma__vector_t tmp = new_sigma__vector(x->max);
        tmp->count = 1;
        tmp->size = x->max;
        for (uint32_t i = 0; i < x->max; i++){ tmp->elems[i] = (mpq_ptr_t)safe_malloc(sizeof(mpq_t));
                mpq_init(tmp->elems[i]);
                if (i < x->size) mpq_set(tmp->elems[i], x->elems[i]);};
         return tmp;}

bool_t equal_sigma__vector(sigma__vector_t x, sigma__vector_t y){
        bool_t tmp = true;
        uint32_t i = 0;
        while  (i < x->size && tmp){tmp = (mpq_cmp(x->elems[i], y->elems[i]) == 0); i++;};
        return tmp;}

char * json_sigma__vector(sigma__vector_t x){
        char ** tmp = (char **)safe_malloc(sizeof(void *) * x->size);
        for (uint32_t i = 0; i < x->size; i++){tmp[i] = json_mpq(x->elems[i]);};
        char * result = json_list_with_sep(tmp, x->size, '[', ',', ']');
        for (uint32_t i = 0; i < x->size; i++) free(tmp[i]);
        free(tmp);
        return result;}

bool_t equal_sigma__vector_ptr(pointer_t x, pointer_t y, type_actual_t T){
        return equal_sigma__vector((sigma__vector_t)x, (sigma__vector_t)y);
}

char * json_sigma__vector_ptr(pointer_t x, type_actual_t T){
        return json_sigma__vector((sigma__vector_t)x);
}

actual_sigma__vector_t actual_sigma__vector(void){
        actual_sigma__vector_t new = (actual_sigma__vector_t)safe_malloc(sizeof(struct actual_sigma__vector_s));
        new->equal_ptr = (equal_ptr_t)(*equal_sigma__vector_ptr);
 
        new->release_ptr = (release_ptr_t)(*release_sigma__vector_ptr);
 
        new->json_ptr = (json_ptr_t)(*json_sigma__vector_ptr);
 

 
        return new;
 }

sigma__vector_t update_sigma__vector(sigma__vector_t x, uint32_t i, mpq_t v){
        sigma__vector_t y; 
         if (x->count == 1){y = x;}
           else {y = copy_sigma__vector(x );
                x->count--;};
        mpq_set(y->elems[i], v);
        return y;}

sigma__vector_t upgrade_sigma__vector(sigma__vector_t x, uint32_t i, mpq_t v){
        sigma__vector_t y;
        uint32_t xmax = x->max;
         if (x->count == 1 && i < xmax){y = x;}
           else if (i >= xmax){uint32_t newmax = ((xmax < UINT32_MAX/2) ? ((i < 2 * (xmax + 1)) ? 2 * (xmax + 1) : i + 1) : UINT32_MAX);
                y = safe_realloc(x, sizeof(struct sigma__vector_s) + (newmax * sizeof(mpq_t)));
                y->count = 1;
                y->size = i+1;
                y->max = newmax;}
           else {y = copy_sigma__vector(x );
                x->count--;};
        mpq_set(y->elems[i], v);
        return y;}



void release_sigma_funtype_1(sigma_funtype_1_t x){
        x->count--;
            if (x->count <= 0)

                x->ftbl->rptr(x);}

sigma_funtype_1_t copy_sigma_funtype_1(sigma_funtype_1_t x){return x->ftbl->cptr(x);}

uint32_t lookup_sigma_funtype_1(sigma_funtype_1_htbl_t htbl, mpz_ptr_t i, uint32_t ihash){
        uint32_t mask = htbl->size - 1;
        uint32_t hashindex = ihash & mask;
        sigma_funtype_1_hashentry_t data = htbl->data[hashindex];
        bool_t keyzero;


        int64_t tmp6437 = mpz_cmp_ui(data.key, 0);
        keyzero = (tmp6437 == 0);
        bool_t keymatch;

        int64_t tmp6438 = mpz_cmp(data.key, i);
        keymatch = (tmp6438 == 0);
        while ((!keyzero || data.keyhash != 0) &&
                 (data.keyhash != ihash || !keymatch)){
                hashindex++;
                hashindex = hashindex & mask;
                data = htbl->data[hashindex];


                int64_t tmp6437 = mpz_cmp_ui(data.key, 0);
                keyzero = (tmp6437 == 0);


                int64_t tmp6438 = mpz_cmp(data.key, i);
                keymatch = (tmp6438 == 0);
                }
        return hashindex;
        }

sigma_funtype_1_t dupdate_sigma_funtype_1(sigma_funtype_1_t a, mpz_ptr_t i, mpq_ptr_t v){
        sigma_funtype_1_htbl_t htbl = a->htbl;
        if (htbl == NULL){//construct new htbl
                htbl = (sigma_funtype_1_htbl_t)safe_malloc(sizeof(struct sigma_funtype_1_htbl_s));
                htbl->size = HTBL_DEFAULT_SIZE; htbl->num_entries = 0;
                htbl->data = (sigma_funtype_1_hashentry_t *)safe_malloc(HTBL_DEFAULT_SIZE * sizeof(struct sigma_funtype_1_hashentry_s));
                for (uint32_t j = 0; j < HTBL_DEFAULT_SIZE; j++){mpz_init(htbl->data[j].key);mpz_set_ui(htbl->data[j].key, 0); htbl->data[j].keyhash = 0;
                }
                a->htbl = htbl;
        }
        uint32_t size = htbl->size;
        uint32_t num_entries = htbl->num_entries;
        sigma_funtype_1_hashentry_t * data = htbl->data;
        if (num_entries/3 >  size/5){//resize data
                uint32_t new_size = 2*size; uint32_t new_mask = new_size - 1;
                if (size >= HTBL_MAX_SIZE) out_of_memory();
                sigma_funtype_1_hashentry_t * new_data = (sigma_funtype_1_hashentry_t *)safe_malloc(new_size * sizeof(struct sigma_funtype_1_hashentry_s));
                for (uint32_t j = 0; j < new_size; j++){
                        mpz_init(new_data[j].key); mpz_set_ui(new_data[j].key, 0); 
                        new_data[j].keyhash = 0;}
                for (uint32_t j = 0; j < size; j++){//transfer entries
                        uint32_t keyhash = data[j].keyhash;
                        bool_t keyzero;
                        int64_t tmp6439 = mpz_cmp_ui(data[j].key, 0);
                        keyzero = (tmp6439 == 0);

                        if (!keyzero || keyhash != 0){
                                uint32_t new_loc = keyhash ^ new_mask;
                                bool_t newkeyzero;
                                int64_t tmp6440 = mpz_cmp_ui(new_data[new_loc].key, 0);
                                newkeyzero = (tmp6440 == 0);

                                while (!newkeyzero || new_data[new_loc].keyhash != 0){
                                        new_loc++;
                                        new_loc = new_loc ^ new_mask;

                                        int64_t tmp6441 = mpz_cmp_ui(new_data[new_loc].key, 0);
                                        newkeyzero = (tmp6441 == 0);

                                }
                                mpz_set(new_data[new_loc].key, data[j].key);
                                new_data[new_loc].keyhash = keyhash;
                                mpq_set(new_data[new_loc].value, data[j].value);
                                }}
                htbl->size = new_size;
                htbl->num_entries = num_entries;
                htbl->data = new_data;
                for (uint32_t j=0; j < size; j++){mpz_clear(data[j].key); mpq_clear(data[j].value);};
                safe_free(data);}
        uint32_t ihash = mpz_hash(i);
        uint32_t hashindex = lookup_sigma_funtype_1(htbl, i, ihash);
        sigma_funtype_1_hashentry_t hentry = htbl->data[hashindex];
        uint32_t hkeyhash = hentry.keyhash;
        bool_t hentrykeyzero;
        int64_t tmp6442 = mpz_cmp_ui(hentry.key, 0);
        hentrykeyzero = (tmp6442 == 0);

        if (hentrykeyzero && (hkeyhash == 0))
                {mpz_set(htbl->data[hashindex].key, i); htbl->data[hashindex].keyhash = ihash; mpq_set(htbl->data[hashindex].value, v); htbl->num_entries++;}
            else {mpq_set(htbl->data[hashindex].value, v);};
        return a;

}

sigma_funtype_1_t update_sigma_funtype_1(sigma_funtype_1_t a, mpz_ptr_t i, mpq_ptr_t v){
        if (a->count == 1){
                return dupdate_sigma_funtype_1(a, i, v);
            } else {
                sigma_funtype_1_t x = copy_sigma_funtype_1(a);
                a->count--;
                return dupdate_sigma_funtype_1(x, i, v);
            }}

bool_t equal_sigma_funtype_1(sigma_funtype_1_t x, sigma_funtype_1_t y){
        return false;}

char* json_sigma_funtype_1(sigma_funtype_1_t x){char * result = safe_malloc(25); sprintf(result, "%s", "\"sigma_funtype_1\""); return result;}


mpq_ptr_t f_sigma_closure_2(struct sigma_closure_2_s * closure, mpz_ptr_t bvar){
if (closure->htbl != NULL){
        sigma_funtype_1_htbl_t htbl = closure->htbl;
        uint32_t hash = mpz_hash(bvar);
        uint32_t hashindex = lookup_sigma_funtype_1(htbl, bvar, hash);
        sigma_funtype_1_hashentry_t entry = htbl->data[hashindex];
        bool_t keyzero;
         int64_t tmp6443 = mpz_cmp_ui(entry.key, 0);
         keyzero = (tmp6443 == 0);
        if (!keyzero || entry.keyhash != 0){
                mpq_ptr_t result;
                release_sigma_funtype_1((sigma_funtype_1_t)closure);
                result = (mpq_ptr_t)entry.value;
                return result;}
        else {
            sigma__vector_t fvar_1 = closure->fvar_1;

            fvar_1->count++;
            release_sigma_funtype_1((sigma_funtype_1_t)closure);
            mpq_ptr_t result;
            result = (mpq_ptr_t)h_sigma_closure_2(bvar, fvar_1);
            return result;};
        }

      else {
        sigma__vector_t fvar_1 = closure->fvar_1;
        fvar_1->count++;
        release_sigma_funtype_1((sigma_funtype_1_t)closure);
        mpq_ptr_t result;
        result = (mpq_ptr_t)h_sigma_closure_2(bvar, fvar_1);
        return result;}
}

mpq_ptr_t m_sigma_closure_2(struct sigma_closure_2_s * closure, mpz_ptr_t bvar){
        sigma__vector_t fvar_1 = closure->fvar_1;
        fvar_1->count++;
        release_sigma_funtype_1((sigma_funtype_1_t)closure);
        return h_sigma_closure_2(bvar, fvar_1);}

mpq_ptr_t h_sigma_closure_2(mpz_ptr_t ivar_21, sigma__vector_t ivar_2){
        mpq_ptr_t result;

        uint32_t ivar_28;
        //copying to uint32 from mpz;
        ivar_28 = (uint32_t)mpz_get_ui(ivar_21);
        mpz_clear(ivar_21);
        result = safe_malloc(sizeof(mpq_t));
        mpq_init(result);
        mpq_set(result, ivar_2->elems[ivar_28]);
        return result;
}

sigma_closure_2_t new_sigma_closure_2(void){
        static struct sigma_funtype_1_ftbl_s ftbl = {.fptr = (mpq_ptr_t (*)(sigma_funtype_1_t, mpz_ptr_t))&f_sigma_closure_2, .mptr = (mpq_ptr_t (*)(sigma_funtype_1_t, mpz_ptr_t))&m_sigma_closure_2, .rptr =  (void (*)(sigma_funtype_1_t))&release_sigma_closure_2, .cptr = (sigma_funtype_1_t (*)(sigma_funtype_1_t))&copy_sigma_closure_2};
        sigma_closure_2_t tmp = (sigma_closure_2_t) safe_malloc(sizeof(struct sigma_closure_2_s));
        tmp->count = 1;
        tmp->ftbl = &ftbl;
        tmp->htbl = NULL;
        return tmp;}

void release_sigma_closure_2(sigma_funtype_1_t closure){
        sigma_closure_2_t x = (sigma_closure_2_t)closure;
        x->count--;
        if (x->count <= 0){
         release_sigma__vector((sigma__vector_t)x->fvar_1);
          if (x->htbl != NULL){
               for (uint32_t j = 0; j < x->htbl->size; j++){mpz_clear(x->htbl->data[j].key);}

               safe_free(x->htbl->data);

               safe_free(x->htbl);

               }

        //printf("\nFreeing\n");
        safe_free(x);}}

sigma_closure_2_t copy_sigma_closure_2(sigma_closure_2_t x){
        sigma_closure_2_t y = new_sigma_closure_2();
        y->ftbl = x->ftbl;

        y->fvar_1 = x->fvar_1; x->fvar_1->count++;
        if (x->htbl != NULL){
            sigma_funtype_1_htbl_t new_htbl = (sigma_funtype_1_htbl_t) safe_malloc(sizeof(struct sigma_funtype_1_htbl_s));
            new_htbl->size = x->htbl->size;
            new_htbl->num_entries = x->htbl->num_entries;
            sigma_funtype_1_hashentry_t * new_data = (sigma_funtype_1_hashentry_t *) safe_malloc(new_htbl->size * sizeof(struct sigma_funtype_1_hashentry_s));
            
             for (uint32_t j = 0; j < new_htbl->size; j++){
                  new_data[j].keyhash = (uint32_t)x->htbl->data[j].keyhash;
                  mpz_init(new_data[j].key); mpz_set(new_data[j].key, x->htbl->data[j].key);;
                  mpq_init(new_data[j].value); mpq_set(new_data[j].value, x->htbl->data[j].value);;
             };
            new_htbl->data = new_data;
            y->htbl = new_htbl;
        } else
            {y->htbl = NULL;};
        return y;
}
mpq_ptr_t sigma__sigma(uint32_t ivar_1, sigma__vector_t ivar_2){
         mpq_ptr_t  result;

        bool_t ivar_3;
        uint8_t ivar_5;
        ivar_5 = (uint8_t)0;
        ivar_3 = (ivar_1 == ivar_5);
        if (ivar_3){
             release_sigma__vector((sigma__vector_t)ivar_2);
             result = safe_malloc(sizeof(mpq_t));
             mpq_init(result);
             mpq_mk_set_ui(result, 0);
        } else {
             mpq_ptr_t ivar_7;
             uint32_t ivar_15;
             uint8_t ivar_11;
             ivar_11 = (uint8_t)1;
             ivar_15 = (uint32_t)(ivar_1 - ivar_11);
             ivar_7 = safe_malloc(sizeof(mpq_t));
             mpq_init(ivar_7);
             mpq_set(ivar_7, ivar_2->elems[ivar_15]);
             mpq_ptr_t ivar_8;
             int32_t ivar_43;
             uint8_t ivar_19;
             ivar_19 = (uint8_t)1;
             ivar_43 = (int32_t)((uint64_t)ivar_1 - (uint64_t)ivar_19);
             uint32_t ivar_38;
             //copying to uint32 from int32;
             ivar_38 = (uint32_t)ivar_43;
             sigma_funtype_1_t ivar_42;
             sigma_closure_2_t cl6444;
             cl6444 = new_sigma_closure_2();
             cl6444->fvar_1 = (sigma__vector_t)ivar_2;
             if (cl6444->fvar_1 != NULL) cl6444->fvar_1->count++;
             release_sigma__vector((sigma__vector_t)ivar_2);
             ivar_42 = (sigma_funtype_1_t)cl6444;
             sigma__vector_t ivar_39;
             //copying to sigma__vector from sigma_funtype_1;
             uint32_t tmp6445;
             //copying to uint32 from uint32;
             tmp6445 = (uint32_t)ivar_38;
             tmp6445 += 0;
             ivar_39 = new_sigma__vector(tmp6445);
             for (uint32_t index_45 = 0; index_45 < tmp6445; index_45++){
           mpz_t index_46;
           mpz_init(index_46);
           mpz_set_ui(index_46, index_45);
           ivar_39->elems[index_45] = (mpq_ptr_t)safe_malloc(sizeof(mpq_t));
           mpq_init(ivar_39->elems[index_45]);
           mpq_mk_set(ivar_39->elems[index_45], ivar_42->ftbl->fptr(ivar_42, index_46));
             };
             release_sigma_funtype_1((sigma_funtype_1_t)ivar_42);
             ivar_8 = (mpq_ptr_t)sigma__sigma((uint32_t)ivar_38, (sigma__vector_t)ivar_39);
             mpq_mk_set(result, ivar_7);
             mpq_add(result, result, ivar_8);
             mpq_clear(ivar_7);
             mpq_clear(ivar_8);};
        
        
        return result;
}
