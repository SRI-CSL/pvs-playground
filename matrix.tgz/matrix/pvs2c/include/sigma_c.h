//Code generated using pvs2ir
#ifndef _sigma_h 
#define _sigma_h

#include <stdio.h>

#include <stdlib.h>

#include <inttypes.h>

#include <stdbool.h>

#include <stdarg.h>

#include <string.h>

#include <fcntl.h>

#include <math.h>

#include <sys/mman.h>

#include <sys/stat.h>

#include <sys/types.h>

#include <gmp.h>

#include "pvslib.h"

#include "exp2_c.h"


#include "integertypes_c.h"


//cc -O3 -Wall -o sigma -L /Users/shankar/pvs8/PVS/lib/pvs2c/lib -I /Users/shankar/pvs8/PVS/lib/pvs2c/include sigma_c.c <your main>.c  -lgmp -lpvs-prelude 
//vector

struct sigma__vector_s { uint32_t count;
        uint32_t size;
         uint32_t max;
         mpq_ptr_t elems[]; };
typedef struct sigma__vector_s * sigma__vector_t;

extern sigma__vector_t new_sigma__vector(uint32_t size);

extern void release_sigma__vector(sigma__vector_t x);

extern sigma__vector_t copy_sigma__vector(sigma__vector_t x);

extern bool_t equal_sigma__vector(sigma__vector_t x, sigma__vector_t y);
extern char * json_sigma__vector(sigma__vector_t x);

typedef struct actual_sigma__vector_s {equal_ptr_t equal_ptr; release_ptr_t release_ptr; json_ptr_t json_ptr;} * actual_sigma__vector_t;
extern void release_sigma__vector_ptr(pointer_t x, type_actual_t sigma__vector);

extern bool_t equal_sigma__vector_ptr(pointer_t x, pointer_t y, type_actual_t T);

extern char * json_sigma__vector_ptr(pointer_t x, type_actual_t T);

actual_sigma__vector_t actual_sigma__vector(void);

 

extern sigma__vector_t update_sigma__vector(sigma__vector_t x, uint32_t i, mpq_t v);

extern sigma__vector_t upgrade_sigma__vector(sigma__vector_t x, uint32_t i, mpq_t v);


//sigma

struct sigma_funtype_1_s;
        typedef struct sigma_funtype_1_s * sigma_funtype_1_t;

struct sigma_funtype_1_ftbl_s {mpq_ptr_t (* fptr)(struct sigma_funtype_1_s *, mpz_ptr_t);
        mpq_ptr_t (* mptr)(struct sigma_funtype_1_s *, mpz_ptr_t);
        void (* rptr)(struct sigma_funtype_1_s *);
        struct sigma_funtype_1_s * (* cptr)(struct sigma_funtype_1_s *);};
typedef struct sigma_funtype_1_ftbl_s * sigma_funtype_1_ftbl_t;

struct sigma_funtype_1_hashentry_s {uint32_t keyhash; mpz_ptr_t key; mpq_t value;}; 
typedef struct sigma_funtype_1_hashentry_s sigma_funtype_1_hashentry_t;

struct sigma_funtype_1_htbl_s {uint32_t size; uint32_t num_entries; sigma_funtype_1_hashentry_t * data;}; 
typedef struct sigma_funtype_1_htbl_s * sigma_funtype_1_htbl_t;

struct sigma_funtype_1_s {uint32_t count;
        sigma_funtype_1_ftbl_t ftbl;
        sigma_funtype_1_htbl_t htbl;};

extern void release_sigma_funtype_1(sigma_funtype_1_t x);

extern sigma_funtype_1_t copy_sigma_funtype_1(sigma_funtype_1_t x);

extern uint32_t lookup_sigma_funtype_1(sigma_funtype_1_htbl_t htbl, mpz_ptr_t i, uint32_t ihash);

extern sigma_funtype_1_t dupdate_sigma_funtype_1(sigma_funtype_1_t a, mpz_ptr_t i, mpq_ptr_t v);

extern sigma_funtype_1_t update_sigma_funtype_1(sigma_funtype_1_t a, mpz_ptr_t i, mpq_ptr_t v);

extern bool_t equal_sigma_funtype_1(sigma_funtype_1_t x, sigma_funtype_1_t y);

extern char* json_sigma_funtype_1(sigma_funtype_1_t x);




struct sigma_closure_2_s;
        typedef struct sigma_closure_2_s * sigma_closure_2_t;

struct sigma_closure_2_s {uint32_t count;
         sigma_funtype_1_ftbl_t ftbl;
         sigma_funtype_1_htbl_t htbl;
        sigma__vector_t fvar_1;};

mpq_ptr_t f_sigma_closure_2(struct sigma_closure_2_s * closure, mpz_ptr_t bvar);

mpq_ptr_t m_sigma_closure_2(struct sigma_closure_2_s * closure, mpz_ptr_t bvar);

extern mpq_ptr_t h_sigma_closure_2(mpz_ptr_t ivar_21, sigma__vector_t ivar_2);

sigma_closure_2_t new_sigma_closure_2(void);

void release_sigma_closure_2(sigma_funtype_1_t closure);

sigma_closure_2_t copy_sigma_closure_2(sigma_closure_2_t x);



extern mpq_ptr_t sigma__sigma(uint32_t ivar_1, sigma__vector_t ivar_2);
#endif
