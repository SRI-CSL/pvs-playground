//Code generated using pvs2ir
#ifndef _matrix_h 
#define _matrix_h

#include <stdio.h>

#include <stdlib.h>

#include <inttypes.h>

#include <stdbool.h>

#include <stdarg.h>

#include <string.h>

#include <fcntl.h>

#include <math.h>

#include <sys/mman.h>

#include <sys/stat.h>

#include <sys/types.h>

#include <gmp.h>

#include "pvslib.h"

#include "exp2_c.h"


#include "integertypes_c.h"


#include "sigma_c.h"


//cc -O3 -Wall -o matrix -L /Users/shankar/pvs8/PVS/lib/pvs2c/lib -I /Users/shankar/pvs8/PVS/lib/pvs2c/include sigma_c.c matrix_c.c <your main>.c  -lgmp -lpvs-prelude 
//matrix

struct matrix_array_0_s { uint32_t count;
        uint32_t size;
         uint32_t max;
         mpq_ptr_t elems[]; };
typedef struct matrix_array_0_s * matrix_array_0_t;

extern matrix_array_0_t new_matrix_array_0(uint32_t size);

extern void release_matrix_array_0(matrix_array_0_t x);

extern matrix_array_0_t copy_matrix_array_0(matrix_array_0_t x);

extern bool_t equal_matrix_array_0(matrix_array_0_t x, matrix_array_0_t y);
extern char * json_matrix_array_0(matrix_array_0_t x);

typedef struct actual_matrix_array_0_s {equal_ptr_t equal_ptr; release_ptr_t release_ptr; json_ptr_t json_ptr;} * actual_matrix_array_0_t;
extern void release_matrix_array_0_ptr(pointer_t x, type_actual_t matrix_array_0);

extern bool_t equal_matrix_array_0_ptr(pointer_t x, pointer_t y, type_actual_t T);

extern char * json_matrix_array_0_ptr(pointer_t x, type_actual_t T);

actual_matrix_array_0_t actual_matrix_array_0(void);

 

extern matrix_array_0_t update_matrix_array_0(matrix_array_0_t x, uint32_t i, mpq_t v);

extern matrix_array_0_t upgrade_matrix_array_0(matrix_array_0_t x, uint32_t i, mpq_t v);


//matrix

struct matrix__matrix_s { uint32_t count;
        uint32_t size;
         uint32_t max;
         matrix_array_0_t elems[]; };
typedef struct matrix__matrix_s * matrix__matrix_t;

extern matrix__matrix_t new_matrix__matrix(uint32_t size);

extern void release_matrix__matrix(matrix__matrix_t x);

extern matrix__matrix_t copy_matrix__matrix(matrix__matrix_t x);

extern bool_t equal_matrix__matrix(matrix__matrix_t x, matrix__matrix_t y);
extern char * json_matrix__matrix(matrix__matrix_t x);

typedef struct actual_matrix__matrix_s {equal_ptr_t equal_ptr; release_ptr_t release_ptr; json_ptr_t json_ptr;} * actual_matrix__matrix_t;
extern void release_matrix__matrix_ptr(pointer_t x, type_actual_t matrix__matrix);

extern bool_t equal_matrix__matrix_ptr(pointer_t x, pointer_t y, type_actual_t T);

extern char * json_matrix__matrix_ptr(pointer_t x, type_actual_t T);

actual_matrix__matrix_t actual_matrix__matrix(void);

 

extern matrix__matrix_t update_matrix__matrix(matrix__matrix_t x, uint32_t i, matrix_array_0_t v);

extern matrix__matrix_t upgrade_matrix__matrix(matrix__matrix_t x, uint32_t i, matrix_array_0_t v);


//madd

struct matrix_record_2_s {
        uint32_t count; 
        matrix__matrix_t project_1;
        matrix__matrix_t project_2;};
typedef struct matrix_record_2_s * matrix_record_2_t;

extern matrix_record_2_t new_matrix_record_2(void);

extern void release_matrix_record_2(matrix_record_2_t x);

extern matrix_record_2_t copy_matrix_record_2(matrix_record_2_t x);

extern bool_t equal_matrix_record_2(matrix_record_2_t x, matrix_record_2_t y);
extern char * json_matrix_record_2(matrix_record_2_t x);

typedef struct actual_matrix_record_2_s {equal_ptr_t equal_ptr; release_ptr_t release_ptr; json_ptr_t json_ptr;} * actual_matrix_record_2_t;
extern void release_matrix_record_2_ptr(pointer_t x, type_actual_t matrix_record_2);

extern bool_t equal_matrix_record_2_ptr(pointer_t x, pointer_t y, actual_matrix_record_2_t T);

extern char * json_matrix_record_2_ptr(pointer_t x,  actual_matrix_record_2_t T);

actual_matrix_record_2_t actual_matrix_record_2(void);

 

extern matrix_record_2_t update_matrix_record_2_project_1(matrix_record_2_t x, matrix__matrix_t v);

extern matrix_record_2_t update_matrix_record_2_project_2(matrix_record_2_t x, matrix__matrix_t v);


//madd

struct matrix_funtype_3_s;
        typedef struct matrix_funtype_3_s * matrix_funtype_3_t;

struct matrix_funtype_3_ftbl_s {matrix__matrix_t (* fptr)(struct matrix_funtype_3_s *, matrix_record_2_t);
        matrix__matrix_t (* mptr)(struct matrix_funtype_3_s *, matrix__matrix_t, matrix__matrix_t);
        void (* rptr)(struct matrix_funtype_3_s *);
        struct matrix_funtype_3_s * (* cptr)(struct matrix_funtype_3_s *);};
typedef struct matrix_funtype_3_ftbl_s * matrix_funtype_3_ftbl_t;

struct matrix_funtype_3_hashentry_s {uint32_t keyhash; matrix_record_2_t key; matrix__matrix_t value;}; 
typedef struct matrix_funtype_3_hashentry_s matrix_funtype_3_hashentry_t;

struct matrix_funtype_3_htbl_s {uint32_t size; uint32_t num_entries; matrix_funtype_3_hashentry_t * data;}; 
typedef struct matrix_funtype_3_htbl_s * matrix_funtype_3_htbl_t;

struct matrix_funtype_3_s {uint32_t count;
        matrix_funtype_3_ftbl_t ftbl;
        matrix_funtype_3_htbl_t htbl;};

extern void release_matrix_funtype_3(matrix_funtype_3_t x);

extern matrix_funtype_3_t copy_matrix_funtype_3(matrix_funtype_3_t x);

extern bool_t equal_matrix_funtype_3(matrix_funtype_3_t x, matrix_funtype_3_t y);

extern char* json_matrix_funtype_3(matrix_funtype_3_t x);




struct matrix_closure_4_s;
        typedef struct matrix_closure_4_s * matrix_closure_4_t;

struct matrix_closure_4_s {uint32_t count;
         matrix_funtype_3_ftbl_t ftbl;
         matrix_funtype_3_htbl_t htbl;};

matrix__matrix_t f_matrix_closure_4(struct matrix_closure_4_s * closure, matrix_record_2_t bvar);

matrix__matrix_t m_matrix_closure_4(struct matrix_closure_4_s * closure, matrix__matrix_t bvar_1, matrix__matrix_t bvar_2);

extern matrix__matrix_t h_matrix_closure_4(matrix__matrix_t ivar_6, matrix__matrix_t ivar_7);

matrix_closure_4_t new_matrix_closure_4(void);

void release_matrix_closure_4(matrix_funtype_3_t closure);

matrix_closure_4_t copy_matrix_closure_4(matrix_closure_4_t x);


//mmult

struct matrix_funtype_5_s;
        typedef struct matrix_funtype_5_s * matrix_funtype_5_t;

struct matrix_funtype_5_ftbl_s {mpq_ptr_t (* fptr)(struct matrix_funtype_5_s *, mpz_ptr_t);
        mpq_ptr_t (* mptr)(struct matrix_funtype_5_s *, mpz_ptr_t);
        void (* rptr)(struct matrix_funtype_5_s *);
        struct matrix_funtype_5_s * (* cptr)(struct matrix_funtype_5_s *);};
typedef struct matrix_funtype_5_ftbl_s * matrix_funtype_5_ftbl_t;

struct matrix_funtype_5_hashentry_s {uint32_t keyhash; mpz_ptr_t key; mpq_t value;}; 
typedef struct matrix_funtype_5_hashentry_s matrix_funtype_5_hashentry_t;

struct matrix_funtype_5_htbl_s {uint32_t size; uint32_t num_entries; matrix_funtype_5_hashentry_t * data;}; 
typedef struct matrix_funtype_5_htbl_s * matrix_funtype_5_htbl_t;

struct matrix_funtype_5_s {uint32_t count;
        matrix_funtype_5_ftbl_t ftbl;
        matrix_funtype_5_htbl_t htbl;};

extern void release_matrix_funtype_5(matrix_funtype_5_t x);

extern matrix_funtype_5_t copy_matrix_funtype_5(matrix_funtype_5_t x);

extern uint32_t lookup_matrix_funtype_5(matrix_funtype_5_htbl_t htbl, mpz_ptr_t i, uint32_t ihash);

extern matrix_funtype_5_t dupdate_matrix_funtype_5(matrix_funtype_5_t a, mpz_ptr_t i, mpq_ptr_t v);

extern matrix_funtype_5_t update_matrix_funtype_5(matrix_funtype_5_t a, mpz_ptr_t i, mpq_ptr_t v);

extern bool_t equal_matrix_funtype_5(matrix_funtype_5_t x, matrix_funtype_5_t y);

extern char* json_matrix_funtype_5(matrix_funtype_5_t x);




struct matrix_closure_6_s;
        typedef struct matrix_closure_6_s * matrix_closure_6_t;

struct matrix_closure_6_s {uint32_t count;
         matrix_funtype_5_ftbl_t ftbl;
         matrix_funtype_5_htbl_t htbl;
        matrix__matrix_t fvar_1;
        mpz_t fvar_2;
        matrix__matrix_t fvar_3;
        mpz_t fvar_4;};

mpq_ptr_t f_matrix_closure_6(struct matrix_closure_6_s * closure, mpz_ptr_t bvar);

mpq_ptr_t m_matrix_closure_6(struct matrix_closure_6_s * closure, mpz_ptr_t bvar);

extern mpq_ptr_t h_matrix_closure_6(mpz_ptr_t ivar_12, matrix__matrix_t ivar_5, mpz_ptr_t ivar_9, matrix__matrix_t ivar_4, mpz_ptr_t ivar_7);

matrix_closure_6_t new_matrix_closure_6(void);

void release_matrix_closure_6(matrix_funtype_5_t closure);

matrix_closure_6_t copy_matrix_closure_6(matrix_closure_6_t x);


//right_inverse

struct matrix_funtype_7_s;
        typedef struct matrix_funtype_7_s * matrix_funtype_7_t;

struct matrix_funtype_7_ftbl_s {bool_t (* fptr)(struct matrix_funtype_7_s *, matrix__matrix_t);
        bool_t (* mptr)(struct matrix_funtype_7_s *, matrix__matrix_t);
        void (* rptr)(struct matrix_funtype_7_s *);
        struct matrix_funtype_7_s * (* cptr)(struct matrix_funtype_7_s *);};
typedef struct matrix_funtype_7_ftbl_s * matrix_funtype_7_ftbl_t;

struct matrix_funtype_7_hashentry_s {uint32_t keyhash; matrix__matrix_t key; bool_t value;}; 
typedef struct matrix_funtype_7_hashentry_s matrix_funtype_7_hashentry_t;

struct matrix_funtype_7_htbl_s {uint32_t size; uint32_t num_entries; matrix_funtype_7_hashentry_t * data;}; 
typedef struct matrix_funtype_7_htbl_s * matrix_funtype_7_htbl_t;

struct matrix_funtype_7_s {uint32_t count;
        matrix_funtype_7_ftbl_t ftbl;
        matrix_funtype_7_htbl_t htbl;};

extern void release_matrix_funtype_7(matrix_funtype_7_t x);

extern matrix_funtype_7_t copy_matrix_funtype_7(matrix_funtype_7_t x);

extern bool_t equal_matrix_funtype_7(matrix_funtype_7_t x, matrix_funtype_7_t y);

extern char* json_matrix_funtype_7(matrix_funtype_7_t x);




struct matrix_closure_8_s;
        typedef struct matrix_closure_8_s * matrix_closure_8_t;

struct matrix_closure_8_s {uint32_t count;
         matrix_funtype_7_ftbl_t ftbl;
         matrix_funtype_7_htbl_t htbl;
        uint32_t fvar_1;
        matrix__matrix_t fvar_2;};

bool_t f_matrix_closure_8(struct matrix_closure_8_s * closure, matrix__matrix_t bvar);

bool_t m_matrix_closure_8(struct matrix_closure_8_s * closure, matrix__matrix_t bvar);

extern bool_t h_matrix_closure_8(matrix__matrix_t ivar_5, uint32_t ivar_1, matrix__matrix_t ivar_2);

matrix_closure_8_t new_matrix_closure_8(void);

void release_matrix_closure_8(matrix_funtype_7_t closure);

matrix_closure_8_t copy_matrix_closure_8(matrix_closure_8_t x);




struct matrix_closure_9_s;
        typedef struct matrix_closure_9_s * matrix_closure_9_t;

struct matrix_closure_9_s {uint32_t count;
         matrix_funtype_7_ftbl_t ftbl;
         matrix_funtype_7_htbl_t htbl;
        uint32_t fvar_1;
        matrix__matrix_t fvar_2;};

bool_t f_matrix_closure_9(struct matrix_closure_9_s * closure, matrix__matrix_t bvar);

bool_t m_matrix_closure_9(struct matrix_closure_9_s * closure, matrix__matrix_t bvar);

extern bool_t h_matrix_closure_9(matrix__matrix_t ivar_5, uint32_t ivar_1, matrix__matrix_t ivar_2);

matrix_closure_9_t new_matrix_closure_9(void);

void release_matrix_closure_9(matrix_funtype_7_t closure);

matrix_closure_9_t copy_matrix_closure_9(matrix_closure_9_t x);




struct matrix_closure_10_s;
        typedef struct matrix_closure_10_s * matrix_closure_10_t;

struct matrix_closure_10_s {uint32_t count;
         matrix_funtype_7_ftbl_t ftbl;
         matrix_funtype_7_htbl_t htbl;
        matrix__matrix_t fvar_1;
        uint32_t fvar_2;};

bool_t f_matrix_closure_10(struct matrix_closure_10_s * closure, matrix__matrix_t bvar);

bool_t m_matrix_closure_10(struct matrix_closure_10_s * closure, matrix__matrix_t bvar);

extern bool_t h_matrix_closure_10(matrix__matrix_t ivar_5, matrix__matrix_t ivar_2, uint32_t ivar_1);

matrix_closure_10_t new_matrix_closure_10(void);

void release_matrix_closure_10(matrix_funtype_7_t closure);

matrix_closure_10_t copy_matrix_closure_10(matrix_closure_10_t x);




struct matrix_closure_11_s;
        typedef struct matrix_closure_11_s * matrix_closure_11_t;

struct matrix_closure_11_s {uint32_t count;
         matrix_funtype_3_ftbl_t ftbl;
         matrix_funtype_3_htbl_t htbl;
        uint32_t fvar_1;};

matrix__matrix_t f_matrix_closure_11(struct matrix_closure_11_s * closure, matrix_record_2_t bvar);

matrix__matrix_t m_matrix_closure_11(struct matrix_closure_11_s * closure, matrix__matrix_t bvar_1, matrix__matrix_t bvar_2);

extern matrix__matrix_t h_matrix_closure_11(matrix__matrix_t ivar_16, matrix__matrix_t ivar_17, uint32_t ivar_2);

matrix_closure_11_t new_matrix_closure_11(void);

void release_matrix_closure_11(matrix_funtype_3_t closure);

matrix_closure_11_t copy_matrix_closure_11(matrix_closure_11_t x);




struct matrix_closure_12_s;
        typedef struct matrix_closure_12_s * matrix_closure_12_t;

struct matrix_closure_12_s {uint32_t count;
         matrix_funtype_3_ftbl_t ftbl;
         matrix_funtype_3_htbl_t htbl;
        uint32_t fvar_1;};

matrix__matrix_t f_matrix_closure_12(struct matrix_closure_12_s * closure, matrix_record_2_t bvar);

matrix__matrix_t m_matrix_closure_12(struct matrix_closure_12_s * closure, matrix__matrix_t bvar_1, matrix__matrix_t bvar_2);

extern matrix__matrix_t h_matrix_closure_12(matrix__matrix_t ivar_13, matrix__matrix_t ivar_14, uint32_t ivar_1);

matrix_closure_12_t new_matrix_closure_12(void);

void release_matrix_closure_12(matrix_funtype_3_t closure);

matrix_closure_12_t copy_matrix_closure_12(matrix_closure_12_t x);


//topleft

struct matrix_record_13_s {
        uint32_t count; 
        uint32_t project_1;
        uint32_t project_2;};
typedef struct matrix_record_13_s * matrix_record_13_t;

extern matrix_record_13_t new_matrix_record_13(void);

extern void release_matrix_record_13(matrix_record_13_t x);

extern matrix_record_13_t copy_matrix_record_13(matrix_record_13_t x);

extern bool_t equal_matrix_record_13(matrix_record_13_t x, matrix_record_13_t y);
extern char * json_matrix_record_13(matrix_record_13_t x);

typedef struct actual_matrix_record_13_s {equal_ptr_t equal_ptr; release_ptr_t release_ptr; json_ptr_t json_ptr;} * actual_matrix_record_13_t;
extern void release_matrix_record_13_ptr(pointer_t x, type_actual_t matrix_record_13);

extern bool_t equal_matrix_record_13_ptr(pointer_t x, pointer_t y, actual_matrix_record_13_t T);

extern char * json_matrix_record_13_ptr(pointer_t x,  actual_matrix_record_13_t T);

actual_matrix_record_13_t actual_matrix_record_13(void);

 

extern matrix_record_13_t update_matrix_record_13_project_1(matrix_record_13_t x, uint32_t v);

extern matrix_record_13_t update_matrix_record_13_project_2(matrix_record_13_t x, uint32_t v);


//topleft

struct matrix_funtype_14_s;
        typedef struct matrix_funtype_14_s * matrix_funtype_14_t;

struct matrix_funtype_14_ftbl_s {matrix__matrix_t (* fptr)(struct matrix_funtype_14_s *, matrix__matrix_t);
        matrix__matrix_t (* mptr)(struct matrix_funtype_14_s *, matrix__matrix_t);
        void (* rptr)(struct matrix_funtype_14_s *);
        struct matrix_funtype_14_s * (* cptr)(struct matrix_funtype_14_s *);};
typedef struct matrix_funtype_14_ftbl_s * matrix_funtype_14_ftbl_t;

struct matrix_funtype_14_hashentry_s {uint32_t keyhash; matrix__matrix_t key; matrix__matrix_t value;}; 
typedef struct matrix_funtype_14_hashentry_s matrix_funtype_14_hashentry_t;

struct matrix_funtype_14_htbl_s {uint32_t size; uint32_t num_entries; matrix_funtype_14_hashentry_t * data;}; 
typedef struct matrix_funtype_14_htbl_s * matrix_funtype_14_htbl_t;

struct matrix_funtype_14_s {uint32_t count;
        matrix_funtype_14_ftbl_t ftbl;
        matrix_funtype_14_htbl_t htbl;};

extern void release_matrix_funtype_14(matrix_funtype_14_t x);

extern matrix_funtype_14_t copy_matrix_funtype_14(matrix_funtype_14_t x);

extern bool_t equal_matrix_funtype_14(matrix_funtype_14_t x, matrix_funtype_14_t y);

extern char* json_matrix_funtype_14(matrix_funtype_14_t x);


//topleft

struct matrix_funtype_15_s;
        typedef struct matrix_funtype_15_s * matrix_funtype_15_t;

struct matrix_funtype_15_ftbl_s {matrix_funtype_14_t (* fptr)(struct matrix_funtype_15_s *, matrix_record_13_t);
        matrix_funtype_14_t (* mptr)(struct matrix_funtype_15_s *, uint32_t, uint32_t);
        void (* rptr)(struct matrix_funtype_15_s *);
        struct matrix_funtype_15_s * (* cptr)(struct matrix_funtype_15_s *);};
typedef struct matrix_funtype_15_ftbl_s * matrix_funtype_15_ftbl_t;

struct matrix_funtype_15_hashentry_s {uint32_t keyhash; matrix_record_13_t key; matrix_funtype_14_t value;}; 
typedef struct matrix_funtype_15_hashentry_s matrix_funtype_15_hashentry_t;

struct matrix_funtype_15_htbl_s {uint32_t size; uint32_t num_entries; matrix_funtype_15_hashentry_t * data;}; 
typedef struct matrix_funtype_15_htbl_s * matrix_funtype_15_htbl_t;

struct matrix_funtype_15_s {uint32_t count;
        matrix_funtype_15_ftbl_t ftbl;
        matrix_funtype_15_htbl_t htbl;};

extern void release_matrix_funtype_15(matrix_funtype_15_t x);

extern matrix_funtype_15_t copy_matrix_funtype_15(matrix_funtype_15_t x);

extern bool_t equal_matrix_funtype_15(matrix_funtype_15_t x, matrix_funtype_15_t y);

extern char* json_matrix_funtype_15(matrix_funtype_15_t x);




struct matrix_closure_16_s;
        typedef struct matrix_closure_16_s * matrix_closure_16_t;

struct matrix_closure_16_s {uint32_t count;
         matrix_funtype_15_ftbl_t ftbl;
         matrix_funtype_15_htbl_t htbl;};

matrix_funtype_14_t f_matrix_closure_16(struct matrix_closure_16_s * closure, matrix_record_13_t bvar);

matrix_funtype_14_t m_matrix_closure_16(struct matrix_closure_16_s * closure, uint32_t bvar_1, uint32_t bvar_2);

extern matrix_funtype_14_t h_matrix_closure_16(uint32_t ivar_12, uint32_t ivar_13);

matrix_closure_16_t new_matrix_closure_16(void);

void release_matrix_closure_16(matrix_funtype_15_t closure);

matrix_closure_16_t copy_matrix_closure_16(matrix_closure_16_t x);




struct matrix_closure_17_s;
        typedef struct matrix_closure_17_s * matrix_closure_17_t;

struct matrix_closure_17_s {uint32_t count;
         matrix_funtype_14_ftbl_t ftbl;
         matrix_funtype_14_htbl_t htbl;};

matrix__matrix_t f_matrix_closure_17(struct matrix_closure_17_s * closure, matrix__matrix_t bvar);

matrix__matrix_t m_matrix_closure_17(struct matrix_closure_17_s * closure, matrix__matrix_t bvar);

extern matrix__matrix_t h_matrix_closure_17(matrix__matrix_t ivar_16);

matrix_closure_17_t new_matrix_closure_17(void);

void release_matrix_closure_17(matrix_funtype_14_t closure);

matrix_closure_17_t copy_matrix_closure_17(matrix_closure_17_t x);




struct matrix_closure_18_s;
        typedef struct matrix_closure_18_s * matrix_closure_18_t;

struct matrix_closure_18_s {uint32_t count;
         matrix_funtype_15_ftbl_t ftbl;
         matrix_funtype_15_htbl_t htbl;};

matrix_funtype_14_t f_matrix_closure_18(struct matrix_closure_18_s * closure, matrix_record_13_t bvar);

matrix_funtype_14_t m_matrix_closure_18(struct matrix_closure_18_s * closure, uint32_t bvar_1, uint32_t bvar_2);

extern matrix_funtype_14_t h_matrix_closure_18(uint32_t ivar_21, uint32_t ivar_22);

matrix_closure_18_t new_matrix_closure_18(void);

void release_matrix_closure_18(matrix_funtype_15_t closure);

matrix_closure_18_t copy_matrix_closure_18(matrix_closure_18_t x);




struct matrix_closure_19_s;
        typedef struct matrix_closure_19_s * matrix_closure_19_t;

struct matrix_closure_19_s {uint32_t count;
         matrix_funtype_14_ftbl_t ftbl;
         matrix_funtype_14_htbl_t htbl;
        uint32_t fvar_1;};

matrix__matrix_t f_matrix_closure_19(struct matrix_closure_19_s * closure, matrix__matrix_t bvar);

matrix__matrix_t m_matrix_closure_19(struct matrix_closure_19_s * closure, matrix__matrix_t bvar);

extern matrix__matrix_t h_matrix_closure_19(matrix__matrix_t ivar_34, uint32_t ivar_22);

matrix_closure_19_t new_matrix_closure_19(void);

void release_matrix_closure_19(matrix_funtype_14_t closure);

matrix_closure_19_t copy_matrix_closure_19(matrix_closure_19_t x);




struct matrix_closure_20_s;
        typedef struct matrix_closure_20_s * matrix_closure_20_t;

struct matrix_closure_20_s {uint32_t count;
         matrix_funtype_15_ftbl_t ftbl;
         matrix_funtype_15_htbl_t htbl;};

matrix_funtype_14_t f_matrix_closure_20(struct matrix_closure_20_s * closure, matrix_record_13_t bvar);

matrix_funtype_14_t m_matrix_closure_20(struct matrix_closure_20_s * closure, uint32_t bvar_1, uint32_t bvar_2);

extern matrix_funtype_14_t h_matrix_closure_20(uint32_t ivar_18, uint32_t ivar_19);

matrix_closure_20_t new_matrix_closure_20(void);

void release_matrix_closure_20(matrix_funtype_15_t closure);

matrix_closure_20_t copy_matrix_closure_20(matrix_closure_20_t x);




struct matrix_closure_21_s;
        typedef struct matrix_closure_21_s * matrix_closure_21_t;

struct matrix_closure_21_s {uint32_t count;
         matrix_funtype_14_ftbl_t ftbl;
         matrix_funtype_14_htbl_t htbl;
        uint32_t fvar_1;};

matrix__matrix_t f_matrix_closure_21(struct matrix_closure_21_s * closure, matrix__matrix_t bvar);

matrix__matrix_t m_matrix_closure_21(struct matrix_closure_21_s * closure, matrix__matrix_t bvar);

extern matrix__matrix_t h_matrix_closure_21(matrix__matrix_t ivar_28, uint32_t ivar_18);

matrix_closure_21_t new_matrix_closure_21(void);

void release_matrix_closure_21(matrix_funtype_14_t closure);

matrix_closure_21_t copy_matrix_closure_21(matrix_closure_21_t x);




struct matrix_closure_22_s;
        typedef struct matrix_closure_22_s * matrix_closure_22_t;

struct matrix_closure_22_s {uint32_t count;
         matrix_funtype_15_ftbl_t ftbl;
         matrix_funtype_15_htbl_t htbl;};

matrix_funtype_14_t f_matrix_closure_22(struct matrix_closure_22_s * closure, matrix_record_13_t bvar);

matrix_funtype_14_t m_matrix_closure_22(struct matrix_closure_22_s * closure, uint32_t bvar_1, uint32_t bvar_2);

extern matrix_funtype_14_t h_matrix_closure_22(uint32_t ivar_27, uint32_t ivar_28);

matrix_closure_22_t new_matrix_closure_22(void);

void release_matrix_closure_22(matrix_funtype_15_t closure);

matrix_closure_22_t copy_matrix_closure_22(matrix_closure_22_t x);




struct matrix_closure_23_s;
        typedef struct matrix_closure_23_s * matrix_closure_23_t;

struct matrix_closure_23_s {uint32_t count;
         matrix_funtype_14_ftbl_t ftbl;
         matrix_funtype_14_htbl_t htbl;
        uint32_t fvar_1;
        uint32_t fvar_2;};

matrix__matrix_t f_matrix_closure_23(struct matrix_closure_23_s * closure, matrix__matrix_t bvar);

matrix__matrix_t m_matrix_closure_23(struct matrix_closure_23_s * closure, matrix__matrix_t bvar);

extern matrix__matrix_t h_matrix_closure_23(matrix__matrix_t ivar_46, uint32_t ivar_28, uint32_t ivar_27);

matrix_closure_23_t new_matrix_closure_23(void);

void release_matrix_closure_23(matrix_funtype_14_t closure);

matrix_closure_23_t copy_matrix_closure_23(matrix_closure_23_t x);


//slice

struct matrix__slice_s {
        uint32_t count; 
        mpz_t col0;
        mpz_t colhi;
        matrix__matrix_t M;
        mpz_t row0;
        mpz_t rowhi;};
typedef struct matrix__slice_s * matrix__slice_t;

extern matrix__slice_t new_matrix__slice(void);

extern void release_matrix__slice(matrix__slice_t x);

extern matrix__slice_t copy_matrix__slice(matrix__slice_t x);

extern bool_t equal_matrix__slice(matrix__slice_t x, matrix__slice_t y);
extern char * json_matrix__slice(matrix__slice_t x);

typedef struct actual_matrix__slice_s {equal_ptr_t equal_ptr; release_ptr_t release_ptr; json_ptr_t json_ptr;} * actual_matrix__slice_t;
extern void release_matrix__slice_ptr(pointer_t x, type_actual_t matrix__slice);

extern bool_t equal_matrix__slice_ptr(pointer_t x, pointer_t y, actual_matrix__slice_t T);

extern char * json_matrix__slice_ptr(pointer_t x,  actual_matrix__slice_t T);

actual_matrix__slice_t actual_matrix__slice(void);

 

extern matrix__slice_t update_matrix__slice_col0(matrix__slice_t x, mpz_ptr_t v);

extern matrix__slice_t update_matrix__slice_colhi(matrix__slice_t x, mpz_ptr_t v);

extern matrix__slice_t update_matrix__slice_M(matrix__slice_t x, matrix__matrix_t v);

extern matrix__slice_t update_matrix__slice_row0(matrix__slice_t x, mpz_ptr_t v);

extern matrix__slice_t update_matrix__slice_rowhi(matrix__slice_t x, mpz_ptr_t v);


//slice2matrix

struct matrix_record_25_s {
        uint32_t count; 
        uint32_t col0;
        uint32_t colhi;
        matrix__matrix_t M;
        uint32_t row0;
        uint32_t rowhi;};
typedef struct matrix_record_25_s * matrix_record_25_t;

extern matrix_record_25_t new_matrix_record_25(void);

extern void release_matrix_record_25(matrix_record_25_t x);

extern matrix_record_25_t copy_matrix_record_25(matrix_record_25_t x);

extern bool_t equal_matrix_record_25(matrix_record_25_t x, matrix_record_25_t y);
extern char * json_matrix_record_25(matrix_record_25_t x);

typedef struct actual_matrix_record_25_s {equal_ptr_t equal_ptr; release_ptr_t release_ptr; json_ptr_t json_ptr;} * actual_matrix_record_25_t;
extern void release_matrix_record_25_ptr(pointer_t x, type_actual_t matrix_record_25);

extern bool_t equal_matrix_record_25_ptr(pointer_t x, pointer_t y, actual_matrix_record_25_t T);

extern char * json_matrix_record_25_ptr(pointer_t x,  actual_matrix_record_25_t T);

actual_matrix_record_25_t actual_matrix_record_25(void);

 

extern matrix_record_25_t update_matrix_record_25_col0(matrix_record_25_t x, uint32_t v);

extern matrix_record_25_t update_matrix_record_25_colhi(matrix_record_25_t x, uint32_t v);

extern matrix_record_25_t update_matrix_record_25_M(matrix_record_25_t x, matrix__matrix_t v);

extern matrix_record_25_t update_matrix_record_25_row0(matrix_record_25_t x, uint32_t v);

extern matrix_record_25_t update_matrix_record_25_rowhi(matrix_record_25_t x, uint32_t v);


//slice2matrix

struct matrix_funtype_26_s;
        typedef struct matrix_funtype_26_s * matrix_funtype_26_t;

struct matrix_funtype_26_ftbl_s {matrix_funtype_5_t (* fptr)(struct matrix_funtype_26_s *, mpz_ptr_t);
        matrix_funtype_5_t (* mptr)(struct matrix_funtype_26_s *, mpz_ptr_t);
        void (* rptr)(struct matrix_funtype_26_s *);
        struct matrix_funtype_26_s * (* cptr)(struct matrix_funtype_26_s *);};
typedef struct matrix_funtype_26_ftbl_s * matrix_funtype_26_ftbl_t;

struct matrix_funtype_26_hashentry_s {uint32_t keyhash; mpz_ptr_t key; matrix_funtype_5_t value;}; 
typedef struct matrix_funtype_26_hashentry_s matrix_funtype_26_hashentry_t;

struct matrix_funtype_26_htbl_s {uint32_t size; uint32_t num_entries; matrix_funtype_26_hashentry_t * data;}; 
typedef struct matrix_funtype_26_htbl_s * matrix_funtype_26_htbl_t;

struct matrix_funtype_26_s {uint32_t count;
        matrix_funtype_26_ftbl_t ftbl;
        matrix_funtype_26_htbl_t htbl;};

extern void release_matrix_funtype_26(matrix_funtype_26_t x);

extern matrix_funtype_26_t copy_matrix_funtype_26(matrix_funtype_26_t x);

extern uint32_t lookup_matrix_funtype_26(matrix_funtype_26_htbl_t htbl, mpz_ptr_t i, uint32_t ihash);

extern matrix_funtype_26_t dupdate_matrix_funtype_26(matrix_funtype_26_t a, mpz_ptr_t i, matrix_funtype_5_t v);

extern matrix_funtype_26_t update_matrix_funtype_26(matrix_funtype_26_t a, mpz_ptr_t i, matrix_funtype_5_t v);

extern bool_t equal_matrix_funtype_26(matrix_funtype_26_t x, matrix_funtype_26_t y);

extern char* json_matrix_funtype_26(matrix_funtype_26_t x);


//slice2matrix

struct matrix_funtype_27_s;
        typedef struct matrix_funtype_27_s * matrix_funtype_27_t;

struct matrix_funtype_27_ftbl_s {matrix_funtype_26_t (* fptr)(struct matrix_funtype_27_s *, matrix_record_25_t);
        matrix_funtype_26_t (* mptr)(struct matrix_funtype_27_s *, matrix_record_25_t);
        void (* rptr)(struct matrix_funtype_27_s *);
        struct matrix_funtype_27_s * (* cptr)(struct matrix_funtype_27_s *);};
typedef struct matrix_funtype_27_ftbl_s * matrix_funtype_27_ftbl_t;

struct matrix_funtype_27_hashentry_s {uint32_t keyhash; matrix_record_25_t key; matrix_funtype_26_t value;}; 
typedef struct matrix_funtype_27_hashentry_s matrix_funtype_27_hashentry_t;

struct matrix_funtype_27_htbl_s {uint32_t size; uint32_t num_entries; matrix_funtype_27_hashentry_t * data;}; 
typedef struct matrix_funtype_27_htbl_s * matrix_funtype_27_htbl_t;

struct matrix_funtype_27_s {uint32_t count;
        matrix_funtype_27_ftbl_t ftbl;
        matrix_funtype_27_htbl_t htbl;};

extern void release_matrix_funtype_27(matrix_funtype_27_t x);

extern matrix_funtype_27_t copy_matrix_funtype_27(matrix_funtype_27_t x);

extern bool_t equal_matrix_funtype_27(matrix_funtype_27_t x, matrix_funtype_27_t y);

extern char* json_matrix_funtype_27(matrix_funtype_27_t x);




struct matrix_closure_28_s;
        typedef struct matrix_closure_28_s * matrix_closure_28_t;

struct matrix_closure_28_s {uint32_t count;
         matrix_funtype_27_ftbl_t ftbl;
         matrix_funtype_27_htbl_t htbl;};

matrix_funtype_26_t f_matrix_closure_28(struct matrix_closure_28_s * closure, matrix_record_25_t bvar);

matrix_funtype_26_t m_matrix_closure_28(struct matrix_closure_28_s * closure, matrix_record_25_t bvar);

extern matrix_funtype_26_t h_matrix_closure_28(matrix_record_25_t ivar_17);

matrix_closure_28_t new_matrix_closure_28(void);

void release_matrix_closure_28(matrix_funtype_27_t closure);

matrix_closure_28_t copy_matrix_closure_28(matrix_closure_28_t x);




struct matrix_closure_29_s;
        typedef struct matrix_closure_29_s * matrix_closure_29_t;

struct matrix_closure_29_s {uint32_t count;
         matrix_funtype_26_ftbl_t ftbl;
         matrix_funtype_26_htbl_t htbl;
        matrix_record_25_t fvar_1;};

matrix_funtype_5_t f_matrix_closure_29(struct matrix_closure_29_s * closure, mpz_ptr_t bvar);

matrix_funtype_5_t m_matrix_closure_29(struct matrix_closure_29_s * closure, mpz_ptr_t bvar);

extern matrix_funtype_5_t h_matrix_closure_29(mpz_ptr_t ivar_36, matrix_record_25_t ivar_17);

matrix_closure_29_t new_matrix_closure_29(void);

void release_matrix_closure_29(matrix_funtype_26_t closure);

matrix_closure_29_t copy_matrix_closure_29(matrix_closure_29_t x);




struct matrix_closure_30_s;
        typedef struct matrix_closure_30_s * matrix_closure_30_t;

struct matrix_closure_30_s {uint32_t count;
         matrix_funtype_5_ftbl_t ftbl;
         matrix_funtype_5_htbl_t htbl;
        matrix_record_25_t fvar_1;
        mpz_t fvar_2;};

mpq_ptr_t f_matrix_closure_30(struct matrix_closure_30_s * closure, mpz_ptr_t bvar);

mpq_ptr_t m_matrix_closure_30(struct matrix_closure_30_s * closure, mpz_ptr_t bvar);

extern mpq_ptr_t h_matrix_closure_30(mpz_ptr_t ivar_54, matrix_record_25_t ivar_17, mpz_ptr_t ivar_36);

matrix_closure_30_t new_matrix_closure_30(void);

void release_matrix_closure_30(matrix_funtype_5_t closure);

matrix_closure_30_t copy_matrix_closure_30(matrix_closure_30_t x);


//numrows

struct matrix_funtype_31_s;
        typedef struct matrix_funtype_31_s * matrix_funtype_31_t;

struct matrix_funtype_31_ftbl_s {mpz_ptr_t (* fptr)(struct matrix_funtype_31_s *, matrix_record_25_t);
        mpz_ptr_t (* mptr)(struct matrix_funtype_31_s *, matrix_record_25_t);
        void (* rptr)(struct matrix_funtype_31_s *);
        struct matrix_funtype_31_s * (* cptr)(struct matrix_funtype_31_s *);};
typedef struct matrix_funtype_31_ftbl_s * matrix_funtype_31_ftbl_t;

struct matrix_funtype_31_hashentry_s {uint32_t keyhash; matrix_record_25_t key; mpz_t value;}; 
typedef struct matrix_funtype_31_hashentry_s matrix_funtype_31_hashentry_t;

struct matrix_funtype_31_htbl_s {uint32_t size; uint32_t num_entries; matrix_funtype_31_hashentry_t * data;}; 
typedef struct matrix_funtype_31_htbl_s * matrix_funtype_31_htbl_t;

struct matrix_funtype_31_s {uint32_t count;
        matrix_funtype_31_ftbl_t ftbl;
        matrix_funtype_31_htbl_t htbl;};

extern void release_matrix_funtype_31(matrix_funtype_31_t x);

extern matrix_funtype_31_t copy_matrix_funtype_31(matrix_funtype_31_t x);

extern bool_t equal_matrix_funtype_31(matrix_funtype_31_t x, matrix_funtype_31_t y);

extern char* json_matrix_funtype_31(matrix_funtype_31_t x);




struct matrix_closure_32_s;
        typedef struct matrix_closure_32_s * matrix_closure_32_t;

struct matrix_closure_32_s {uint32_t count;
         matrix_funtype_31_ftbl_t ftbl;
         matrix_funtype_31_htbl_t htbl;};

mpz_ptr_t f_matrix_closure_32(struct matrix_closure_32_s * closure, matrix_record_25_t bvar);

mpz_ptr_t m_matrix_closure_32(struct matrix_closure_32_s * closure, matrix_record_25_t bvar);

extern mpz_ptr_t h_matrix_closure_32(matrix_record_25_t ivar_10);

matrix_closure_32_t new_matrix_closure_32(void);

void release_matrix_closure_32(matrix_funtype_31_t closure);

matrix_closure_32_t copy_matrix_closure_32(matrix_closure_32_t x);




struct matrix_closure_33_s;
        typedef struct matrix_closure_33_s * matrix_closure_33_t;

struct matrix_closure_33_s {uint32_t count;
         matrix_funtype_31_ftbl_t ftbl;
         matrix_funtype_31_htbl_t htbl;};

mpz_ptr_t f_matrix_closure_33(struct matrix_closure_33_s * closure, matrix_record_25_t bvar);

mpz_ptr_t m_matrix_closure_33(struct matrix_closure_33_s * closure, matrix_record_25_t bvar);

extern mpz_ptr_t h_matrix_closure_33(matrix_record_25_t ivar_10);

matrix_closure_33_t new_matrix_closure_33(void);

void release_matrix_closure_33(matrix_funtype_31_t closure);

matrix_closure_33_t copy_matrix_closure_33(matrix_closure_33_t x);


//fullslice

struct matrix_funtype_34_s;
        typedef struct matrix_funtype_34_s * matrix_funtype_34_t;

struct matrix_funtype_34_ftbl_s {matrix__slice_t (* fptr)(struct matrix_funtype_34_s *, matrix__matrix_t);
        matrix__slice_t (* mptr)(struct matrix_funtype_34_s *, matrix__matrix_t);
        void (* rptr)(struct matrix_funtype_34_s *);
        struct matrix_funtype_34_s * (* cptr)(struct matrix_funtype_34_s *);};
typedef struct matrix_funtype_34_ftbl_s * matrix_funtype_34_ftbl_t;

struct matrix_funtype_34_hashentry_s {uint32_t keyhash; matrix__matrix_t key; matrix__slice_t value;}; 
typedef struct matrix_funtype_34_hashentry_s matrix_funtype_34_hashentry_t;

struct matrix_funtype_34_htbl_s {uint32_t size; uint32_t num_entries; matrix_funtype_34_hashentry_t * data;}; 
typedef struct matrix_funtype_34_htbl_s * matrix_funtype_34_htbl_t;

struct matrix_funtype_34_s {uint32_t count;
        matrix_funtype_34_ftbl_t ftbl;
        matrix_funtype_34_htbl_t htbl;};

extern void release_matrix_funtype_34(matrix_funtype_34_t x);

extern matrix_funtype_34_t copy_matrix_funtype_34(matrix_funtype_34_t x);

extern bool_t equal_matrix_funtype_34(matrix_funtype_34_t x, matrix_funtype_34_t y);

extern char* json_matrix_funtype_34(matrix_funtype_34_t x);




struct matrix_closure_35_s;
        typedef struct matrix_closure_35_s * matrix_closure_35_t;

struct matrix_closure_35_s {uint32_t count;
         matrix_funtype_34_ftbl_t ftbl;
         matrix_funtype_34_htbl_t htbl;
        mpz_t fvar_1;
        mpz_t fvar_2;};

matrix__slice_t f_matrix_closure_35(struct matrix_closure_35_s * closure, matrix__matrix_t bvar);

matrix__slice_t m_matrix_closure_35(struct matrix_closure_35_s * closure, matrix__matrix_t bvar);

extern matrix__slice_t h_matrix_closure_35(matrix__matrix_t ivar_5, mpz_ptr_t ivar_1, mpz_ptr_t ivar_2);

matrix_closure_35_t new_matrix_closure_35(void);

void release_matrix_closure_35(matrix_funtype_34_t closure);

matrix_closure_35_t copy_matrix_closure_35(matrix_closure_35_t x);


//choptop

struct matrix_record_36_s {
        uint32_t count; 
        matrix__slice_t project_1;
        mpz_t project_2;};
typedef struct matrix_record_36_s * matrix_record_36_t;

extern matrix_record_36_t new_matrix_record_36(void);

extern void release_matrix_record_36(matrix_record_36_t x);

extern matrix_record_36_t copy_matrix_record_36(matrix_record_36_t x);

extern bool_t equal_matrix_record_36(matrix_record_36_t x, matrix_record_36_t y);
extern char * json_matrix_record_36(matrix_record_36_t x);

typedef struct actual_matrix_record_36_s {equal_ptr_t equal_ptr; release_ptr_t release_ptr; json_ptr_t json_ptr;} * actual_matrix_record_36_t;
extern void release_matrix_record_36_ptr(pointer_t x, type_actual_t matrix_record_36);

extern bool_t equal_matrix_record_36_ptr(pointer_t x, pointer_t y, actual_matrix_record_36_t T);

extern char * json_matrix_record_36_ptr(pointer_t x,  actual_matrix_record_36_t T);

actual_matrix_record_36_t actual_matrix_record_36(void);

 

extern matrix_record_36_t update_matrix_record_36_project_1(matrix_record_36_t x, matrix__slice_t v);

extern matrix_record_36_t update_matrix_record_36_project_2(matrix_record_36_t x, mpz_ptr_t v);


//choptop

struct matrix_funtype_37_s;
        typedef struct matrix_funtype_37_s * matrix_funtype_37_t;

struct matrix_funtype_37_ftbl_s {matrix__slice_t (* fptr)(struct matrix_funtype_37_s *, matrix_record_36_t);
        matrix__slice_t (* mptr)(struct matrix_funtype_37_s *, matrix__slice_t, mpz_ptr_t);
        void (* rptr)(struct matrix_funtype_37_s *);
        struct matrix_funtype_37_s * (* cptr)(struct matrix_funtype_37_s *);};
typedef struct matrix_funtype_37_ftbl_s * matrix_funtype_37_ftbl_t;

struct matrix_funtype_37_hashentry_s {uint32_t keyhash; matrix_record_36_t key; matrix__slice_t value;}; 
typedef struct matrix_funtype_37_hashentry_s matrix_funtype_37_hashentry_t;

struct matrix_funtype_37_htbl_s {uint32_t size; uint32_t num_entries; matrix_funtype_37_hashentry_t * data;}; 
typedef struct matrix_funtype_37_htbl_s * matrix_funtype_37_htbl_t;

struct matrix_funtype_37_s {uint32_t count;
        matrix_funtype_37_ftbl_t ftbl;
        matrix_funtype_37_htbl_t htbl;};

extern void release_matrix_funtype_37(matrix_funtype_37_t x);

extern matrix_funtype_37_t copy_matrix_funtype_37(matrix_funtype_37_t x);

extern bool_t equal_matrix_funtype_37(matrix_funtype_37_t x, matrix_funtype_37_t y);

extern char* json_matrix_funtype_37(matrix_funtype_37_t x);




struct matrix_closure_38_s;
        typedef struct matrix_closure_38_s * matrix_closure_38_t;

struct matrix_closure_38_s {uint32_t count;
         matrix_funtype_37_ftbl_t ftbl;
         matrix_funtype_37_htbl_t htbl;};

matrix__slice_t f_matrix_closure_38(struct matrix_closure_38_s * closure, matrix_record_36_t bvar);

matrix__slice_t m_matrix_closure_38(struct matrix_closure_38_s * closure, matrix__slice_t bvar_1, mpz_ptr_t bvar_2);

extern matrix__slice_t h_matrix_closure_38(matrix__slice_t ivar_80, mpz_ptr_t ivar_81);

matrix_closure_38_t new_matrix_closure_38(void);

void release_matrix_closure_38(matrix_funtype_37_t closure);

matrix_closure_38_t copy_matrix_closure_38(matrix_closure_38_t x);




struct matrix_closure_39_s;
        typedef struct matrix_closure_39_s * matrix_closure_39_t;

struct matrix_closure_39_s {uint32_t count;
         matrix_funtype_37_ftbl_t ftbl;
         matrix_funtype_37_htbl_t htbl;};

matrix__slice_t f_matrix_closure_39(struct matrix_closure_39_s * closure, matrix_record_36_t bvar);

matrix__slice_t m_matrix_closure_39(struct matrix_closure_39_s * closure, matrix__slice_t bvar_1, mpz_ptr_t bvar_2);

extern matrix__slice_t h_matrix_closure_39(matrix__slice_t ivar_80, mpz_ptr_t ivar_81);

matrix_closure_39_t new_matrix_closure_39(void);

void release_matrix_closure_39(matrix_funtype_37_t closure);

matrix_closure_39_t copy_matrix_closure_39(matrix_closure_39_t x);




struct matrix_closure_40_s;
        typedef struct matrix_closure_40_s * matrix_closure_40_t;

struct matrix_closure_40_s {uint32_t count;
         matrix_funtype_37_ftbl_t ftbl;
         matrix_funtype_37_htbl_t htbl;};

matrix__slice_t f_matrix_closure_40(struct matrix_closure_40_s * closure, matrix_record_36_t bvar);

matrix__slice_t m_matrix_closure_40(struct matrix_closure_40_s * closure, matrix__slice_t bvar_1, mpz_ptr_t bvar_2);

extern matrix__slice_t h_matrix_closure_40(matrix__slice_t ivar_80, mpz_ptr_t ivar_81);

matrix_closure_40_t new_matrix_closure_40(void);

void release_matrix_closure_40(matrix_funtype_37_t closure);

matrix_closure_40_t copy_matrix_closure_40(matrix_closure_40_t x);




struct matrix_closure_41_s;
        typedef struct matrix_closure_41_s * matrix_closure_41_t;

struct matrix_closure_41_s {uint32_t count;
         matrix_funtype_37_ftbl_t ftbl;
         matrix_funtype_37_htbl_t htbl;};

matrix__slice_t f_matrix_closure_41(struct matrix_closure_41_s * closure, matrix_record_36_t bvar);

matrix__slice_t m_matrix_closure_41(struct matrix_closure_41_s * closure, matrix__slice_t bvar_1, mpz_ptr_t bvar_2);

extern matrix__slice_t h_matrix_closure_41(matrix__slice_t ivar_80, mpz_ptr_t ivar_81);

matrix_closure_41_t new_matrix_closure_41(void);

void release_matrix_closure_41(matrix_funtype_37_t closure);

matrix_closure_41_t copy_matrix_closure_41(matrix_closure_41_t x);



extern matrix__matrix_t matrix__I(uint32_t ivar_1);

extern matrix__matrix_t matrix__Z(uint32_t ivar_1, uint32_t ivar_2);

extern matrix_funtype_3_t matrix__madd(uint32_t ivar_1, uint32_t ivar_2);

extern matrix__matrix_t matrix__mmult(mpz_ptr_t ivar_1, mpz_ptr_t ivar_2, mpz_ptr_t ivar_3, matrix__matrix_t ivar_4, matrix__matrix_t ivar_5);

extern matrix_funtype_7_t matrix__right_inverse(uint32_t ivar_1, matrix__matrix_t ivar_2);

extern matrix_funtype_7_t matrix__left_inverse(uint32_t ivar_1, matrix__matrix_t ivar_2);

extern matrix_funtype_7_t matrix__inverse(uint32_t ivar_1, matrix__matrix_t ivar_2);

extern bool_t matrix__lower_triangularp(uint32_t ivar_1, matrix__matrix_t ivar_2);

extern matrix_funtype_3_t matrix__concat(uint32_t ivar_1, uint32_t ivar_2, uint32_t ivar_3);

extern matrix_funtype_3_t matrix__stack(uint32_t ivar_1, uint32_t ivar_2, uint32_t ivar_3);

extern matrix_funtype_15_t matrix__topleft(uint32_t ivar_1, uint32_t ivar_2);

extern matrix_funtype_15_t matrix__topright(uint32_t ivar_1, uint32_t ivar_2);

extern matrix_funtype_15_t matrix__botleft(uint32_t ivar_1, uint32_t ivar_2);

extern matrix_funtype_15_t matrix__botright(uint32_t ivar_1, uint32_t ivar_2);

extern matrix_funtype_27_t matrix__slice2matrix(uint32_t ivar_1, uint32_t ivar_2);

extern matrix_funtype_31_t matrix__numrows(uint32_t ivar_1, uint32_t ivar_2);

extern matrix_funtype_31_t matrix__numcols(uint32_t ivar_1, uint32_t ivar_2);

extern matrix_funtype_34_t matrix__fullslice(mpz_ptr_t ivar_1, mpz_ptr_t ivar_2);

extern matrix_funtype_37_t matrix__choptop(mpz_ptr_t ivar_1, mpz_ptr_t ivar_2);

extern matrix_funtype_37_t matrix__chopbot(mpz_ptr_t ivar_1, mpz_ptr_t ivar_2);

extern matrix_funtype_37_t matrix__diceleft(mpz_ptr_t ivar_1, mpz_ptr_t ivar_2);

extern matrix_funtype_37_t matrix__diceright(mpz_ptr_t ivar_1, mpz_ptr_t ivar_2);

extern bool_t matrix__test1(void);
#endif
